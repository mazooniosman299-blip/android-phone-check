#!/usr/bin/env python3
"""Fail-closed channel release gate: uses a user-authorized M3U snapshot.

A stream that merely answers HTTP 200 is NOT considered playable. This probe
must decode video frames and non-silent PCM audio. A separate Android on-device
Media3 test is also mandatory before a release is approved.
"""
import argparse
import json
import math
import re
import subprocess
import sys
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed


def parse_m3u(text):
    rows = []
    label = None
    for line in text.splitlines():
        value = line.strip()
        if value.startswith('#EXTINF:'):
            label = value.rsplit(',', 1)[-1].strip()
        elif value and not value.startswith('#'):
            if value.startswith(('https://', 'http://')) and not value.lower().split('?')[0].endswith(('.m3u', '.html')):
                rows.append({'name': label or 'Unknown', 'url': value.split('|', 1)[0]})
            label = None
    return rows


def ffmpeg_probe(item, seconds=5):
    # No DRM handling, login bypass, cookie extraction or stream downloading to disk.
    src = item['url']
    cmd = ['ffmpeg', '-v', 'error', '-nostdin', '-rw_timeout', '8000000', '-i', src,
           '-t', str(seconds), '-map', '0:v:0', '-frames:v', '3', '-f', 'image2pipe',
           '-vcodec', 'mjpeg', 'pipe:1']
    try:
        video = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=25)
        has_video = video.returncode == 0 and video.stdout.count(b'\xff\xd8') >= 2
        cmd = ['ffmpeg', '-v', 'error', '-nostdin', '-rw_timeout', '8000000', '-i', src,
               '-t', str(seconds), '-map', '0:a:0', '-ac', '1', '-ar', '8000',
               '-f', 's16le', 'pipe:1']
        audio = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=25)
        pcm = audio.stdout
        # Sample at most 4 MiB. Quiet speech may yield false negatives; that's
        # intentional for a release gate that must not mislabel silent channels.
        import array
        samples = array.array('h')
        samples.frombytes(pcm[:4_000_000 - len(pcm[:4_000_000]) % 2])
        rms = math.sqrt(sum(int(x)*int(x) for x in samples[::32]) / max(1, len(samples[::32]))) if samples else 0
        ok = has_video and audio.returncode == 0 and rms > 18
        return {'name':item['name'], 'ok':ok, 'decoded_video':has_video,
                'audible_pcm':audio.returncode==0 and rms>18}
    except (OSError, subprocess.TimeoutExpired):
        return {'name':item['name'], 'ok':False, 'decoded_video':False, 'audible_pcm':False}


def main():
    a = argparse.ArgumentParser(description=__doc__)
    a.add_argument('--playlist', required=True)
    a.add_argument('--minimum-channels', type=int, default=300)
    a.add_argument('--workers', type=int, default=3)
    a.add_argument('--report', required=True)
    args = a.parse_args()
    channels = parse_m3u(Path(args.playlist).read_text(encoding='utf-8-sig'))
    names = [c['name'].casefold() for c in channels]
    zee = any(('zee alwan' in name or 'زي ألوان' in name or 'زي الوان' in name) for name in names)
    report = {'total':len(channels), 'zee_in_catalog':zee, 'results':[], 'release_approved':False,
              'note':'FFmpeg decoder evidence only. Native Android Media3 evidence is separately required.'}
    if len(channels) >= args.minimum_channels and zee:
        with ThreadPoolExecutor(max_workers=min(max(1,args.workers),5)) as executor:
            futures = [executor.submit(ffmpeg_probe, ch) for ch in channels]
            for future in as_completed(futures): report['results'].append(future.result())
    # Never mark release_approved from remote FFmpeg alone; native device run is required.
    Path(args.report).write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    passed = sum(r['ok'] for r in report['results'])
    print(f'CHECK: decoded audio+video {passed}/{len(channels)}. Zee entry: {zee}. Android device validation required.')
    raise SystemExit(1)


if __name__ == '__main__': main()
