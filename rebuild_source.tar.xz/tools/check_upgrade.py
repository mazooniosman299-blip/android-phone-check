#!/usr/bin/env python3
"""Fail-closed identity, version and signing compatibility gate for built APKs.

Requires Android SDK aapt + apksigner; does not contain or modify signing keys.
"""
import argparse
import re
import subprocess
import sys


def output(argv):
    return subprocess.check_output(argv, text=True, stderr=subprocess.STDOUT, timeout=30)


def identity(aapt, apk):
    msg = output([aapt, 'dump', 'badging', apk])
    match = re.search(r"^package: name='([^']+)' versionCode='(\d+)'", msg, re.M)
    if not match:
        raise RuntimeError(f'APK package identity missing in {apk}')
    return match.group(1), int(match.group(2))


def cert(apksigner, apk):
    output([apksigner, 'verify', '--verbose', apk])
    msg = output([apksigner, 'verify', '--print-certs', apk])
    match = re.search(r'^Signer #1 certificate SHA-256 digest: ([0-9a-fA-F]{64})$', msg, re.M)
    if not match:
        raise RuntimeError(f'Signer certificate unavailable: {apk}')
    return match.group(1).upper()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--aapt', required=True)
    parser.add_argument('--apksigner', required=True)
    parser.add_argument('--installed-apk', required=True, help='Actual currently installed version, exported with user consent')
    parser.add_argument('--candidate-apk', required=True)
    args = parser.parse_args()
    old_pkg, old_ver = identity(args.aapt, args.installed_apk)
    new_pkg, new_ver = identity(args.aapt, args.candidate_apk)
    old_cert = cert(args.apksigner, args.installed_apk)
    new_cert = cert(args.apksigner, args.candidate_apk)
    if old_pkg != new_pkg or old_pkg != 'com.mazentv.live':
        raise RuntimeError(f'Package mismatch: {old_pkg}, {new_pkg}')
    if new_ver <= old_ver:
        raise RuntimeError(f'Version must increase: {old_ver} -> {new_ver}')
    if old_cert != new_cert:
        raise RuntimeError('SIGNATURE MISMATCH. Do not publish this APK as an in-place upgrade.')
    print(f'PASS upgrade identity: {old_pkg}, versionCode {old_ver}->{new_ver}, SAME SHA-256 signer {new_cert}')


if __name__ == '__main__':
    try:
        main()
    except (OSError, subprocess.SubprocessError, RuntimeError) as error:
        print(f'RELEASE BLOCKED: {error}', file=sys.stderr)
        raise SystemExit(1)
