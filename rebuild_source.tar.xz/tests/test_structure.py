from pathlib import Path
import re
from xml.etree import ElementTree

root=Path(__file__).resolve().parents[1]
java=root/'app/src/main/java/com/mazentv/live'
files={p.name:p.read_text() for p in java.glob('*.java')}
required={'Channel.java','StreamAddress.java','PlaylistParser.java','ChannelStore.java',
          'CatalogService.java','CatalogIndex.java','MainActivity.java','PlayerActivity.java',
          'BackupService.java','LogoLoader.java','XtreamPlaylist.java'}
assert required <= files.keys(),required-files.keys()
assert 'new WebView' not in ''.join(files.values()),'No embedded third-party website in rebuilt player'
assert 'android.webkit.WebView' not in ''.join(files.values()),'No WebView dependency'
assert 'RESIZE_MODE_FIT' in files['PlayerActivity.java'],'No crop by default'
assert 'onRenderedFirstFrame' in files['PlayerActivity.java'],'Do not confuse READY with decoded video'
assert 'DefaultHttpDataSource' in files['PlayerActivity.java'],'Use native Media3 HTTP source'
assert 'getStringArrayListExtra("alternatives")' in files['PlayerActivity.java'],'Channel-specific fallback only'
assert 'setDefaultRequestProperties(endpoint.headers)' in files['PlayerActivity.java'],'Respect approved M3U request metadata'
assert 'tilfazi_channels_v2.db' in files['ChannelStore.java']
assert 'v4_migration_done' in files['ChannelStore.java'], 'Non-destructive legacy migration'
assert 'remove("channels")' not in files['ChannelStore.java'], 'Never erase original legacy preferences'
assert 'store.migrateOldPreferences' in files['MainActivity.java'], 'Migrate in background'
assert 'channelSnapshot' in files['MainActivity.java'] and 'diskWorker.execute' in files['MainActivity.java'], 'No full-table scans in filter'
assert 'if(!current())return;' in files['PlayerActivity.java'], 'Reject stale player callbacks'
assert 'setAllowCrossProtocolRedirects(false)' in files['PlayerActivity.java'], 'Prevent HTTPS downgrade'
assert 'DROP TABLE' not in files['ChannelStore.java'],'Do not erase users'
assert 'favorite INTEGER NOT NULL DEFAULT 0' in files['ChannelStore.java']
assert 'catalog_sync' in files['ChannelStore.java'],'Track each catalog separately'
assert 'getResponseCode()!=200' in files['LogoLoader.java']
assert 'ActivityResultContracts.OpenDocument' in files['MainActivity.java'],'Lifecycle aware import'
assert 'ActivityResultContracts.CreateDocument' in files['MainActivity.java'],'Backup export'
assert 'ArrayBlockingQueue' in files['LogoLoader.java'], 'Bound logo task backlog'
assert "applicationId 'com.mazentv.live'" in (root/'app/build.gradle').read_text()
assert "versionCode 20" in (root/'app/build.gradle').read_text()
assert "signingConfig signingConfigs.stableRelease" in (root/'app/build.gradle').read_text()
manifest=root/'app/src/main/AndroidManifest.xml'
ElementTree.parse(manifest)
assert 'PlayerActivity' in manifest.read_text()
for p in (root/'app/src/main/res').rglob('*.xml'):ElementTree.parse(p)
print(f'PASS: {len(files)} rebuilt Java modules, data retention, native playback and XML checks')
