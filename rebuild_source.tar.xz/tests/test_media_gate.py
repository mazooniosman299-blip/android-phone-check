#!/usr/bin/env python3
"""Offline media-gate integration tests using actual FFmpeg video/audio decoders.

These fixtures deliberately do not simulate internet or claim TV-channel playback.
"""
import importlib.util
import pathlib
import shutil
import subprocess
import tempfile

base = pathlib.Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('gate', base / 'tools' / 'channel_playback_gate.py')
gate = importlib.util.module_from_spec(spec)
spec.loader.exec_module(gate)

def make(path, mode):
    cmd = ['ffmpeg', '-hide_banner', '-loglevel', 'error', '-nostdin', '-y',
           '-f', 'lavfi', '-i', 'testsrc2=size=96x96:rate=12:duration=2']
    if mode != 'video_only':
        source = 'anullsrc=r=8000:cl=mono' if mode == 'silent' else 'sine=frequency=880:sample_rate=8000:duration=2'
        cmd += ['-f', 'lavfi', '-i', source]
    cmd += ['-t', '2', '-c:v', 'mpeg4', '-q:v', '6']
    if mode != 'video_only': cmd += ['-c:a', 'aac', '-shortest']
    cmd += [str(path)]
    subprocess.run(cmd, check=True, timeout=30)

def main():
    if not shutil.which('ffmpeg'):
        raise RuntimeError('FFmpeg integration test cannot run without ffmpeg')
    with tempfile.TemporaryDirectory() as temp:
        for mode, expected in [('valid', True), ('video_only', False), ('silent', False)]:
            path = pathlib.Path(temp) / (mode + '.mp4')
            make(path, mode)
            result = gate.ffmpeg_probe({'name':mode,'url':str(path)}, seconds=2)
            assert result['ok'] == expected, (mode, result)
            print(f'PASS decoded video and audio — {mode}: {result}')
    print('PASS: 3 actual FFmpeg fixture integrations (not live channels)')

if __name__=='__main__':
    main()
