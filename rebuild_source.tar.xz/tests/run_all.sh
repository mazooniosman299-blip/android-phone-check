#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
BUILD="$(mktemp -d)"
trap 'rm -rf "$BUILD"' EXIT
BASE=app/src/main/java/com/mazentv/live
javac -encoding UTF-8 -d "$BUILD" "$BASE/Channel.java" "$BASE/StreamAddress.java" \
    "$BASE/PlaylistParser.java" "$BASE/CatalogIndex.java" "$BASE/XtreamPlaylist.java" tests/ModelTests.java
java -cp "$BUILD" com.mazentv.live.ModelTests
python3 tests/test_structure.py

SYNTAX="$BUILD/grammar"
mkdir -p "$SYNTAX"
javac -d "$SYNTAX" tests/SyntaxCheck.java
java -cp "$SYNTAX" SyntaxCheck "$BASE"/*.java

if [ "${RUN_MEDIA_TESTS:-0}" = "1" ]; then
    python3 tests/test_media_gate.py
fi
