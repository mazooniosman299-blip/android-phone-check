package com.mazentv.live;
import java.util.List;

public final class ModelTests {
    private static int checks=0;
    private static void require(boolean condition,String name){checks++;if(!condition)throw new AssertionError(name);}
    public static void main(String[] args)throws Exception{
        require(StreamAddress.isMedia("https://example.org/live/abc.m3u8"),"HLS");
        require(StreamAddress.isMedia("https://example.org/live/tv.mpd"),"DASH");
        require(StreamAddress.isMedia("https://provider.test/live/stream/abc?token=123"),"extensionless media");
        require(StreamAddress.isMedia("http://example.org/live/u/p/32.ts"),"user-authorized legacy MPEG-TS");
        require(!StreamAddress.isMedia("https://provider.org/list.m3u"),"channel playlist is not a video");
        require(!StreamAddress.isMedia("https://site.net/watch.html"),"web page is not a video");
        require(!StreamAddress.isMedia("https://starzplay.com/ar/watch/movies/zee-alwan/559865896371"),"ZEE watch page not a Media3 stream");
        require(!StreamAddress.isMedia("https://www.zee5.com/tv-shows"),"ZEE5 webpage not a stream");
        require(!StreamAddress.isMedia("file:///etc/passwd"),"no local file source");
        require(!StreamAddress.isMedia("https://u:p@service.net/live.m3u8"),"no userinfo");
        require(!StreamAddress.isMedia("https://example.com/live.m3u8|Cookie=abc"),"no credential header");
        require(!StreamAddress.isMedia("https://example.com/live.m3u8|Origin=hello%0D%0Ax"),"no header injection");
        require(StreamAddress.parse("https://ok.example/play|User-Agent=My%20Player&Referer=https%3A%2F%2Ffoo.example%2F").headers.size()==2,"metadata headers");
        String playlist="#EXTM3U\n#EXTINF:-1 tvg-logo=\"https://img.example/a.png\" group-title=\"أطفال\",قناة, عربية\nhttps://cdn.example/live/a.m3u8\n";
        List<Channel> parsed=PlaylistParser.parse(playlist,10);
        require(parsed.size()==1,"valid list");
        require(parsed.get(0).name.equals("قناة, عربية"),"commas in channel name");
        require(parsed.get(0).group.equals("أطفال"),"group from M3U");
        require(parsed.get(0).logo.equals("https://img.example/a.png"),"logo");
        try{PlaylistParser.parse("#EXTM3U\n#EXT-X-TARGETDURATION:5\n#EXTINF:5\nchunk.ts",10);throw new AssertionError("Accepted HLS as channels");}
        catch(java.io.IOException expected){checks++;}
        try{PlaylistParser.parse("<html>Hello</html>",10);throw new AssertionError("Accepted HTML");}
        catch(java.io.IOException expected){checks++;}
        require(CatalogIndex.full().size()>=15,"full catalog coverage");
        require(CatalogIndex.full().stream().allMatch(CatalogIndex::isTrusted),"trusted source URLs");
        require(!CatalogIndex.isTrusted("https://evil.example/iptv/index.m3u"),"reject untrusted host");
        require(!CatalogIndex.isTrusted("https://iptv-org.github.io.evil.tld/iptv/index.m3u"),"no matching suffix spoof");
        require(!CatalogIndex.isTrusted("http://iptv-org.github.io/iptv/index.m3u"),"HTTPS required");
        String xtream=XtreamPlaylist.buildUrl("https://provider.example","u&v","p+123");
        require(xtream!=null && xtream.contains("username=u%26v") && xtream.contains("password=p%2B123"),"Xtream URL encoding");
        require(XtreamPlaylist.buildUrl("file:///local","user","pass")==null,"no unsafe provider URL");
        require(XtreamPlaylist.buildUrl("http://provider.example","user","secret")==null,"reject plaintext IPTV credentials");
        require(StreamAddress.isMedia("https://example.net/live/channel?auth=abc"),"extensionless HTTPS player URL");
        require(!StreamAddress.isMedia("https://example.net/list.m3u?access=abc"),"reject a playlist disguised by query");
        require(!StreamAddress.isMedia("https://example.net/live.m3u8|Referer=hello%0D%0AHost%3Aevil"),"header CRLF protection");
        require(!StreamAddress.isMedia("https://example.net/live.m3u8|Cookie=secret"),"do not expose arbitrary credentials headers");
        require(PlaylistParser.parse("#EXTM3U\n#EXTINF:-1,قناة الاختبار\nhttps://example.org/stream/channel\n",5).size()==1,"parse extensionless channels");
        System.out.println("PASS: " +checks + " independent rebuilt-model assertions");
    }
}
