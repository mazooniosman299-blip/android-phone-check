# QA status — 30 Oct 2026

- New architecture: 11 modules, 32 pure-JVM checks and Java syntax checks pass.
- Previous Android source files not reused. Only Android build configuration, strings/theme, vector icon reused as resources for identity compatibility.
- Local Android SDK / Gradle: unavailable in active execution environment; full Android compile not performed.
- Actual native APK/video/audio on device: not performed.
- Zee Alwan: no verified direct HLS/DASH media endpoint; unresolved.
- All live IPTV channels: not tested, cannot assert playback coverage.
- Upgrade compatibility: package + monotonically increasing code provided; actual signer and on-device update not verified on the new rebuild.
- Public release gate: BLOCKED. No APK release created or pushed to GitHub.

## 4.0.1 QA progress
- Pure Java: 32 assertions passed.
- Real FFmpeg local fixtures: video + audible PCM accepted; silent audio and missing audio rejected.
- Main thread no longer performs full-channel snapshot database queries during search and tabs.
- Legacy preferences are retained and migrated on a background worker; database closure waits for network workers where possible.
- Network/Android native channel playback has not been proven; **release remains blocked**.
