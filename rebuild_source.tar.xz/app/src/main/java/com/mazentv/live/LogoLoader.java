package com.mazentv.live;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Handler;
import android.os.Looper;
import android.util.LruCache;
import android.widget.ImageView;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.lang.ref.WeakReference;

/** Bounded background image cache. Does not fetch any network data on the UI thread. */
public final class LogoLoader {
    // Bounded queue avoids retaining thousands of obsolete logo tasks during fast scrolling.
    private final ThreadPoolExecutor workers=new ThreadPoolExecutor(3,3,0L,TimeUnit.MILLISECONDS,
            new ArrayBlockingQueue<>(96),new ThreadPoolExecutor.AbortPolicy());
    private final ConcurrentHashMap<String,CopyOnWriteArrayList<WeakReference<ImageView>>> pending=new ConcurrentHashMap<>();
    private final Handler main=new Handler(Looper.getMainLooper());
    private final LruCache<String,Bitmap> cache=new LruCache<>(48);
    public void load(ImageView view,String url) {
        view.setImageResource(R.drawable.ic_tv);
        view.setTag(url);
        if(url==null || !url.startsWith("https://") || url.length()>2048) return;
        Bitmap found=cache.get(url);
        if(found!=null){view.setImageBitmap(found);return;}
        CopyOnWriteArrayList<WeakReference<ImageView>> waiting=new CopyOnWriteArrayList<>();
        waiting.add(new WeakReference<>(view));
        CopyOnWriteArrayList<WeakReference<ImageView>> existing=pending.putIfAbsent(url,waiting);
        if(existing!=null){existing.add(new WeakReference<>(view));return;}
        if(workers.getQueue().remainingCapacity()==0){pending.remove(url);return;}
        try { workers.execute(()->{
            Bitmap image=null;
            try {
                image=readLogo(url);
                if(image!=null)cache.put(url,image);
            } finally {
                CopyOnWriteArrayList<WeakReference<ImageView>> listeners=pending.remove(url);
                if(image!=null && listeners!=null){
                    final Bitmap result=image;
                    main.post(()->{
                        for(WeakReference<ImageView> weak:listeners){
                            ImageView target=weak.get();
                            if(target!=null && url.equals(target.getTag()))target.setImageBitmap(result);
                        }
                    });
                }
            }
        }); }catch(RejectedExecutionException ignored){pending.remove(url);}
    }
    private Bitmap readLogo(String src) {
        HttpURLConnection conn=null;
        try {
            URI uri=new URI(src);
            if(!"https".equals(uri.getScheme()) || uri.getHost()==null || uri.getUserInfo()!=null)return null;
            conn=(HttpURLConnection)new URL(src).openConnection();
            conn.setConnectTimeout(4000);conn.setReadTimeout(4500);
            conn.setInstanceFollowRedirects(false);
            if(conn.getResponseCode()!=200)return null;
            String type=conn.getContentType();
            if(type==null || !type.toLowerCase(java.util.Locale.ROOT).startsWith("image/"))return null;
            if(conn.getContentLength()>512000)return null;
            try(InputStream stream=conn.getInputStream()) {
                ByteArrayOutputStream bytes=new ByteArrayOutputStream();
                byte[] buffer=new byte[8192];int n;
                while((n=stream.read(buffer))!=-1){
                    if(bytes.size()+n>512000)return null;
                    bytes.write(buffer,0,n);
                }
                byte[] data=bytes.toByteArray();
                BitmapFactory.Options opts=new BitmapFactory.Options();opts.inJustDecodeBounds=true;
                BitmapFactory.decodeByteArray(data,0,data.length,opts);
                if(opts.outWidth<1 || opts.outHeight<1 || opts.outWidth>4096 || opts.outHeight>4096)return null;
                opts.inJustDecodeBounds=false;
                opts.inSampleSize=Math.max(1,Math.max(opts.outWidth/128,opts.outHeight/128));
                return BitmapFactory.decodeByteArray(data,0,data.length,opts);
            }
        }catch(Exception ignored){return null;}
        finally {if(conn!=null)conn.disconnect();}
    }
    public void close(){workers.shutdownNow();pending.clear();cache.evictAll();}
}
