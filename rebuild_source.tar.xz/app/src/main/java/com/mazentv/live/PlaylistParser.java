package com.mazentv.live;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Pure Java parser: a channel M3U is NOT a media/HLS master playlist. */
public final class PlaylistParser {
    private static final Pattern ATTRIBUTE = Pattern.compile("([\\w-]+)\\s*=\\s*\"([^\"]*)\"");
    private PlaylistParser() {}

    public static List<Channel> parse(String source, int max) throws IOException {
        if (source == null || source.length() > 32_000_000) throw new IOException("Invalid playlist size");
        String trimmed = source.replace("\uFEFF", "").trim();
        if (!trimmed.startsWith("#EXTM3U") || trimmed.contains("#EXT-X-TARGETDURATION")
                || trimmed.contains("#EXT-X-STREAM-INF") || trimmed.contains("#EXT-X-MEDIA-SEQUENCE")) {
            throw new IOException("Not a channel M3U playlist");
        }
        ArrayList<Channel> result = new ArrayList<>();
        String name = null, group = "عام", logo = "", ua = null, referer = null;
        int limit = Math.min(30000, Math.max(1,max));
        try (BufferedReader reader = new BufferedReader(new StringReader(trimmed))) {
            String line;
            while ((line=reader.readLine()) != null && result.size() < limit) {
                line = line.trim();
                if (line.startsWith("#EXTINF:")) {
                    name = "قناة"; group = "عام"; logo = ""; ua = null; referer = null;
                    Matcher attr = ATTRIBUTE.matcher(line);
                    while (attr.find()) {
                        switch (attr.group(1).toLowerCase(java.util.Locale.ROOT)) {
                            case "tvg-name": name = attr.group(2); break;
                            case "tvg-logo": logo = attr.group(2); break;
                            case "group-title": group = attr.group(2); break;
                        }
                    }
                    boolean quoted=false;
                    for (int i=0; i<line.length(); i++) {
                        char c=line.charAt(i);
                        if (c=='"') quoted=!quoted;
                        else if (c==',' && !quoted) {
                            if (i+1<line.length() && !line.substring(i+1).trim().isEmpty()) name=line.substring(i+1).trim();
                            break;
                        }
                    }
                } else if (line.regionMatches(true,0,"#EXTVLCOPT:",0,11)) {
                    String opt=line.substring(11);
                    int equals=opt.indexOf('=');
                    if (equals > 0) {
                        String key=opt.substring(0,equals).toLowerCase(java.util.Locale.ROOT);
                        String value=opt.substring(equals+1).trim();
                        if (key.equals("http-user-agent")) ua=value;
                        if (key.equals("http-referrer") || key.equals("http-referer")) referer=value;
                    }
                } else if (!line.isEmpty() && !line.startsWith("#")) {
                    String endpoint=StreamAddress.attachHeaders(line,ua,referer);
                    if (StreamAddress.isMedia(endpoint)) result.add(new Channel(name,group,endpoint,logo));
                    name=null;group="عام";logo="";ua=null;referer=null;
                }
            }
        }
        return result;
    }
}
