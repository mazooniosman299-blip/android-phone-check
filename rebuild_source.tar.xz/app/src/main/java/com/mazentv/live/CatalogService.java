package com.mazentv.live;

import android.os.Handler;
import android.os.Looper;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

/** All network and database import operations off the UI thread; no destructive resync. */
public final class CatalogService {
    public interface Progress { void update(int finished,int total,int added,String message); }
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    private final ExecutorService downloaders=Executors.newFixedThreadPool(4);
    private static final class Result {
        final String source, message;
        final boolean attempted, ok;
        final int added;
        Result(String source, String message, boolean attempted, boolean ok, int added){
            this.source=source;this.message=message;this.attempted=attempted;this.ok=ok;this.added=added;
        }
    }
    private final Handler ui=new Handler(Looper.getMainLooper());
    private final AtomicBoolean running=new AtomicBoolean(false);
    private final ChannelStore store;
    public CatalogService(ChannelStore store) { this.store=store; }
    public boolean isRunning(){return running.get();}
    public void importCatalogs(List<String> urls, boolean force, Progress listener) {
        if(!running.compareAndSet(false,true))return;
        worker.execute(()->{
            int completed=0,added=0;
            try {
                java.util.concurrent.CompletionService<Result> completion=
                        new java.util.concurrent.ExecutorCompletionService<>(downloaders);
                int submitted=0;
                for(String url:urls) {
                    if(!CatalogIndex.isTrusted(url))continue;
                    submitted++;
                    completion.submit(()->{
                        if(!force && store.synchronizedCatalog(url))
                            return new Result(url,"موجود مسبقاً",false,true,0);
                        try {
                            List<Channel> channels=PlaylistParser.parse(download(url),30000);
                            if(channels.isEmpty())throw new IOException("No channels");
                            int inserted=store.addBatch(channels);
                            return new Result(url,"تمت مزامنة المصدر",true,true,inserted);
                        }catch(Exception error) {
                            return new Result(url,"تعذّر الاتصال بالمصدر",true,false,0);
                        }
                    });
                }
                for(int i=0;i<submitted;i++) {
                    Result result=completion.take().get();
                    if(result.attempted)store.catalogResult(result.source,result.ok);
                    completed++;added+=result.added;
                    int c=completed,a=added,total=submitted;
                    String msg=result.message;
                    ui.post(()->listener.update(c,total,a,msg));
                }
            }catch(Exception interrupted) {
                Thread.currentThread().interrupt();
            }finally{running.set(false);}
        });
    }
    public boolean importUserPlaylist(InputStream input, Progress listener) {
        if(!running.compareAndSet(false,true)) {
            try { input.close(); } catch(IOException ignored) {}
            return false;
        }
        worker.execute(()->{
            try(InputStream stream=input) {
                String text=readLimited(stream,32_000_000);
                List<Channel> parsed=PlaylistParser.parse(text,30000);
                int added=store.addBatch(parsed);
                ui.post(()->listener.update(1,1,added,"تم استيراد القائمة"));
            } catch(Exception e) {
                ui.post(()->listener.update(1,1,0,"تعذّر قراءة القائمة"));
            } finally {running.set(false);}
        });
        return true;
    }
    public void importRemotePlaylist(String url, Progress listener) {
        if(!running.compareAndSet(false,true))return;
        worker.execute(()->{
            try {
                String text=download(url);
                List<Channel> channels=PlaylistParser.parse(text,30000);
                int count=store.addBatch(channels);
                ui.post(()->listener.update(1,1,count,"تم استيراد المصدر"));
            } catch(Exception e) {
                ui.post(()->listener.update(1,1,0,"المصدر لا يوفّر قائمة صالحة"));
            } finally {running.set(false);}
        });
    }
    private static String download(String source) throws IOException {
        URL url=new URL(source);
        if(!"https".equalsIgnoreCase(url.getProtocol()))
            throw new IOException("Remote playlist must use encrypted HTTPS");
        HttpURLConnection conn=(HttpURLConnection)url.openConnection();
        try {
            conn.setConnectTimeout(9000);conn.setReadTimeout(16000);
            conn.setInstanceFollowRedirects(false);
            conn.setRequestProperty("Accept","application/x-mpegURL,application/vnd.apple.mpegurl,text/plain");
            int code=conn.getResponseCode();
            if(code!=200) throw new IOException("HTTP " +code);
            if(conn.getContentLengthLong()>32_000_000L)throw new IOException("Playlist too large");
            String mime=conn.getContentType();
            if(mime!=null && mime.toLowerCase(java.util.Locale.ROOT).contains("text/html"))
                throw new IOException("HTML instead of playlist");
            try(InputStream stream=conn.getInputStream()) {return readLimited(stream,32_000_000);}
        } finally {conn.disconnect();}
    }
    private static String readLimited(InputStream stream,int max) throws IOException {
        ByteArrayOutputStream bytes=new ByteArrayOutputStream();
        byte[] buffer=new byte[8192];int n;
        while((n=stream.read(buffer))!=-1){
            if(bytes.size()+n>max) throw new IOException("Playlist too large");
            bytes.write(buffer,0,n);
        }
        return new String(bytes.toByteArray(),StandardCharsets.UTF_8);
    }
    public void close(){downloaders.shutdownNow();worker.shutdownNow();}
    /** Called only on a background thread, after close(), to protect open database handles. */
    public boolean awaitStopped(long millis){
        try {
            long until=System.nanoTime()+java.util.concurrent.TimeUnit.MILLISECONDS.toNanos(millis);
            if(!worker.awaitTermination(millis,java.util.concurrent.TimeUnit.MILLISECONDS))return false;
            long remaining=java.util.concurrent.TimeUnit.NANOSECONDS.toMillis(until-System.nanoTime());
            return downloaders.awaitTermination(Math.max(0,remaining),java.util.concurrent.TimeUnit.MILLISECONDS);
        } catch(InterruptedException e){Thread.currentThread().interrupt();return false;}
    }
}
