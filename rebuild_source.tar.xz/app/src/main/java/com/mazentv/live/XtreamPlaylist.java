package com.mazentv.live;

import java.net.URI;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

/** Builds a playlist URL for a user-authorized Xtream provider. No login bypass. */
public final class XtreamPlaylist {
    private XtreamPlaylist() {}
    public static String buildUrl(String base,String username,String password) {
        if(base==null || username==null || password==null || username.trim().isEmpty() || password.trim().isEmpty()
                || username.length()>256 || password.length()>256) return null;
        try {
            String origin=base.trim().replaceAll("/+$","");
            URI uri=new URI(origin);
            if(!"https".equalsIgnoreCase(uri.getScheme())
                    || uri.getHost()==null || uri.getRawUserInfo()!=null
                    || uri.getRawQuery()!=null || uri.getRawFragment()!=null) return null;
            String path=uri.getPath();
            if(path!=null && (path.contains("..") || path.contains("\\")))return null;
            String result=origin+"/get.php?username="+encode(username)
                    +"&password="+encode(password)+"&type=m3u_plus&output=ts";
            return result;
        }catch(Exception e){return null;}
    }
    private static String encode(String value){try { return URLEncoder.encode(value,"UTF-8"); }
        catch(java.io.UnsupportedEncodingException e){throw new IllegalStateException(e);}}
}
