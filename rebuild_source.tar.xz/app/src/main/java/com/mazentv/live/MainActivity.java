package com.mazentv.live;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Toast;
import android.widget.Spinner;
import android.widget.TextView;
import android.text.Editable;
import android.text.TextWatcher;

import androidx.activity.ComponentActivity;
import androidx.media3.common.util.UnstableApi;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Collections;
import java.util.concurrent.atomic.AtomicLong;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/** New main screen: one reusable channel list with independent tabs, no networking on UI thread. */
@UnstableApi
public final class MainActivity extends ComponentActivity {
    private static final int BG=0xFF0C0D11, PANEL=0xFF1B202A, WHITE=0xFFF4F6FB;
    private static final int MUTED=0xFFAEB7C6, ACCENT=0xFF99E36C;
    private ChannelStore store;
    private LogoLoader logos;
    private Set<String> favoriteCache=new HashSet<>();
    /** Immutable data snapshot for filtering; no full-table queries on the UI thread. */
    private List<Channel> channelSnapshot=Collections.emptyList();
    private final AtomicLong snapshotGeneration=new AtomicLong();
    private CatalogService catalogs;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final List<Channel> displayed=new ArrayList<>();
    private final ChannelRows rows=new ChannelRows();
    private TextView headline, summary, progress;
    private EditText search;
    private ListView channelList;
    private LinearLayout topActions;
    private int currentTab=0;
    private String searchText="";
    private final Runnable delayedFilter=this::updateVisible;
    private ActivityResultLauncher<String[]> playlistPicker;
    private ActivityResultLauncher<String> backupSaver;
    private ActivityResultLauncher<String[]> backupRestorer;
    private final java.util.concurrent.ExecutorService diskWorker=java.util.concurrent.Executors.newSingleThreadExecutor();

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        store=new ChannelStore(this);
        logos=new LogoLoader();
        catalogs=new CatalogService(store);
        playlistPicker=registerForActivityResult(new ActivityResultContracts.OpenDocument(), uri->{
            if(uri==null)return;
            try {
                // Open the stream only when the import worker has been accepted.
                if(catalogs.isRunning()) {showStatus("عملية استيراد أخرى قيد التنفيذ");return;}
                java.io.InputStream input=getContentResolver().openInputStream(uri);
                if(input==null){showStatus("تعذّر فتح الملف");return;}
                if (catalogs.importUserPlaylist(input,this::onCatalogProgress)) {
                    showStatus("جاري قراءة قائمة القنوات...");
                } else {
                    showStatus("عملية استيراد أخرى قيد التنفيذ");
                }
            } catch(Exception e){showStatus("تعذّر فتح القائمة");}
        });
        backupSaver=registerForActivityResult(new ActivityResultContracts.CreateDocument("application/json"), uri->{
            if(uri==null)return;
            diskWorker.execute(()->{
                try(java.io.OutputStream stream=getContentResolver().openOutputStream(uri)) {
                    if(stream==null)throw new java.io.IOException("Cannot open file");
                    int n=BackupService.exportChannels(store,stream);
                    runOnUiThread(()->showStatus("تم حفظ "+n+" قناة"));
                }catch(Exception e){runOnUiThread(()->showStatus("تعذّر إنشاء النسخة الاحتياطية"));}
            });
        });
        backupRestorer=registerForActivityResult(new ActivityResultContracts.OpenDocument(), uri->{
            if(uri==null)return;
            diskWorker.execute(()->{
                try(java.io.InputStream stream=getContentResolver().openInputStream(uri)) {
                    if(stream==null)throw new java.io.IOException("Cannot read file");
                    int n=BackupService.importChannels(store,stream);
                    runOnUiThread(()->{showStatus("استعدنا القنوات؛ أضيف "+n);reloadChannels();});
                }catch(Exception e){runOnUiThread(()->showStatus("تعذّر استعادة النسخة الاحتياطية"));}
            });
        });
        buildScreen();
        diskWorker.execute(()->{
            store.migrateOldPreferences(getApplicationContext());
            int total=store.count();
            runOnUiThread(()->{
                if(isFinishing() || isDestroyed())return;
                reloadChannels();
                if(total<300 && !catalogs.isRunning()) {
                    showStatus("جاري استكمال دليل القنوات...");
                    catalogs.importCatalogs(CatalogIndex.full(),false,this::onCatalogProgress);
                }
            });
        });
    }
    private int dp(int v){return Math.round(v*getResources().getDisplayMetrics().density);}
    private GradientDrawable background(int color,int radius){
        GradientDrawable bg=new GradientDrawable();bg.setColor(color);bg.setCornerRadius(dp(radius));return bg;
    }
    private TextView text(String value,int sp,int color,boolean bold){
        TextView t=new TextView(this);t.setText(value);t.setTextColor(color);t.setTextSize(sp);
        t.setGravity(Gravity.CENTER_VERTICAL);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        return t;
    }
    private Button button(String label){
        Button b=new Button(this);b.setText(label);b.setTextColor(WHITE);b.setTextSize(13);
        b.setAllCaps(false);b.setBackground(background(PANEL,14));b.setMinHeight(0);b.setMinimumHeight(0);
        b.setPadding(dp(10),dp(8),dp(10),dp(8));return b;
    }
    private void buildScreen(){
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(BG);
        root.setPadding(dp(16),dp(12),dp(16),dp(8));
        // Android 15+ draws apps edge-to-edge. Apply safe system and cutout insets
        // rather than letting the navigation bar cover the bottom tab row.
        WindowCompat.setDecorFitsSystemWindows(getWindow(),false);
        ViewCompat.setOnApplyWindowInsetsListener(root,(view,insets)->{
            Insets safe=insets.getInsets(WindowInsetsCompat.Type.systemBars()
                    | WindowInsetsCompat.Type.displayCutout());
            root.setPadding(dp(16)+safe.left,dp(12)+safe.top,
                    dp(16)+safe.right,dp(8)+safe.bottom);
            return insets;
        });
        setContentView(root);
        headline=text("تلفازي LIVE",25,WHITE,true);root.addView(headline);
        TextView sub=text("قنواتك، في مشغّل تلفازي الأصلي",12,MUTED,false);
        LinearLayout.LayoutParams subLp=new LinearLayout.LayoutParams(-1,-2);subLp.bottomMargin=dp(14);root.addView(sub,subLp);

        topActions=new LinearLayout(this);topActions.setOrientation(LinearLayout.VERTICAL);
        root.addView(topActions,new LinearLayout.LayoutParams(-1,-2));
        summary=text("",13,MUTED,false);summary.setPadding(0,dp(8),0,dp(7));root.addView(summary);
        progress=text("",12,ACCENT,false);root.addView(progress);

        channelList=new ListView(this);channelList.setAdapter(rows);
        channelList.setDividerHeight(dp(8));channelList.setDivider(null);
        channelList.setCacheColorHint(Color.TRANSPARENT);channelList.setBackgroundColor(Color.TRANSPARENT);
        root.addView(channelList,new LinearLayout.LayoutParams(-1,0,1));
        channelList.setOnItemClickListener((parent,view,position,id)->{
            if(position<0 || position>=displayed.size())return;
            Channel channel=displayed.get(position);
            if(!StreamAddress.isMedia(channel.url)){showStatus("القناة لا تملك مصدر فيديو صالح");return;}
            Intent player=new Intent(this,PlayerActivity.class);
            player.putExtra("name",channel.name);player.putExtra("url",channel.url);
            ArrayList<String> candidates=new ArrayList<>(store.alternativeStreams(channel));
            player.putStringArrayListExtra("alternatives",candidates);
            startActivity(player);
        });
        LinearLayout nav=new LinearLayout(this);nav.setGravity(Gravity.CENTER);
        String[] tabs={"الرئيسية","القنوات","المفضلة","المصادر"};
        for(int i=0;i<tabs.length;i++){
            final int index=i;Button tab=button(tabs[i]);
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(48),1);
            if(i!=0)lp.leftMargin=dp(5);nav.addView(tab,lp);
            tab.setOnClickListener(v->switchTab(index));
        }
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.topMargin=dp(9);root.addView(nav,lp);
        switchTab(0);
    }
    private void switchTab(int index){
        currentTab=index;topActions.removeAllViews();
        if(index==0){
            headline.setText("تلفازي LIVE");
            TextView feature=text("استكشف القنوات المفتوحة واستكمل قائمتك بدون فقدان المفضلة",14,WHITE,true);
            feature.setPadding(dp(12),dp(13),dp(12),dp(13));feature.setBackground(background(PANEL,15));
            topActions.addView(feature,new LinearLayout.LayoutParams(-1,-2));
        } else if(index==3) {
            headline.setText("إدارة المصادر");
            Button sync=button("تحديث دليل القنوات بالكامل");sync.setOnClickListener(v->refreshCatalogs());
            topActions.addView(sync,new LinearLayout.LayoutParams(-1,dp(48)));
            Button importFile=button("استيراد قائمة M3U من ملف");
            LinearLayout.LayoutParams mlp=new LinearLayout.LayoutParams(-1,dp(48));mlp.topMargin=dp(8);
            topActions.addView(importFile,mlp);
            importFile.setOnClickListener(v->playlistPicker.launch(new String[]{"*/*"}));
            Button xtream=button("استيراد حساب Xtream مرخّص");
            LinearLayout.LayoutParams xlp=new LinearLayout.LayoutParams(-1,dp(48));xlp.topMargin=dp(8);
            topActions.addView(xtream,xlp);
            xtream.setOnClickListener(v->promptXtream());
            Button backup=button("حفظ نسخة احتياطية من القنوات والمفضلة");
            LinearLayout.LayoutParams blp=new LinearLayout.LayoutParams(-1,dp(48));blp.topMargin=dp(8);
            topActions.addView(backup,blp);
            backup.setOnClickListener(v->backupSaver.launch("tilfazi-channels-backup.json"));
            Button restore=button("استعادة نسخة احتياطية");
            LinearLayout.LayoutParams rlp=new LinearLayout.LayoutParams(-1,dp(48));rlp.topMargin=dp(8);
            topActions.addView(restore,rlp);
            restore.setOnClickListener(v->backupRestorer.launch(new String[]{"application/json","*/*"}));
            TextView help=text("المصادر الخارجية قد تتوقف أو تتطلب تصريحاً؛ الاستيراد لا يحذف أي قناة محفوظة.",13,MUTED,false);
            help.setPadding(0,dp(12),0,dp(10));topActions.addView(help);
        } else headline.setText(index==1?"كل القنوات":"المفضلة");
        if(index!=3){
            search=new EditText(this);search.setSingleLine(true);search.setTextSize(14);
            search.setTextColor(WHITE);search.setHintTextColor(MUTED);search.setHint("ابحث باسم القناة أو التصنيف");
            search.setBackground(background(PANEL,14));
            search.setPadding(dp(14),dp(10),dp(14),dp(10));
            LinearLayout.LayoutParams ep=new LinearLayout.LayoutParams(-1,dp(48));ep.topMargin=dp(10);
            topActions.addView(search,ep);
            search.setText(searchText);
            search.addTextChangedListener(new TextWatcher(){
                @Override public void beforeTextChanged(CharSequence s,int start,int count,int after){}
                @Override public void onTextChanged(CharSequence s,int start,int before,int count){
                    searchText=s.toString();handler.removeCallbacks(delayedFilter);handler.postDelayed(delayedFilter,150);
                }
                @Override public void afterTextChanged(Editable e){}
            });
        } else search=null;
        updateVisible();
    }
    private void showStatus(String msg){if(progress!=null)progress.setText(msg);}
    private void onCatalogProgress(int finished,int total,int added,String message){
        if(isFinishing() || isDestroyed())return;
        showStatus("المصادر "+finished+"/"+total+" • قنوات أضيفت: "+added);
        if(finished==total)showStatus("اكتملت محاولة تحديث الدليل؛ يتم تحديث القائمة...");
        if(finished==total || finished%4==0)reloadChannels();
    }
    private void promptXtream(){
        LinearLayout form=new LinearLayout(this);form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(dp(16),dp(8),dp(16),dp(8));
        EditText server=new EditText(this),username=new EditText(this),password=new EditText(this);
        server.setHint("https://provider.example:443");username.setHint("اسم المستخدم");password.setHint("كلمة المرور");
        password.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);
        form.addView(server);form.addView(username);form.addView(password);
        new android.app.AlertDialog.Builder(this).setTitle("حساب IPTV مصرح لك باستخدامه")
                .setView(form).setNegativeButton("إلغاء",null)
                .setPositiveButton("استيراد",(dialog,which)->{
                    String url=XtreamPlaylist.buildUrl(server.getText().toString(),
                            username.getText().toString(),password.getText().toString());
                    if(url==null){showStatus("بيانات المصدر غير صالحة");return;}
                    if(catalogs.isRunning()){showStatus("انتظر انتهاء الاستيراد الحالي");return;}
                    showStatus("جاري استيراد القنوات من حسابك...");
                    catalogs.importRemotePlaylist(url,this::onCatalogProgress);
                }).show();
    }
    private void refreshCatalogs(){
        if(catalogs.isRunning()){showStatus("تحديث جارٍ بالفعل");return;}
        showStatus("جاري فحص القوائم وتحديثها دون مسح بياناتك...");
        catalogs.importCatalogs(CatalogIndex.full(),true,this::onCatalogProgress);
    }
    private void reloadChannels(){
        if(store==null || diskWorker.isShutdown())return;
        long generation=snapshotGeneration.incrementAndGet();
        diskWorker.execute(()->{
            try {
                List<Channel> data=store.channels();
                Set<String> favs=store.favorites();
                runOnUiThread(()->{
                    if(isFinishing() || isDestroyed() || snapshotGeneration.get()!=generation)return;
                    channelSnapshot=data;
                    favoriteCache=favs;
                    updateVisible();
                });
            } catch (RuntimeException ignored) {
                runOnUiThread(()->{
                    if(!isFinishing() && !isDestroyed())showStatus("تعذّرت قراءة القنوات؛ أعد فتح التطبيق");
                });
            }
        });
    }
    private void updateVisible(){
        if(channelList==null)return;
        Set<String> fav=favoriteCache;
        displayed.clear();
        for(Channel c:channelSnapshot) {
            if(currentTab==2 && !fav.contains(c.url))continue;
            if(currentTab==3)continue;
            if(!c.matches(searchText))continue;
            displayed.add(c);
        }
        rows.notifyDataSetChanged();
        summary.setText("المحفوظة: "+channelSnapshot.size()+"   •   المعروضة: "+displayed.size());
        if(currentTab==3)summary.setText("إجمالي القنوات المحفوظة: "+channelSnapshot.size());
    }
    @Override protected void onResume(){super.onResume();if(store!=null)reloadChannels();}
    @Override protected void onDestroy(){
        handler.removeCallbacks(delayedFilter);
        snapshotGeneration.incrementAndGet();
        CatalogService importer=catalogs;
        if(importer!=null)importer.close();
        if(store!=null && !diskWorker.isShutdown()){
            diskWorker.execute(()->{
                // A catalog worker may be unwinding after cancellation. Avoid
                // closing SQLite while that worker holds an open transaction.
                if(importer==null || importer.awaitStopped(20_000))store.close();
            });
        }
        diskWorker.shutdown();
        if(logos!=null)logos.close();
        super.onDestroy();
    }
    private static final class RowHolder {
        ImageView logo;
        TextView title, group;
        Button favorite;
    }
    private final class ChannelRows extends BaseAdapter {
        @Override public int getCount(){return displayed.size();}
        @Override public Object getItem(int i){return displayed.get(i);}
        @Override public long getItemId(int i){return i;}
        @Override public View getView(int i,View recycled,ViewGroup parent){
            RowHolder holder;
            LinearLayout row;
            if(recycled instanceof LinearLayout && recycled.getTag() instanceof RowHolder){
                row=(LinearLayout)recycled;
                holder=(RowHolder)row.getTag();
            } else {
                row=new LinearLayout(MainActivity.this);row.setGravity(Gravity.CENTER_VERTICAL);
                row.setPadding(dp(12),dp(9),dp(12),dp(9));row.setBackground(background(PANEL,13));
                holder=new RowHolder();
                ImageView logo=new ImageView(MainActivity.this);
                logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
                row.addView(logo,new LinearLayout.LayoutParams(dp(46),dp(51)));
                holder.logo=logo;
                LinearLayout body=new LinearLayout(MainActivity.this);body.setOrientation(LinearLayout.VERTICAL);
                holder.title=text("",16,WHITE,true);holder.title.setSingleLine(true);
                holder.title.setEllipsize(android.text.TextUtils.TruncateAt.END);
                holder.group=text("",12,MUTED,false);
                body.addView(holder.title);body.addView(holder.group);
                LinearLayout.LayoutParams bodyLp=new LinearLayout.LayoutParams(0,-2,1);
                bodyLp.leftMargin=dp(9);row.addView(body,bodyLp);
                holder.favorite=button("♡");holder.favorite.setTextColor(ACCENT);holder.favorite.setTextSize(20);
                row.addView(holder.favorite,new LinearLayout.LayoutParams(dp(46),dp(42)));
                row.setTag(holder);
            }
            Channel channel=displayed.get(i);
            holder.title.setText(channel.name);
            holder.group.setText(channel.group);
            holder.favorite.setText(favoriteCache.contains(channel.url)?"♥":"♡");
            holder.favorite.setOnClickListener(v->{
                boolean wanted=!favoriteCache.contains(channel.url);
                if(wanted)favoriteCache.add(channel.url);
                else favoriteCache.remove(channel.url);
                if(currentTab==2)updateVisible();else rows.notifyDataSetChanged();
                diskWorker.execute(()->store.setFavorite(channel.url,wanted));
            });
            logos.load(holder.logo,channel.logo);
            return row;
        }
    }
}
