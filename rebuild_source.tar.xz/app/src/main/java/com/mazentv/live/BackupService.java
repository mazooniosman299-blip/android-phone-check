package com.mazentv.live;

import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/** User-owned backup, compatible with old Tilfazi JSON backups. */
public final class BackupService {
    private BackupService() {}
    public static int exportChannels(ChannelStore store,OutputStream output) throws Exception {
        List<Channel> data=store.channels();Set<String> favorites=store.favorites();
        output.write("{\"format\":\"tilfazi-backup-v1\",\"channels\":[".getBytes(StandardCharsets.UTF_8));
        int count=0;
        for(Channel ch:data){
            JSONObject row=new JSONObject();row.put("name",ch.name);row.put("group",ch.group);
            row.put("url",ch.url);row.put("logo",ch.logo);row.put("favorite",favorites.contains(ch.url));
            if(count>0)output.write(',');output.write(row.toString().getBytes(StandardCharsets.UTF_8));count++;
        }
        output.write("]}".getBytes(StandardCharsets.UTF_8));output.flush();return count;
    }
    public static int importChannels(ChannelStore store,InputStream input) throws Exception {
        ByteArrayOutputStream bytes=new ByteArrayOutputStream();byte[] chunk=new byte[8192];int size;
        while((size=input.read(chunk))!=-1){
            if(bytes.size()+size>32_000_000)throw new IOException("Backup too large");
            bytes.write(chunk,0,size);
        }
        JSONObject backup=new JSONObject(new String(bytes.toByteArray(),StandardCharsets.UTF_8));
        if(!"tilfazi-backup-v1".equals(backup.optString("format")))throw new IOException("Wrong backup type");
        JSONArray channelArray=backup.optJSONArray("channels");
        if(channelArray==null || channelArray.length()>30000)throw new IOException("Invalid backup length");
        ArrayList<Channel> all=new ArrayList<>();ArrayList<String> favoriteUrls=new ArrayList<>();
        for(int i=0;i<channelArray.length();i++){
            JSONObject row=channelArray.optJSONObject(i);if(row==null)continue;
            Channel channel=new Channel(row.optString("name"),row.optString("group"),
                    row.optString("url"),row.optString("logo"));
            if(!StreamAddress.isMedia(channel.url))continue;
            all.add(channel);if(row.optBoolean("favorite"))favoriteUrls.add(channel.url);
        }
        int added=store.addBatch(all);
        for(String url:favoriteUrls)store.setFavorite(url,true);
        return added;
    }
}
