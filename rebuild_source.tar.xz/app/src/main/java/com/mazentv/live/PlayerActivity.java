package com.mazentv.live;

import android.app.Activity;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.media3.common.C;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.common.Tracks;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.datasource.DefaultDataSource;
import androidx.media3.datasource.DefaultHttpDataSource;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory;
import androidx.media3.ui.AspectRatioFrameLayout;
import androidx.media3.ui.PlayerView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Native Media3 TV player. No WebView, third-party web player or link-opening logic. */
@UnstableApi
public final class PlayerActivity extends Activity {
    private static final int WHITE=0xFFF5F7FB, GLASS=0xC0151B27;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final List<String> candidates=new ArrayList<>();
    private PlayerView surface;
    private ExoPlayer player;
    private LinearLayout overlay;
    private TextView status;
    private int candidateIndex=0, mimeAttempt=0;
    private boolean zoom=false, firstFrame=false, hasAudio=false;
    private boolean retrying=false;
    private int quality=-1;

    private final Runnable fade=()->{if(overlay!=null)overlay.setVisibility(View.GONE);};
    private final Runnable timeout=()->{if(!firstFrame)nextCandidate("انتهى وقت انتظار الصورة");};
    private final Runnable checkAudio=()->{if(firstFrame && !hasAudio)nextCandidate("مسار الصوت غير موجود");};

    @Override protected void onCreate(Bundle state){
        super.onCreate(state);
        String primary=getIntent().getStringExtra("url");
        if(StreamAddress.isMedia(primary))candidates.add(primary);
        ArrayList<String> extra=getIntent().getStringArrayListExtra("alternatives");
        if(extra!=null)for(String e:extra)if(StreamAddress.isMedia(e)&&!candidates.contains(e)&&candidates.size()<8)candidates.add(e);
        if(candidates.isEmpty()){finish();return;}
        getWindow().setStatusBarColor(Color.BLACK);getWindow().setNavigationBarColor(Color.BLACK);
        createUi();
        enterImmersive();
    }
    private int dp(int v){return Math.round(v*getResources().getDisplayMetrics().density);}
    private GradientDrawable shade(){
        GradientDrawable d=new GradientDrawable();d.setColor(GLASS);d.setCornerRadius(dp(12));return d;
    }
    private Button control(String label){
        Button b=new Button(this);b.setText(label);b.setTextSize(14);b.setAllCaps(false);
        b.setTextColor(WHITE);b.setBackground(shade());b.setMinHeight(0);b.setMinimumHeight(0);
        b.setPadding(dp(9),dp(4),dp(9),dp(4));return b;
    }
    private void createUi(){
        FrameLayout root=new FrameLayout(this);root.setBackgroundColor(Color.BLACK);setContentView(root);
        surface=new PlayerView(this);
        surface.setUseController(false);
        surface.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_FIT); // Never crop content by default.
        surface.setKeepScreenOn(true);
        root.addView(surface,new FrameLayout.LayoutParams(-1,-1));
        surface.setOnClickListener(v->toggleOverlay());
        overlay=new LinearLayout(this);overlay.setOrientation(LinearLayout.HORIZONTAL);
        overlay.setGravity(Gravity.CENTER_VERTICAL);
        overlay.setPadding(dp(12),dp(6),dp(12),dp(6));
        Button back=control("‹");Button play=control("Ⅱ");Button qualityButton=control("HD");
        Button fit=control("▣");Button rotate=control("⛶");
        overlay.addView(back,new LinearLayout.LayoutParams(dp(48),dp(44)));
        overlay.addView(play,new LinearLayout.LayoutParams(dp(48),dp(44)));
        overlay.addView(qualityButton,new LinearLayout.LayoutParams(0,dp(44),1));
        overlay.addView(fit,new LinearLayout.LayoutParams(dp(48),dp(44)));
        overlay.addView(rotate,new LinearLayout.LayoutParams(dp(48),dp(44)));
        FrameLayout.LayoutParams top=new FrameLayout.LayoutParams(-1,dp(58),Gravity.TOP);
        root.addView(overlay,top);
        back.setOnClickListener(v->finish());
        play.setOnClickListener(v->{
            if(player!=null){if(player.isPlaying())player.pause();else player.play();}
            exposeControls();
        });
        fit.setOnClickListener(v->{
            zoom=!zoom;
            surface.setResizeMode(zoom?AspectRatioFrameLayout.RESIZE_MODE_ZOOM:AspectRatioFrameLayout.RESIZE_MODE_FIT);
            exposeControls();
        });
        rotate.setOnClickListener(v->{
            boolean landscape=getResources().getConfiguration().orientation==Configuration.ORIENTATION_LANDSCAPE;
            setRequestedOrientation(landscape?ActivityInfo.SCREEN_ORIENTATION_PORTRAIT:ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
            exposeControls();
        });
        qualityButton.setOnClickListener(v->showQualityDialog());
        status=new TextView(this);status.setTextSize(12);status.setTextColor(WHITE);
        status.setBackground(shade());status.setText("جاري الاتصال...");
        status.setPadding(dp(10),dp(7),dp(10),dp(7));
        FrameLayout.LayoutParams center=new FrameLayout.LayoutParams(-2,-2,Gravity.CENTER);
        root.addView(status,center);
    }
    private void showQualityDialog(){
        String[] labels={"تلقائي","1080p","720p","480p","360p"};
        int selected=quality<0?0:quality==1080?1:quality==720?2:quality==480?3:4;
        new android.app.AlertDialog.Builder(this).setTitle("جودة البث")
                .setSingleChoiceItems(labels,selected,(dialog,choice)->{
                    quality=choice==0?-1:choice==1?1080:choice==2?720:choice==3?480:360;
                    selectQuality();dialog.dismiss();exposeControls();
                }).setNegativeButton("إغلاق",null).show();
    }
    private void selectQuality(){
        if(player!=null) {
            int height=quality<0?Integer.MAX_VALUE:quality;
            int width=quality<0?Integer.MAX_VALUE:quality*16/9;
            player.setTrackSelectionParameters(player.getTrackSelectionParameters().buildUpon()
                    .setMaxVideoSize(width,height).build());
        }
    }
    private void toggleOverlay(){
        if(overlay.getVisibility()==View.VISIBLE)overlay.setVisibility(View.GONE);
        else exposeControls();
    }
    private void exposeControls(){
        if(overlay==null)return;
        overlay.setVisibility(View.VISIBLE);handler.removeCallbacks(fade);handler.postDelayed(fade,4500);
    }
    private void enterImmersive(){
        if(Build.VERSION.SDK_INT>=30){
            getWindow().setDecorFitsSystemWindows(false);
            WindowInsetsController controller=getWindow().getInsetsController();
            if(controller!=null){
                controller.hide(WindowInsets.Type.systemBars());
                controller.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            }
        } else {
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        }
    }
    @Override public void onConfigurationChanged(Configuration config){super.onConfigurationChanged(config);enterImmersive();}
    @Override protected void onStart(){super.onStart();if(surface!=null)startCandidate();}
    @Override protected void onStop(){releasePlayer();super.onStop();}
    @Override protected void onDestroy(){handler.removeCallbacksAndMessages(null);super.onDestroy();}
    private void releasePlayer(){
        handler.removeCallbacks(timeout);handler.removeCallbacks(checkAudio);
        if(surface!=null)surface.setPlayer(null);
        if(player!=null){player.release();player=null;}
    }
    private void startCandidate(){
        if(candidateIndex>=candidates.size()){
            status.setVisibility(View.VISIBLE);status.setText("البث غير متاح من المصادر الموجودة");return;
        }
        releasePlayer();
        StreamAddress endpoint=StreamAddress.parse(candidates.get(candidateIndex));
        if(endpoint==null){nextCandidate("مصدر غير صالح");return;}
        firstFrame=false;hasAudio=false;retrying=false;
        status.setVisibility(View.VISIBLE);status.setText("جاري الاتصال...");
        DefaultHttpDataSource.Factory http=new DefaultHttpDataSource.Factory()
                .setConnectTimeoutMs(9000).setReadTimeoutMs(14000)
                .setAllowCrossProtocolRedirects(false)
                .setDefaultRequestProperties(endpoint.headers);
        DefaultDataSource.Factory ds=new DefaultDataSource.Factory(this,http);
        player=new ExoPlayer.Builder(this)
                .setMediaSourceFactory(new DefaultMediaSourceFactory(ds)).build();
        surface.setPlayer(player);
        final ExoPlayer activePlayer=player;
        player.addListener(new Player.Listener(){
            private boolean current(){return player==activePlayer && !isFinishing() && !isDestroyed();}
            @Override public void onPlaybackStateChanged(int state){
                if(!current())return;
                if(state==Player.STATE_READY && firstFrame)status.setVisibility(View.GONE);
                if(state==Player.STATE_ENDED)nextCandidate("انتهى بث القناة");
            }
            @Override public void onRenderedFirstFrame(){
                if(!current())return;
                firstFrame=true;
                handler.removeCallbacks(timeout);
                handler.removeCallbacks(checkAudio);handler.postDelayed(checkAudio,7500);
                if(status!=null)status.setVisibility(View.GONE);
                // A frame proves video decoded; it does NOT prove sound, rights or perpetual availability.
            }
            @Override public void onTracksChanged(Tracks tracks){
                if(!current())return;
                hasAudio=tracks.isTypeSelected(C.TRACK_TYPE_AUDIO);
            }
            @Override public void onPlayerError(PlaybackException e){
                if(!current())return;
                // Never log signed URL tokens or user-supplied authorization headers.
                Log.w("TilfaziPlayback","source="+candidateIndex+" errorCode="+e.errorCode);
                // For extensionless streams only: retry the SAME authorized URL
                // using HLS/DASH on parser errors. HTTP 403 is not a MIME problem.
                boolean parserError=e.errorCode>=3000 && e.errorCode<4000;
                nextCandidate("تعذّر تشغيل المصدر",parserError);
            }
        });
        MediaItem.Builder item=new MediaItem.Builder().setUri(endpoint.url);
        String path=endpoint.url.toLowerCase(Locale.ROOT).split("\\?",2)[0];
        if(path.endsWith(".m3u8") || mimeAttempt==1)item.setMimeType(MimeTypes.APPLICATION_M3U8);
        else if(path.endsWith(".mpd") || mimeAttempt==2)item.setMimeType(MimeTypes.APPLICATION_MPD);
        player.setMediaItem(item.build());
        selectQuality();
        player.prepare();player.setPlayWhenReady(true);
        handler.postDelayed(timeout,25000);
        exposeControls();
    }
    private void nextCandidate(String reason) { nextCandidate(reason,false); }
    private void nextCandidate(String reason,boolean allowFormatRetry){
        if(retrying)return;retrying=true;
        handler.removeCallbacks(timeout);handler.removeCallbacks(checkAudio);
        boolean reused=false;
        if(allowFormatRetry && !firstFrame && candidateIndex<candidates.size()) {
            StreamAddress current=StreamAddress.parse(candidates.get(candidateIndex));
            if(current!=null) {
                String path=current.url.toLowerCase(Locale.ROOT).split("\\?",2)[0];
                if(!path.endsWith(".m3u8") && !path.endsWith(".mpd") && mimeAttempt<2) {
                    mimeAttempt++; reused=true;
                }
            }
        }
        if(!reused){candidateIndex++;mimeAttempt=0;}
        handler.post(()->{
            retrying=false;
            if(isFinishing() || isDestroyed())return;
            startCandidate();
        });
    }
}
