package com.mazentv.live;

import java.net.URI;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

/** Separates an actual media URL from optional, user-supplied M3U HTTP headers. */
public final class StreamAddress {
    public final String url;
    public final Map<String, String> headers;
    private StreamAddress(String url, Map<String, String> headers) {
        this.url = url;
        this.headers = Collections.unmodifiableMap(headers);
    }
    public static StreamAddress parse(String input) {
        if (input == null || input.length() > 8192) return null;
        String[] parts = input.trim().split("\\|", -1);
        if (parts.length > 2) return null;
        String url = parts[0].trim();
        try {
            URI uri = new URI(url);
            String scheme = uri.getScheme();
            if (!("http".equalsIgnoreCase(scheme) || "https".equalsIgnoreCase(scheme))
                    || uri.getHost() == null || uri.getRawUserInfo() != null
                    || uri.getRawFragment() != null) return null;
            String path = uri.getPath() == null ? "" : uri.getPath().toLowerCase(Locale.ROOT);
            String host=uri.getHost().toLowerCase(Locale.ROOT);
            if (path.endsWith(".m3u") || path.endsWith(".html") || path.endsWith(".htm")) return null;
            // A provider's public watch page is not a raw stream and must never
            // be handed to ExoPlayer. Extensionless authorized IPTV URLs remain valid.
            if (host.equals("starzplay.com") || host.equals("www.starzplay.com")
                    || host.equals("zee5.com") || host.equals("www.zee5.com")
                    || host.equals("dramalive.app") || host.equals("www.youtube.com")) return null;
        } catch (Exception invalid) { return null; }
        LinkedHashMap<String,String> headers = new LinkedHashMap<>();
        if (parts.length == 2) {
            if (parts[1].isEmpty()) return null;
            for (String token : parts[1].split("&")) {
                int equals = token.indexOf('=');
                if (equals < 1 || equals == token.length()-1) return null;
                String key;
                String value;
                try {
                    key = URLDecoder.decode(token.substring(0, equals).replace("+","%2B"), "UTF-8");
                    value = URLDecoder.decode(token.substring(equals + 1).replace("+","%2B"), "UTF-8");
                } catch (Exception invalid) { return null; }
                if (value.trim().isEmpty() || value.length() > 1024 || value.contains("\r") || value.contains("\n")) return null;
                switch (key.toLowerCase(Locale.ROOT)) {
                    case "user-agent": headers.put("User-Agent", value); break;
                    case "referer": case "referrer": headers.put("Referer", value); break;
                    case "origin": headers.put("Origin", value); break;
                    default: return null;
                }
            }
        }
        return new StreamAddress(url, headers);
    }
    public static boolean isMedia(String input) { return parse(input) != null; }
    public static String attachHeaders(String url, String agent, String referer) {
        if (parse(url) == null || url.contains("|")) return url;
        java.util.ArrayList<String> tokens = new java.util.ArrayList<>();
        if (agent != null && !agent.trim().isEmpty()) tokens.add("User-Agent="+encode(agent));
        if (referer != null && !referer.trim().isEmpty()) tokens.add("Referer="+encode(referer));
        if (tokens.isEmpty()) return url;
        return url + "|" + String.join("&", tokens);
    }
    private static String encode(String s) {
        try { return java.net.URLEncoder.encode(s, "UTF-8"); }
        catch (java.io.UnsupportedEncodingException e) { throw new IllegalStateException(e); }
    }
}
