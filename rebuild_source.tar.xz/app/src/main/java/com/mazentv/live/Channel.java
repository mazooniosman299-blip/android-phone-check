package com.mazentv.live;

import java.util.Locale;

/** Immutable channel metadata. The URL identifies a database row, not proof of playback. */
public final class Channel {
    public final String name, group, url, logo;
    public Channel(String name, String group, String url, String logo) {
        this.name = safe(name, "قناة");
        this.group = safe(group, "عام");
        this.url = url == null ? "" : url.trim();
        this.logo = logo == null ? "" : logo.trim();
    }
    private static String safe(String s, String fallback) {
        return s == null || s.trim().isEmpty() ? fallback : s.trim();
    }
    public boolean matches(String term) {
        String query = term == null ? "" : term.trim().toLowerCase(Locale.ROOT);
        return name.toLowerCase(Locale.ROOT).contains(query) || group.toLowerCase(Locale.ROOT).contains(query);
    }
}
