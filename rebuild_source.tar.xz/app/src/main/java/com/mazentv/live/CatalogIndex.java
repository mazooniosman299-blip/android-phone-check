package com.mazentv.live;

import java.util.Arrays;
import java.util.List;

/** Public playlist directory. Presence is not proof of playability or redistribution rights. */
public final class CatalogIndex {
    private static final String ROOT = "https://iptv-org.github.io/iptv/";
    private CatalogIndex() {}
    public static List<String> starter() {
        return Arrays.asList(ROOT+"languages/ara.m3u", ROOT+"countries/sd.m3u",
                ROOT+"countries/om.m3u", ROOT+"categories/kids.m3u",
                ROOT+"categories/animation.m3u", ROOT+"categories/sports.m3u");
    }
    public static List<String> full() {
        return Arrays.asList(ROOT+"languages/ara.m3u",ROOT+"countries/sd.m3u",
                ROOT+"countries/om.m3u", ROOT+"countries/sa.m3u",ROOT+"countries/ae.m3u",
                ROOT+"countries/eg.m3u", ROOT+"categories/kids.m3u",ROOT+"categories/animation.m3u",
                ROOT+"categories/sports.m3u",ROOT+"categories/news.m3u",
                ROOT+"categories/series.m3u", ROOT+"categories/entertainment.m3u",
                ROOT+"categories/documentary.m3u",ROOT+"categories/religious.m3u",
                ROOT+"categories/movies.m3u",ROOT+"index.m3u");
    }
    public static boolean isTrusted(String address) {
        try {
            java.net.URI uri = new java.net.URI(address);
            return uri.getScheme().equals("https") && uri.getHost().equals("iptv-org.github.io")
                    && uri.getPath().startsWith("/iptv/") && uri.getPath().endsWith(".m3u")
                    && uri.getRawUserInfo()==null && uri.getRawFragment()==null && uri.getRawQuery()==null;
        } catch (Exception e) {return false;}
    }
}
