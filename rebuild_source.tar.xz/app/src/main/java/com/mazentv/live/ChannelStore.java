package com.mazentv.live;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/** Reimplementation that keeps the exact old SQLite filename/table and favourites. */
public final class ChannelStore extends SQLiteOpenHelper {
    private static final int LIMIT=30000;
    private static final String DB="tilfazi_channels_v2.db";
    public ChannelStore(Context context) {
        super(context.getApplicationContext(),DB,null,2);
        getWritableDatabase();
        // Legacy JSON migration is run by the app background worker, never on the UI thread.
    }
    public synchronized void migrateOldPreferences(Context context) {
        android.content.SharedPreferences prefs=context.getSharedPreferences("tv_local_v1",Context.MODE_PRIVATE);
        if(!prefs.contains("channels") || prefs.getBoolean("v4_migration_done",false))return;
        try {
            org.json.JSONArray records=new org.json.JSONArray(prefs.getString("channels","[]"));
            ArrayList<Channel> imported=new ArrayList<>();
            for(int i=0;i<records.length() && i<LIMIT;i++) {
                org.json.JSONObject row=records.optJSONObject(i);
                if(row!=null) imported.add(new Channel(row.optString("name"),row.optString("group"),
                        row.optString("url"),row.optString("logo")));
            }
            addBatch(imported);
            // Do not erase the old preferences: they may be the only backup when
            // the 30K-channel capacity is reached. Verify migration before marking.
            boolean allPresent=true;
            SQLiteDatabase db=getReadableDatabase();
            for(Channel item:imported) {
                if(!StreamAddress.isMedia(item.url))continue;
                try(Cursor check=db.rawQuery("SELECT 1 FROM channel WHERE url=? LIMIT 1",new String[]{item.url})) {
                    if(!check.moveToFirst()) { allPresent=false; break; }
                }
            }
            if(!allPresent)return;
            for(String url:prefs.getStringSet("favorites",java.util.Collections.emptySet())) {
                setFavorite(url,true);
            }
            prefs.edit().putBoolean("v4_migration_done",true).apply();
        }catch(Exception ignored) { /* Leave data untouched for retry. */ }
    }
    @Override public void onConfigure(SQLiteDatabase db) { db.setForeignKeyConstraintsEnabled(true); }
    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE channel (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, grp TEXT NOT NULL, url TEXT UNIQUE NOT NULL, logo TEXT, favorite INTEGER NOT NULL DEFAULT 0)");
        db.execSQL("CREATE INDEX idx_channel_grp ON channel(grp)");
        createCatalogTable(db);
    }
    private void createCatalogTable(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE IF NOT EXISTS catalog_sync (url TEXT PRIMARY KEY NOT NULL, success_at INTEGER NOT NULL DEFAULT 0, error_at INTEGER NOT NULL DEFAULT 0)");
    }
    @Override public void onUpgrade(SQLiteDatabase db,int oldVersion,int newVersion) {
        if (oldVersion<2) createCatalogTable(db); // NEVER DROP the user's channel table.
    }
    public synchronized int count() {
        try(Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM channel",null)) {
            return c.moveToFirst()?c.getInt(0):0;
        }
    }
    public synchronized List<Channel> channels() {
        ArrayList<Channel> out=new ArrayList<>();
        try(Cursor c=getReadableDatabase().rawQuery("SELECT name,grp,url,logo FROM channel ORDER BY id DESC",null)) {
            while(c.moveToNext()) out.add(new Channel(c.getString(0),c.getString(1),c.getString(2),c.getString(3)));
        }
        return out;
    }
    public synchronized Set<String> favorites() {
        HashSet<String> values=new HashSet<>();
        try(Cursor c=getReadableDatabase().rawQuery("SELECT url FROM channel WHERE favorite=1",null)) {
            while(c.moveToNext()) values.add(c.getString(0));
        }
        return values;
    }
    public synchronized void setFavorite(String url,boolean value) {
        ContentValues values=new ContentValues();values.put("favorite",value?1:0);
        getWritableDatabase().update("channel",values,"url=?",new String[]{url});
    }
    public synchronized void toggleFavorite(String url) {
        getWritableDatabase().execSQL("UPDATE channel SET favorite=1-favorite WHERE url=?", new Object[]{url});
    }
    public synchronized int addBatch(List<Channel> data) {
        SQLiteDatabase db=getWritableDatabase();
        int count=0;
        db.beginTransaction();
        try {
            int existing=count();
            for(Channel ch:data) {
                if (existing>=LIMIT) break;
                if(!StreamAddress.isMedia(ch.url)) continue;
                ContentValues values=new ContentValues();
                values.put("name",ch.name);values.put("grp",ch.group);
                values.put("url",ch.url);values.put("logo",ch.logo);
                long id=db.insertWithOnConflict("channel",null,values,SQLiteDatabase.CONFLICT_IGNORE);
                if (id>=0) { count++; existing++; }
            }
            db.setTransactionSuccessful();
        } finally {db.endTransaction();}
        return count;
    }
    public synchronized List<String> alternativeStreams(Channel chosen) {
        // Match exact channel name only; never substitute similarly named but unrelated services.
        ArrayList<String> result=new ArrayList<>();
        try(Cursor c=getReadableDatabase().rawQuery(
                "SELECT url FROM channel WHERE name = ? COLLATE NOCASE AND url != ? ORDER BY id DESC LIMIT 6",
                new String[]{chosen.name,chosen.url})) {
            while(c.moveToNext()) {
                String url=c.getString(0);
                if(StreamAddress.isMedia(url)) result.add(url);
            }
        }
        return result;
    }
    public synchronized boolean synchronizedCatalog(String source) {
        try(Cursor c=getReadableDatabase().rawQuery("SELECT success_at FROM catalog_sync WHERE url=?",new String[]{source})) {
            return c.moveToFirst() && c.getLong(0)>0;
        }
    }
    public synchronized void catalogResult(String source,boolean success) {
        SQLiteDatabase db=getWritableDatabase();
        ContentValues row=new ContentValues();row.put("url",source);
        row.put(success?"success_at":"error_at",System.currentTimeMillis());
        // Prior successful sync must not be replaced by a transient connection failure.
        db.insertWithOnConflict("catalog_sync",null,row,SQLiteDatabase.CONFLICT_IGNORE);
        db.update("catalog_sync",row,"url=?",new String[]{source});
    }
}
