# تلفازي LIVE — 3.0.0 / 2026 Redesign

An original Android Java / Media3 television-stream browser. This is a *source project*, not a streaming-service licence or a promise that any particular channel is available.

## Full interface redesign

- **Home:** completely new editorial hero, last-played shortcut, discovery chips, featured channel tiles.
- **Channels:** searchable two-column channel grid (more columns on larger displays), category filters, LIVE badges and channel images.
- **Favorites:** dedicated screen with persistent favorites.
- **More:** import playlist URL, import local M3U, add channel manually, browse source catalogs, visit broadcaster websites; the unwanted URL/file/official toolbar no longer appears on the main viewing screen.
- **Navigation:** persistent four-tab native navigation (Home / Channels / Favorites / More), with new vector icons.
- **TV player:** overlays instead of a fixed header/footer, proper immersive landscape mode, tap to reveal controls, auto-hide, full-bleed zoom vs fit, adaptive stream-quality caps. There is no retry button.
- **Artwork:** optional bounded HTTPS logo loading and local in-memory cache. App remains usable if a logo fails.

## Channels

The app draws from publicly listed third-party URLs at iptv-org.github.io/iptv, on startup, including Arabic, Sudan, Oman, kids, animation, Saudi Arabia, UAE, Egypt, entertainment and news. These are not broadcaster-licenced streaming integrations. Imported streams may disappear, be geoblocked, have copyright restrictions or require subscriptions. Broadcaster websites may open in the browser. MBC/Alwan are not guaranteed or advertised as available unless an authorised working source is provided.

## Testing

`sh tests/run_all.sh` runs offline parser, catalog, Java parsing and XML/manifest consistency checks. Java syntax checks are strict; parsing diagnostics cause failure. **Offline tests cannot prove an APK compiles or channels stream.** Build on GitHub Actions using `.github/workflows/build-apk.yml`, verify the APK signing and run Android lint. Physical phone full-screen and network testing remains a separate step.

## Build

Requires JDK 17, Android SDK 36 and Gradle 8.13. Use `gradle :app:assembleDebug` on a configured machine or build through GitHub Actions. Debug-key signatures may change between CI runs. For publication, sign a release with a persistent private keystore. Do not use a CI debug keystore as a production signature.

## Privacy

The app saves channels, favorites and the last viewed channel locally. It fetches stream URLs and optional logos from their respective remote providers. There is no project analytics account or custom user tracking server.
