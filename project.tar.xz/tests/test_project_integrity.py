#!/usr/bin/env python3
"""Offline consistency tests, not an Android SDK build."""
from pathlib import Path
import xml.etree.ElementTree as ET
import re

project = Path(__file__).resolve().parents[1]
for f in project.rglob('*.xml'):
    ET.parse(f)
print('PASS valid XML:', len(list(project.rglob('*.xml'))))

manifest = ET.parse(project / 'app/src/main/AndroidManifest.xml').getroot()
ns = '{http://schemas.android.com/apk/res/android}'
perms = {p.attrib.get(ns + 'name') for p in manifest.findall('uses-permission')}
assert 'android.permission.INTERNET' in perms
assert 'android.permission.ACCESS_NETWORK_STATE' in perms
assert 'android.permission.READ_EXTERNAL_STORAGE' not in perms

build = (project / 'app/build.gradle').read_text()
assert re.search(r"targetSdk 35", build)
assert re.search(r"versionName '3.2.0'", build)
assert 'media3-exoplayer-hls' in build and 'media3-exoplayer-dash' in build

main_source = (project / 'app/src/main/java/com/mazentv/live/MainActivity.java').read_text()
assert 'bootstrapDefaultCatalogs()' in main_source
assert 'showQuickActions()' in main_source
assert 'showCatalog()' in main_source
assert 'showOfficialSources()' not in main_source
for marker in ('TAB_HOME', 'TAB_CHANNELS', 'TAB_FAVORITES', 'TAB_MORE', 'renderHome()', 'renderChannels(', 'renderMore()', 'LogoLoader', 'GridView'):
    assert marker in main_source, marker
assert 'favoritesOnly' not in main_source

player_source = (project / 'app/src/main/java/com/mazentv/live/PlayerActivity.java').read_text()
assert 'إعادة المحاولة' not in player_source
assert 'chooseQuality()' in player_source
assert 'changeOrientation()' in player_source
assert 'setUseController(false)' in player_source
assert 'RESIZE_MODE_FIT' in player_source
assert 'RESIZE_MODE_ZOOM' not in player_source
assert 'bottomControls' not in player_source
assert 'fitButton' not in player_source
assert 'setAutoShow(' not in player_source

catalog_source = (project / 'app/src/main/java/com/mazentv/live/CatalogSources.java').read_text()
assert 'categories/kids' in catalog_source
assert 'categories/animation' in catalog_source
assert 'categories/sports' in catalog_source
assert 'categories/series' in catalog_source
assert 'ZEE_ALWAN_HLS' in main_source
assert 'addRequestedChannels()' in main_source
assert 'openProvider(' not in main_source
assert 'BEIN_TOD_URL' not in main_source
assert 'partnerRow' not in main_source
assert 'شاهد الآن' not in main_source
assert 'categories/entertainment' in catalog_source
assert 'countries/sd' in catalog_source
assert 'countries/om' in catalog_source
assert (project / '.github/workflows/build-apk.yml').exists()
print('PASS Android manifest, dependencies, modern player UI, startup catalogs and CI checks')
