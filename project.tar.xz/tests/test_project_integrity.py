#!/usr/bin/env python3
"""Offline consistency tests, not an Android SDK build."""
from pathlib import Path
import xml.etree.ElementTree as ET
import re

project = Path(__file__).resolve().parents[1]
for f in project.rglob('*.xml'):
    ET.parse(f)
print('PASS valid XML:', len(list(project.rglob('*.xml'))))

manifest = ET.parse(project / 'app/src/main/AndroidManifest.xml').getroot()
ns = '{http://schemas.android.com/apk/res/android}'
perms = {p.attrib.get(ns + 'name') for p in manifest.findall('uses-permission')}
assert 'android.permission.INTERNET' in perms
assert 'android.permission.ACCESS_NETWORK_STATE' in perms
assert 'android.permission.READ_EXTERNAL_STORAGE' not in perms

build = (project / 'app/build.gradle').read_text()
assert re.search(r"targetSdk 35", build)
assert re.search(r"versionName '3.4.3'", build)
assert 'media3-exoplayer-hls' in build and 'media3-exoplayer-dash' in build

main_source = (project / 'app/src/main/java/com/mazentv/live/MainActivity.java').read_text()
assert 'bootstrapDefaultCatalogs()' in main_source
assert 'bootstrapDefaultCatalogs(false)' in main_source
assert 'CatalogRefreshPolicy.shouldFetch(' in main_source
assert 'if (pending.isEmpty())' in main_source
assert 'catalogs_3_2' not in main_source
assert 'المعروض ' in main_source
assert 'showQuickActions()' in main_source
assert 'ChannelBackup.write(output, repo)' in main_source
assert 'ChannelBackup.restore(in, repo)' in main_source
assert 'sources.sort((left, right)' in main_source
assert 'i.putExtra("channel_url", channel.url)' in main_source
assert (project / 'app/src/main/java/com/mazentv/live/ChannelBackup.java').exists()
assert 'showCatalog()' in main_source
assert 'CatalogRefreshPolicy.needsIndexRecovery(repo.size())' in main_source
assert 'pending.add(0, fullIndex)' in main_source
assert 'showOfficialSources()' not in main_source
for marker in ('TAB_HOME', 'TAB_CHANNELS', 'TAB_FAVORITES', 'TAB_MORE', 'renderHome()', 'renderChannels(', 'renderMore()', 'LogoLoader', 'GridView'):
    assert marker in main_source, marker
assert 'favoritesOnly' not in main_source
# Playback badges are evidence-based: only a rendered first frame earns LIVE.
assert '"● مباشر"' in main_source
assert 'if (observed == PlaybackHealth.PLAYED)' in main_source
assert 'ChannelFallbacks.alternatives(channel, repo.all())' in main_source
assert 'if(playbackHealth.state(c.url)==PlaybackHealth.FAILED)continue;' not in main_source
assert 'فشل مؤخراً' not in main_source


player_source = (project / 'app/src/main/java/com/mazentv/live/PlayerActivity.java').read_text()
assert 'إعادة المحاولة' not in player_source
assert 'chooseQuality()' in player_source
assert 'changeOrientation()' in player_source
assert 'setUseController(false)' in player_source
assert 'RESIZE_MODE_FIT' in player_source
assert 'RESIZE_MODE_ZOOM' not in player_source
assert 'String selectedChannelUrl = getIntent().getStringExtra("channel_url")' in player_source
assert 'bufferingTimeout' in player_source
assert 'sourceSwitchPending' in player_source and 'if (player == null || sourceSwitchPending) return;' in player_source
assert 'bottomControls' not in player_source
assert 'fitButton' not in player_source
assert 'setAutoShow(' not in player_source

catalog_source = (project / 'app/src/main/java/com/mazentv/live/CatalogSources.java').read_text()
assert 'categories/kids' in catalog_source
assert 'categories/animation' in catalog_source
assert 'categories/sports' in catalog_source
assert 'categories/series' in catalog_source
assert 'ensureZeeAlwanListed()' in main_source
# A real Zee Alwan HLS/DASH source must open in Media3, not a webpage.
assert 'ZeeAlwanSource.nativeAlternatives(c, repo.all())' in main_source
assert 'askForZeeSource(c)' in main_source
assert 'startActivity(new Intent(this, ZeeAlwanActivity.class))' not in main_source
assert 'ZeeAlwanResolver.findAvailable' not in main_source
assert (project / 'app/src/main/java/com/mazentv/live/ZeeAlwanActivity.java').exists()
assert 'WebView' in (project / 'app/src/main/java/com/mazentv/live/ZeeAlwanActivity.java').read_text()
assert 'ZeeAlwanSource.ZEE5_LIVE_PAGE' in (project / 'app/src/main/java/com/mazentv/live/ZeeAlwanActivity.java').read_text()
assert "p.indexOf('/watch/movies/zee-alwan/')" in (project / 'app/src/main/java/com/mazentv/live/ZeeAlwanActivity.java').read_text()
zee_activity = (project / 'app/src/main/java/com/mazentv/live/ZeeAlwanActivity.java').read_text()
assert 'NetworkCapabilities.TRANSPORT_VPN' in zee_activity
assert 'registerDefaultNetworkCallback' in zee_activity
assert 'restartOfficialPlayback()' in zee_activity
assert 'Math.abs(current - previousVideoPosition) >= 0.9' in zee_activity
assert 'unregisterNetworkCallback' in zee_activity
assert 'ZeeAlwanActivity' in str(manifest.attrib) or 'ZeeAlwanActivity' in (project / 'app/src/main/AndroidManifest.xml').read_text()
assert 'قنوات طلبتها' not in main_source
assert 'addZeeAlwanTile' not in main_source
assert 'openProvider(' not in main_source
assert 'BEIN_TOD_URL' not in main_source
assert 'partnerRow' not in main_source
assert 'شاهد الآن' not in main_source
assert 'categories/entertainment' in catalog_source
assert 'countries/sd' in catalog_source
assert 'countries/om' in catalog_source
assert (project / '.github/workflows/build-apk.yml').exists()
print('PASS Android manifest, dependencies, modern player UI, startup catalogs and CI checks')
