#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
mkdir -p /tmp/tilfazi-zee-test
javac -d /tmp/tilfazi-zee-test app/src/main/java/com/mazentv/live/Channel.java app/src/main/java/com/mazentv/live/ChannelFallbacks.java app/src/main/java/com/mazentv/live/ZeeAlwanSource.java tests/ZeeAlwanSourceTest.java
java -cp /tmp/tilfazi-zee-test ZeeAlwanSourceTest
