import javax.tools.JavaCompiler;
import javax.tools.JavaFileObject;
import javax.tools.StandardJavaFileManager;
import javax.tools.ToolProvider;
import com.sun.source.util.JavacTask;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

public final class SyntaxCheck {
    public static void main(String[] args) throws Exception {
        JavaCompiler compiler = ToolProvider.getSystemJavaCompiler();
        if (compiler == null) throw new RuntimeException("JDK compiler missing");
        List<File> files = new ArrayList<>();
        for (String path: args) files.add(new File(path));
        try (StandardJavaFileManager manager = compiler.getStandardFileManager(null, null, null)) {
            Iterable<? extends JavaFileObject> source = manager.getJavaFileObjectsFromFiles(files);
            JavacTask task = (JavacTask) compiler.getTask(null, manager, null,
                java.util.Arrays.asList("-encoding", "UTF-8", "-proc:none"), null, source);
            int count = 0;
            for (com.sun.source.tree.CompilationUnitTree ignored : task.parse()) count++;
            if (count != files.size()) throw new AssertionError("Incomplete parse");
            System.out.println("PASS Java syntax parse: " + count + " source files");
        }
    }
}
