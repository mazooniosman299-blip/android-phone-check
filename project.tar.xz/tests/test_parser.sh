#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
mkdir -p /tmp/tilfazi-parser-test
javac -encoding UTF-8 -d /tmp/tilfazi-parser-test \
  app/src/main/java/com/mazentv/live/Channel.java \
  app/src/main/java/com/mazentv/live/M3uParser.java \
  tests/M3uParserTest.java
java -cp /tmp/tilfazi-parser-test M3uParserTest
