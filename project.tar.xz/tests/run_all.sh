#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
sh tests/test_parser.sh
sh tests/test_fallbacks.sh
sh tests/test_catalog.sh
sh tests/test_zee.sh
sh tests/test_syntax.sh
python3 tests/test_project_integrity.py
