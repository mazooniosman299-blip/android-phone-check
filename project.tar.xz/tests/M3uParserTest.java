import com.mazentv.live.Channel;
import com.mazentv.live.M3uParser;
import java.util.List;

public class M3uParserTest {
    private static void check(boolean value, String label) {
        if (!value) throw new AssertionError(label);
    }
    public static void main(String[] args) throws Exception {
        String test = "\uFEFF#EXTM3U\n#EXTINF:-1 tvg-name=\"Fallback\" group-title=\"أخبار\" tvg-logo=\"https://image.example/a.png\",العربية\n"
                + "https://example.org/1.m3u8\n#EXTINF:-1,قناة ثانية\nhttps://example.org/second.mpd\n"
                + "#EXTINF:-1,رابط فاسد\nfile:///etc/passwd\n"
                + "#EXTINF:-1,HTTP\nhttp://test.example/3.ts\n";
        List<Channel> all = M3uParser.parse(test, 50);
        check(all.size() == 3, "Number of parsed valid channels");
        check("العربية".equals(all.get(0).name), "Arabic name parsed");
        check("أخبار".equals(all.get(0).group), "Group parsed");
        check("https://image.example/a.png".equals(all.get(0).logo), "Logo parsed");
        check("قناة ثانية".equals(all.get(1).name), "Second channel");
        check("عام".equals(all.get(1).group), "No stale categories");
        check(all.size() == M3uParser.parse(test, 3).size(), "limit check");
        check(M3uParser.parse(test, 1).size() == 1, "Single item cap");
        check(M3uParser.parse("#EXTM3U\n#EXTINF:-1,broken\njavascript:alert(1)", 10).isEmpty(), "Reject JS URLs");
        check(!Channel.isValidStreamUrl("https://user:pass@example.com/x.m3u8"), "Reject credentials in URL");
        check(!Channel.isValidStreamUrl("https://"), "Reject invalid URL");
        check(!Channel.isValidStreamUrl("ftp://example.com/stream"), "Reject FTP");
        check(Channel.isValidStreamUrl("https://example.com/live.m3u8?token=abc"), "Accept HLS with token");
        String noMetadata = "https://example.org/a.m3u8\nhttps://example.org/b.m3u8\n";
        check(M3uParser.parse(noMetadata, 10).size() == 2, "M3U without metadata");
        System.out.println("PASS 13 M3U parser and URL checks");
    }
}
