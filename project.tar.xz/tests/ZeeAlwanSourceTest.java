import com.mazentv.live.ZeeAlwanSource;
import com.mazentv.live.Channel;
import java.util.Arrays;
import java.util.List;

public final class ZeeAlwanSourceTest {
    public static void main(String[] args) {
        if (!ZeeAlwanSource.matches("ZEE Alwan – زي ألوان")) throw new AssertionError("Arabic/English matching failed");
        if (!ZeeAlwanSource.matches("زي الوان")) throw new AssertionError("Unaccented Arabic matching failed");
        if (ZeeAlwanSource.matches("ZEE Aflam")) throw new AssertionError("Wrong channel matched");
        if (!ZeeAlwanSource.isLiveManifest("#EXTM3U\n#EXT-X-TARGETDURATION:5\n#EXTINF:5,\nseg.ts"))
            throw new AssertionError("Live media playlist rejected");
        if (!ZeeAlwanSource.isLiveManifest("#EXTM3U\n#EXT-X-STREAM-INF:BANDWIDTH=123\nvariant.m3u8"))
            throw new AssertionError("Live master playlist rejected");
        if (ZeeAlwanSource.isLiveManifest("#EXTM3U\n#EXTINF:-1,TV\nhttps://example.com/stream.m3u8"))
            throw new AssertionError("Channel directory incorrectly accepted as video");
        if (ZeeAlwanSource.isLiveManifest("<html>403 forbidden</html>"))
            throw new AssertionError("HTML error incorrectly accepted as video");
        if (!ZeeAlwanSource.OFFICIAL_FREE_PAGE.startsWith("https://starzplay.com/ar/movies/zee-alwan/")) throw new AssertionError("Official free channel page missing");
        if (!ZeeAlwanSource.OFFICIAL_WATCH_PAGE.contains("/ar/watch/movies/zee-alwan/")) throw new AssertionError("Direct watch route missing");
        if (!ZeeAlwanSource.isDirectMediaUrl("https://video.example/zee/live.m3u8?token=valid"))
            throw new AssertionError("Authorized HLS stream rejected");
        if (!ZeeAlwanSource.isDirectMediaUrl("https://video.example/zee/live.MPD"))
            throw new AssertionError("DASH stream rejected");
        if (ZeeAlwanSource.isDirectMediaUrl(ZeeAlwanSource.CHANNEL_ID))
            throw new AssertionError("IPTV catalog entry is not an HLS stream");
        if (ZeeAlwanSource.isDirectMediaUrl(ZeeAlwanSource.OFFICIAL_WATCH_PAGE))
            throw new AssertionError("Do not open provider website through native player");
        if (ZeeAlwanSource.isDirectMediaUrl(ZeeAlwanSource.OLD_DEAD_URL))
            throw new AssertionError("Old 404 HLS source must not be retried");
        Channel placeholder = new Channel("ZEE Alwan - زي ألوان","مسلسلات",ZeeAlwanSource.CHANNEL_ID,"");
        Channel direct = new Channel("ZEE Alwan HD","مسلسلات","https://video.example/zee/live.m3u8","");
        Channel wrong = new Channel("ZEE Aflam","أفلام","https://video.example/aflam.m3u8","");
        List<String> nativeUrls = ZeeAlwanSource.nativeAlternatives(placeholder,Arrays.asList(placeholder, direct, wrong));
        if (nativeUrls.size()!=1 || !nativeUrls.get(0).equals(direct.url))
            throw new AssertionError("Placeholder must discover only same-channel native media");
        System.out.println("PASS Zee Alwan identity, native stream routing and official source guards: 15");
    }
}
