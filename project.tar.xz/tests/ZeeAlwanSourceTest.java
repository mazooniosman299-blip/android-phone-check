import com.mazentv.live.ZeeAlwanSource;

public final class ZeeAlwanSourceTest {
    public static void main(String[] args) {
        if (!ZeeAlwanSource.matches("ZEE Alwan – زي ألوان")) throw new AssertionError("Arabic/English matching failed");
        if (!ZeeAlwanSource.matches("زي الوان")) throw new AssertionError("Unaccented Arabic matching failed");
        if (ZeeAlwanSource.matches("ZEE Aflam")) throw new AssertionError("Wrong channel matched");
        if (!ZeeAlwanSource.isLiveManifest("#EXTM3U\n#EXT-X-TARGETDURATION:5\n#EXTINF:5,\nseg.ts"))
            throw new AssertionError("Live media playlist rejected");
        if (!ZeeAlwanSource.isLiveManifest("#EXTM3U\n#EXT-X-STREAM-INF:BANDWIDTH=123\nvariant.m3u8"))
            throw new AssertionError("Live master playlist rejected");
        if (ZeeAlwanSource.isLiveManifest("#EXTM3U\n#EXTINF:-1,TV\nhttps://example.com/stream.m3u8"))
            throw new AssertionError("Channel directory incorrectly accepted as video");
        if (ZeeAlwanSource.isLiveManifest("<html>403 forbidden</html>"))
            throw new AssertionError("HTML error incorrectly accepted as video");
        if (!ZeeAlwanSource.OFFICIAL_FREE_PAGE.startsWith("https://starzplay.com/ar/movies/zee-alwan/")) throw new AssertionError("Official free channel page missing");
        System.out.println("PASS Zee Alwan channel identity and official provider checks: 8");
    }
}
