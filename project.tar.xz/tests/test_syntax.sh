#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
mkdir -p /tmp/tilfazi-syntax
javac -d /tmp/tilfazi-syntax tests/SyntaxCheck.java
java -cp /tmp/tilfazi-syntax SyntaxCheck \
  app/src/main/java/com/mazentv/live/CatalogSources.java \
  app/src/main/java/com/mazentv/live/Channel.java \
  app/src/main/java/com/mazentv/live/M3uParser.java \
  app/src/main/java/com/mazentv/live/ChannelRepository.java \
  app/src/main/java/com/mazentv/live/MainActivity.java \
  app/src/main/java/com/mazentv/live/LogoLoader.java \
  app/src/main/java/com/mazentv/live/PlayerActivity.java \
  app/src/main/java/com/mazentv/live/ZeeAlwanSource.java \
  app/src/main/java/com/mazentv/live/ZeeAlwanActivity.java
