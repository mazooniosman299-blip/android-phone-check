"""Regression test for the published APK upgrade-compatibility guard."""
from pathlib import Path
import sys
import tempfile
import struct
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'tools'))
from apk_identity import _length8, _length16

assert _length8(bytes([5]), 0) == (5, 1)
assert _length8(bytes([0x81, 0x03]), 0) == (259, 2)
assert _length16(struct.pack('<H', 34), 0) == (34, 2)
assert _length16(struct.pack('<HH', 0x8001, 7), 0) == (65543, 4)
source = (Path(__file__).resolve().parents[1] / 'tools' / 'check_apk_upgrade.py').read_text()
for marker in ['old_package != new_package', 'new_version <= old_version', 'old_cert != new_cert']:
    assert marker in source, marker
pin = (Path(__file__).resolve().parents[1] / 'tools' / 'release_signer_sha256.txt').read_text().strip()
assert len(pin) == 64 and all(c in '0123456789ABCDEFabcdef' for c in pin)
print('PASS strict APK upgrade guard, identity parser and pinned signer')
