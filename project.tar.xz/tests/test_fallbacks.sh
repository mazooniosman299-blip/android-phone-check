#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
T="$(mktemp -d)"
trap 'rm -rf "$T"' EXIT
javac -encoding UTF-8 -d "$T" app/src/main/java/com/mazentv/live/Channel.java app/src/main/java/com/mazentv/live/ZeeAlwanSource.java app/src/main/java/com/mazentv/live/ChannelFallbacks.java tests/ChannelFallbacksTest.java
java -cp "$T" com.mazentv.live.ChannelFallbacksTest
