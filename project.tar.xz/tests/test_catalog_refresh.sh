#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
mkdir -p /tmp/tilfazi-catalog-refresh
javac -d /tmp/tilfazi-catalog-refresh app/src/main/java/com/mazentv/live/CatalogRefreshPolicy.java tests/CatalogRefreshPolicyTest.java
java -cp /tmp/tilfazi-catalog-refresh CatalogRefreshPolicyTest
