import com.mazentv.live.CatalogRefreshPolicy;

public final class CatalogRefreshPolicyTest {
    private static void check(boolean b, String message) { if(!b) throw new AssertionError(message); }
    public static void main(String[] args) {
        long now = 100000000L;
        check(CatalogRefreshPolicy.shouldFetch(false, false, 0, 0, now), "new source must import");
        check(CatalogRefreshPolicy.shouldFetch(false, false, now-600000, 0, now), "failed source must retry");
        check(!CatalogRefreshPolicy.shouldFetch(false, false, now-1000, 0, now), "rate limit retries");
        check(!CatalogRefreshPolicy.shouldFetch(false, true, now-1000, now-1000, now), "successful source not reloaded immediately");
        check(CatalogRefreshPolicy.shouldFetch(false, true, now-90000000L, now-90000000L, now), "refresh a day later");
        check(!CatalogRefreshPolicy.shouldFetch(false, true, now-1000, now-90000000L, now), "do not hammer stale sources after network failures");
        check(CatalogRefreshPolicy.shouldFetch(true, true, now-100, now-100, now), "manual refresh always works");
        check(CatalogRefreshPolicy.shouldFetch(false, false, 0, 0, 1), "old global flag cannot suppress new sources");
        check(CatalogRefreshPolicy.needsIndexRecovery(38), "partial catalog must use full index recovery");
        check(CatalogRefreshPolicy.needsIndexRecovery(299), "below recovery threshold");
        check(!CatalogRefreshPolicy.needsIndexRecovery(300), "healthy imported catalog");
        check(!CatalogRefreshPolicy.needsIndexRecovery(-1), "invalid count does not recover");
        System.out.println("PASS 12 catalogue restore/retry/index recovery tests");
    }
}
