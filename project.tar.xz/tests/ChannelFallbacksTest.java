package com.mazentv.live;
import java.util.Arrays;
import java.util.List;

public class ChannelFallbacksTest {
  private static void eq(Object wanted, Object actual) {
    if (!wanted.equals(actual)) throw new AssertionError("expected="+wanted+" actual="+actual);
  }
  public static void main(String[] args) {
    Channel a=new Channel("Bahrain Sports 1 (720p) [Not 24/7]","رياضة","https://one.example/bs1.m3u8","");
    Channel b=new Channel("Bahrain Sports 1 (1080p)","رياضة","https://two.example/bs1.m3u8","");
    Channel c=new Channel("Bahrain Sports 2 (720p)","رياضة","https://three.example/bs2.m3u8","");
    List<String> found=ChannelFallbacks.alternatives(a,Arrays.asList(a,b,c,b));
    eq(2, found.size());
    eq(a.url, found.get(0));
    eq(b.url, found.get(1));
    eq("bahrain sports 1",ChannelFallbacks.channelKey(a.name));
    eq("bahrain sports 1",ChannelFallbacks.channelKey(b.name));
    Channel z=new Channel("ZEE Alwan - زي ألوان","مسلسلات",ZeeAlwanSource.CHANNEL_ID,"");
    eq(1,ChannelFallbacks.alternatives(z,Arrays.asList(z,
        new Channel("ZEE Alwan","مسلسلات","https://publisher.example/zee/live.m3u8",""))).size());
    eq("https://publisher.example/zee/live.m3u8", ChannelFallbacks.alternatives(z,Arrays.asList(z,
        new Channel("ZEE Alwan","مسلسلات","https://publisher.example/zee/live.m3u8",""))).get(0));
    eq(0,ChannelFallbacks.alternatives(new Channel("bad","","file:///tmp/bad.m3u8",""),Arrays.asList(a)).size());
    System.out.println("PASS channel fallback name matching, url safety, and no provider bypass");
  }
}
