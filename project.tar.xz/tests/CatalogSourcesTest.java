import com.mazentv.live.CatalogSources;
import java.util.HashSet;

public final class CatalogSourcesTest {
  public static void main(String[] args) {
    HashSet<String> unique = new HashSet<>();
    int count = 0;
    for (CatalogSources.Source source : CatalogSources.SOURCES) {
      if (source.title.isEmpty() || source.note.isEmpty()) throw new AssertionError("Missing metadata");
      if (!CatalogSources.isTrustedCatalogUrl(source.url)) throw new AssertionError("Unsafe provider URL: " + source.url);
      if (!unique.add(source.url)) throw new AssertionError("Duplicate source: " + source.url);
      count++;
    }
    if (count < 10) throw new AssertionError("Missing directories");
    if (CatalogSources.isTrustedCatalogUrl("https://iptv-org.github.io.evil.example/iptv/index.m3u")) throw new AssertionError("Host spoofing");
    if (CatalogSources.isTrustedCatalogUrl("http://iptv-org.github.io/iptv/index.m3u")) throw new AssertionError("Plain HTTP catalog");
    if (CatalogSources.isTrustedCatalogUrl("https://user:pass@iptv-org.github.io/iptv/index.m3u")) throw new AssertionError("Credentials");
    if (CatalogSources.isTrustedCatalogUrl("https://iptv-org.github.io/iptv/index.m3u?q=foo")) throw new AssertionError("Query");
    if (CatalogSources.isTrustedCatalogUrl("https://iptv-org.github.io/iptv/index.m3u#xx")) throw new AssertionError("Fragment");
    System.out.println("PASS " + count + " catalog provider entries + 5 security checks");
  }
}
