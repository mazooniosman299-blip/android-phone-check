#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
mkdir -p /tmp/tilfazi-catalog-test
javac -d /tmp/tilfazi-catalog-test app/src/main/java/com/mazentv/live/CatalogSources.java tests/CatalogSourcesTest.java
java -cp /tmp/tilfazi-catalog-test CatalogSourcesTest
