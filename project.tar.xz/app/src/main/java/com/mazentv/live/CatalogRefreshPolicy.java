package com.mazentv.live;

/** Pure logic for independently retrying source lists without losing prior channels. */
public final class CatalogRefreshPolicy {
    private static final long REFRESH_INTERVAL_MS = 24L * 60 * 60 * 1000;
    private static final int MIN_RECOVERY_CHANNELS = 300;
    private static final long RETRY_INTERVAL_MS = 5L * 60 * 1000;
    private CatalogRefreshPolicy() {}

    public static boolean needsIndexRecovery(int count) {
        return count >= 0 && count < MIN_RECOVERY_CHANNELS;
    }

    public static boolean shouldFetch(boolean force, boolean completed,
                                      long lastAttempt, long lastSuccess, long now) {
        if (force) return true;
        boolean retryAllowed = lastAttempt <= 0 || now < lastAttempt
                || now - lastAttempt >= RETRY_INTERVAL_MS;
        if (completed && lastSuccess > 0) {
            boolean stale = now < lastSuccess || now - lastSuccess >= REFRESH_INTERVAL_MS;
            return stale && retryAllowed;
        }
        return retryAllowed;
    }
}
