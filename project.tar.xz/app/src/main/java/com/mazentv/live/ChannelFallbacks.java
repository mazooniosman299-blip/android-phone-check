package com.mazentv.live;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;

/**
 * Find alternative broadcast URLs for the SAME named channel from the imported
 * catalog. Never substitute a different channel/program and never use a guessed
 * protected stream URL.
 */
public final class ChannelFallbacks {
    private ChannelFallbacks() {}
    public static final int MAX_SOURCES = 6;

    /** Strip stream-quality, broadcast-continuity hints without erasing the channel identity. */
    public static String channelKey(String name) {
        if (name == null) return "";
        return name.toLowerCase(Locale.ROOT)
                .replaceAll("(?i)\\s*\\[[^]]*]", " ")
                .replaceAll("(?i)\\s*\\((?:1080p|720p|480p|360p|576p|sd|hd|fhd|4k|not 24/7|24/7)\\)", " ")
                .replaceAll("(?i)\\b(?:1080p|720p|480p|360p|576p|sd|hd|fhd|uhd|4k)\\b", " ")
                .replaceAll("[\\s._-]+", " ").trim();
    }

    /** Primary URL first, alternate URLs only if name matches exactly after quality normalization. */
    public static List<String> alternatives(Channel primary, List<Channel> all) {
        LinkedHashSet<String> unique = new LinkedHashSet<>();
        if (primary == null || !Channel.isValidStreamUrl(primary.url)) return new ArrayList<>();
        unique.add(primary.url);
        if (ZeeAlwanSource.matches(primary.name)) {
            // Zee Alwan can use genuine authorized native media URLs just as
            // other channels do. Never add the .m3u directory placeholder.
            List<String> direct = ZeeAlwanSource.nativeAlternatives(primary, all);
            return direct;
        }
        String key = channelKey(primary.name);
        if (key.length() < 3 || all == null) return new ArrayList<>(unique);
        for (Channel c : all) {
            if (unique.size() >= MAX_SOURCES) break;
            if (Channel.isValidStreamUrl(c.url)
                    && !ZeeAlwanSource.matches(c.name)
                    && key.equals(channelKey(c.name))) unique.add(c.url);
        }
        return new ArrayList<>(unique);
    }
}
