package com.mazentv.live;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Import plain M3U/M3U8 playlists that users are authorized to access. Pure Java for easy testing. */
public final class M3uParser {
    private static final Pattern ATTRIBUTE = Pattern.compile("([\\w-]+)\\s*=\\s*\"([^\"]*)\"");
    private M3uParser() {}

    public static List<Channel> parse(String text, int maxChannels) throws IOException {
        if (text == null) throw new IllegalArgumentException("Empty playlist");
        int limit = Math.max(1, Math.min(maxChannels, 30000));
        ArrayList<Channel> result = new ArrayList<>();
        BufferedReader reader = new BufferedReader(new StringReader(text.replace("\uFEFF", "")));
        String line;
        String name = "";
        String group = "عام";
        String logo = "";
        boolean hasInfo = false;
        while ((line = reader.readLine()) != null && result.size() < limit) {
            line = line.trim();
            if (line.isEmpty()) continue;
            if (line.startsWith("#EXTINF:")) {
                hasInfo = true;
                name = "";
                group = "عام";
                logo = "";
                Matcher matcher = ATTRIBUTE.matcher(line);
                while (matcher.find()) {
                    String key = matcher.group(1);
                    String value = matcher.group(2).trim();
                    if ("group-title".equalsIgnoreCase(key)) group = value;
                    else if ("tvg-logo".equalsIgnoreCase(key)) logo = value;
                    else if ("tvg-name".equalsIgnoreCase(key)) name = value;
                }
                // Channel name is the part after the last comma not inside quoted metadata.
                int comma = -1;
                boolean quoted = false;
                for (int i = 0; i < line.length(); i++) {
                    char c = line.charAt(i);
                    if (c == '"') quoted = !quoted;
                    else if (c == ',' && !quoted) comma = i;
                }
                if (comma != -1 && comma + 1 < line.length()) {
                    String label = line.substring(comma + 1).trim();
                    if (!label.isEmpty()) name = label;
                }
            } else if (!line.startsWith("#")) {
                if (Channel.isValidStreamUrl(line)) {
                    result.add(new Channel(hasInfo ? name : "قناة " + (result.size() + 1), group, line, logo));
                }
                name = "";
                group = "عام";
                logo = "";
                hasInfo = false;
            }
        }
        return result;
    }
}
