package com.mazentv.live;

import java.util.Locale;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;

/** Channel identity and publicly catalogued sources; no entitlement or rights bypass. */
public final class ZeeAlwanSource {
    private ZeeAlwanSource() {}
    public static final String CHANNEL_ID = "https://iptv-org.github.io/iptv/channels/ZeeAlwan.ae.m3u";
    public static final String OLD_DEAD_URL = "https://weyyak-live.akamaized.net/weyyak_zee_alwan/index.m3u8";
    public static final String OFFICIAL_FREE_PAGE = "https://starzplay.com/ar/movies/zee-alwan/559865896371";
    public static final String OFFICIAL_WATCH_PAGE = "https://starzplay.com/ar/watch/movies/zee-alwan/559865896371";
    // An independent *official* ZEE-hosted provider, kept as a permitted fallback
    // when STARZPLAY itself denies page access. Playback may require entitlement.
    public static final String ZEE5_LIVE_PAGE = "https://www.zee5.com/global/live-tv/zee-alwan-hd/0-9-9z5817234";
    public static final String CHANNEL_LOGO = "https://i.imgur.com/fBL7YrC.png";

    /**
     * A genuine user-authorized HLS/DASH video URL can be played by the native
     * Media3 player. A provider WEB PAGE and an IPTV playlist (.m3u) are not
     * videos, and must never be handed to ExoPlayer as one.
     */
    public static boolean isDirectMediaUrl(String url) {
        if (!Channel.isValidStreamUrl(url) || OLD_DEAD_URL.equals(url)) return false;
        try {
            java.net.URI uri = new java.net.URI(url.trim());
            String path = uri.getPath();
            if (path == null) return false;
            path = path.toLowerCase(Locale.ROOT);
            return path.endsWith(".m3u8") || path.endsWith(".mpd");
        } catch (java.net.URISyntaxException e) { return false; }
    }

    /** Collect only alternate links for this same channel. Never rewrite a DRM
     * provider session as a third-party stream or fabricate a URL. */
    public static List<String> nativeAlternatives(Channel selected, List<Channel> catalog) {
        LinkedHashSet<String> urls = new LinkedHashSet<>();
        if (selected != null && matches(selected.name) && isDirectMediaUrl(selected.url))
            urls.add(selected.url);
        if (catalog != null) for (Channel item : catalog) {
            if (urls.size() >= ChannelFallbacks.MAX_SOURCES) break;
            if (matches(item.name) && isDirectMediaUrl(item.url)) urls.add(item.url);
        }
        return new ArrayList<>(urls);
    }

    public static boolean matches(String name) {
        if (name == null) return false;
        String lower = name.toLowerCase(Locale.ROOT).replaceAll("[\\s._-]", "");
        return lower.contains("zeealwan") || lower.contains("زيألوان") || lower.contains("زيالوان");
    }
    public static boolean isLiveManifest(String text) {
        if (text == null) return false;
        String trimmed = text.trim();
        return trimmed.startsWith("#EXTM3U") && trimmed.contains("#EXT-X-");
    }
}
