package com.mazentv.live;

import java.util.Locale;

/** Channel identity and publicly catalogued sources; no entitlement or rights bypass. */
public final class ZeeAlwanSource {
    private ZeeAlwanSource() {}
    public static final String CHANNEL_ID = "https://iptv-org.github.io/iptv/channels/ZeeAlwan.ae.m3u";
    public static final String OLD_DEAD_URL = "https://weyyak-live.akamaized.net/weyyak_zee_alwan/index.m3u8";
    public static final String OFFICIAL_FREE_PAGE = "https://starzplay.com/ar/movies/zee-alwan/559865896371";
    public static final String CHANNEL_LOGO = "https://i.imgur.com/fBL7YrC.png";

    public static boolean matches(String name) {
        if (name == null) return false;
        String lower = name.toLowerCase(Locale.ROOT).replaceAll("[\\s._-]", "");
        return lower.contains("zeealwan") || lower.contains("زيألوان") || lower.contains("زيالوان");
    }
    public static boolean isLiveManifest(String text) {
        if (text == null) return false;
        String trimmed = text.trim();
        return trimmed.startsWith("#EXTM3U") && trimmed.contains("#EXT-X-");
    }
}
