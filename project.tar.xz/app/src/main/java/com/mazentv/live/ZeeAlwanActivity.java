package com.mazentv.live;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

/**
 * Plays the official provider's own free-channel experience *inside* the app.
 * STARZPLAY controls access, region restrictions, ads and any DRM. This class
 * does not extract media URLs, inject scripts, bypass access restrictions,
 * or purport to re-host the channel.
 * Playback in Android WebView is provider/device dependent and must be tested.
 */
public final class ZeeAlwanActivity extends Activity {
    private static final String CHANNEL_PAGE = ZeeAlwanSource.OFFICIAL_WATCH_PAGE;
    private FrameLayout root;
    private WebView webView;
    private ProgressBar progress;
    private TextView error;
    private View fullScreenView;
    private WebChromeClient.CustomViewCallback fullScreenCallback;
    private FrameLayout fullScreenContainer;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        setContentView(root);

        webView = new WebView(this);
        webView.setBackgroundColor(Color.BLACK);
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setSupportMultipleWindows(false);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);

        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String scheme = request.getUrl().getScheme();
                if (!"https".equalsIgnoreCase(scheme)) return true;
                String host = request.getUrl().getHost();
                if (host == null) return true;
                host = host.toLowerCase(java.util.Locale.ROOT);
                // Allow only the official publisher's frontend and navigation.
                return !(host.equals("starzplay.com") || host.endsWith(".starzplay.com")
                        || host.equals("starzplayarabia.com") || host.endsWith(".starzplayarabia.com"));
            }
            @Override public void onPageFinished(WebView view, String url) {
                if (progress != null) progress.setVisibility(View.GONE);
            }
            @Override public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError e) {
                if (request.isForMainFrame()) showError("تعذر تحميل بث زي ألوان من مزوّد الخدمة. تحقق من الاتصال وإتاحة القناة في منطقتك.");
            }
            @Override public void onReceivedHttpError(WebView view, WebResourceRequest request,
                                                        android.webkit.WebResourceResponse response) {
                if (request.isForMainFrame() && response.getStatusCode() >= 400)
                    showError("المصدر الرسمي رفض التحميل (" + response.getStatusCode() + "). البث غير متاح حالياً من اتصالك.");
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public void onShowCustomView(View view, CustomViewCallback callback) {
                if (fullScreenView != null) { callback.onCustomViewHidden(); return; }
                fullScreenView = view;
                fullScreenCallback = callback;
                fullScreenContainer = new FrameLayout(ZeeAlwanActivity.this);
                fullScreenContainer.setBackgroundColor(Color.BLACK);
                fullScreenContainer.addView(view, new FrameLayout.LayoutParams(-1, -1));
                root.addView(fullScreenContainer, new FrameLayout.LayoutParams(-1, -1));
                getWindow().getDecorView().setSystemUiVisibility(
                        View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
            }
            @Override public void onHideCustomView() {
                closeFullScreen();
            }
        });
        root.addView(webView, new FrameLayout.LayoutParams(-1, -1));

        progress = new ProgressBar(this);
        FrameLayout.LayoutParams loading = new FrameLayout.LayoutParams(-2, -2, Gravity.CENTER);
        root.addView(progress, loading);

        error = new TextView(this);
        error.setTextColor(Color.WHITE);
        error.setTextSize(15);
        error.setGravity(Gravity.CENTER);
        error.setPadding(36, 30, 36, 30);
        error.setBackgroundColor(0xEE111723);
        error.setVisibility(View.GONE);
        root.addView(error, new FrameLayout.LayoutParams(-1, -2, Gravity.CENTER));
        webView.loadUrl(CHANNEL_PAGE);
    }

    private void showError(String detail) {
        if (progress != null) progress.setVisibility(View.GONE);
        if (error != null) {
            error.setText(detail);
            error.setVisibility(View.VISIBLE);
        }
    }

    private void closeFullScreen() {
        if (fullScreenView == null) return;
        if (fullScreenContainer != null) {
            fullScreenContainer.removeView(fullScreenView);
            root.removeView(fullScreenContainer);
        }
        fullScreenView = null;
        fullScreenContainer = null;
        if (fullScreenCallback != null) fullScreenCallback.onCustomViewHidden();
        fullScreenCallback = null;
        getWindow().getDecorView().setSystemUiVisibility(0);
    }

    @Override public void onBackPressed() {
        if (fullScreenView != null) { closeFullScreen(); return; }
        if (webView != null && webView.canGoBack()) { webView.goBack(); return; }
        super.onBackPressed();
    }
    @Override protected void onPause() {
        if (webView != null) webView.onPause();
        super.onPause();
    }
    @Override protected void onResume() {
        super.onResume();
        if (webView != null) webView.onResume();
    }
    @Override protected void onDestroy() {
        if (fullScreenView != null) closeFullScreen();
        if (webView != null) {
            root.removeView(webView);
            webView.stopLoading();
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
