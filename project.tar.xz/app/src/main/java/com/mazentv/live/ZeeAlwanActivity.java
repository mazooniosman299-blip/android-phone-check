package com.mazentv.live;

import android.app.Activity;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkCapabilities;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

/**
 * Plays the official provider's own free-channel experience *inside* the app.
 * STARZPLAY controls access, region restrictions, ads and any DRM. This class
 * does not extract media URLs, inject scripts, bypass access restrictions,
 * or purport to re-host the channel.
 * Playback in Android WebView is provider/device dependent and must be tested.
 */
public final class ZeeAlwanActivity extends Activity {
    private static final String CHANNEL_PAGE = ZeeAlwanSource.OFFICIAL_FREE_PAGE;
    private boolean triedOfficialBackup = false;
    private boolean mainFrameUnavailable = false;
    private String providerIssue = "";
    private boolean observedVideo = false;
    // Not every 403 belongs to the live video; ad and analytics requests can be denied
    // while the actual official player works. Do not switch publishers on subresource errors.
    private boolean providerMediaDenied = false;
    private int videoChecksAfterMediaDenial = 0;
    private final Handler diagnostics = new Handler(Looper.getMainLooper());
    private int videoChecks = 0;
    private final Runnable checkVideo = new Runnable() {
        @Override public void run() {
            if (webView == null || observedVideo || isFinishing() || videoChecks++ > 40) return;
            // Read only the public HTML5 video state; do not access protected
            // manifests, cookies, credentials or DRM keys.
            webView.evaluateJavascript("(function(){var v=document.querySelector('video');return !!(v && !v.paused && v.readyState>=2 && v.videoWidth>0);})()", result -> {
                if ("true".equals(result)) {
                    observedVideo = true;
                    playbackHealth.markRendered(ZeeAlwanSource.CHANNEL_ID);
                    Log.i("ZeeAlwanPlayback", "Verified playing HTML5 video on device");
                } else if (!mainFrameUnavailable) {
                    if (providerMediaDenied && ++videoChecksAfterMediaDenial >= 6) {
                        // Give the publisher 18 seconds to retry a protected media request.
                        // Switch only after an actual media denial AND no visible playback.
                        providerMediaDenied = false;
                        videoChecksAfterMediaDenial = 0;
                        attemptOfficialBackup("تعذر تحميل ملف بث القناة من المصدر الرسمي");
                    } else {
                        diagnostics.postDelayed(this, 3000);
                    }
                }
            });
        }
    };
    private FrameLayout root;
    private PlaybackHealth playbackHealth;
    private WebView webView;
    private ProgressBar progress;
    private TextView error;
    private View fullScreenView;
    private WebChromeClient.CustomViewCallback fullScreenCallback;
    private FrameLayout fullScreenContainer;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        playbackHealth = new PlaybackHealth(this);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        setContentView(root);

        webView = new WebView(this);
        webView.setBackgroundColor(Color.BLACK);
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setSupportMultipleWindows(false);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);

        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String scheme = request.getUrl().getScheme();
                if (!"https".equalsIgnoreCase(scheme)) return true;
                String host = request.getUrl().getHost();
                if (host == null) return true;
                host = host.toLowerCase(java.util.Locale.ROOT);
                // Allow only the official publisher's frontend and navigation.
                return !(host.equals("starzplay.com") || host.endsWith(".starzplay.com")
                        || host.equals("starzplayarabia.com") || host.endsWith(".starzplayarabia.com")
                        || host.equals("zee5.com") || host.endsWith(".zee5.com"));
            }
            @Override public void onPageFinished(WebView view, String url) {
                if (progress != null) progress.setVisibility(View.GONE);
                diagnostics.removeCallbacks(checkVideo);
                videoChecks = 0;
                // The player is not necessarily started until the visitor taps
                // the publisher's own Watch Live button. Never mistake that for a 403.
                diagnostics.postDelayed(checkVideo, 1800);
            }
            @Override public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError e) {
                if (request.isForMainFrame() && !obsoleteSourceRequest(request.getUrl())) {
                    String reason = e.getDescription() == null ? "تعذر اتصال الصفحة" : e.getDescription().toString();
                    providerIssue = "NETWORK " + e.getErrorCode() + ": " + reason;
                    Log.w("ZeeAlwanPlayback", "Provider page loading error " + providerIssue);
                    attemptOfficialBackup("تعذّر فتح صفحة المزود الأول");
                }
            }
            @Override public void onReceivedHttpError(WebView view, WebResourceRequest request,
                                                        android.webkit.WebResourceResponse response) {
                int code = response.getStatusCode();
                if (code >= 400) {
                    android.net.Uri url = request.getUrl();
                    if (obsoleteSourceRequest(url)) return;
                    // Record hostname and status, never playback session URLs or tokens.
                    String host = url.getHost() == null ? "unknown" : url.getHost();
                    Log.w("ZeeAlwanPlayback", "HTTP " + code + " from " + host
                            + (request.isForMainFrame() ? " [main page]" : " [media/resource]"));
                    String path = url.getPath() == null ? "" : url.getPath().toLowerCase(java.util.Locale.ROOT);
                    boolean mediaRequest = path.contains(".mpd") || path.contains(".m3u8")
                            || path.contains("/manifest") || path.contains("/widevine");
                    if (request.isForMainFrame()) {
                        providerIssue = "HTTP " + code + " from " + host;
                        attemptOfficialBackup("المزود الأول رفض فتح صفحة القناة (" + code + ")");
                    } else if ((code == 401 || code == 403) && mediaRequest) {
                        // Ignore unrelated ad/analytics 403s; only recognized playback
                        // endpoints trigger a delayed, frame-aware fallback.
                        providerIssue = "Media HTTP " + code + " from " + host;
                        providerMediaDenied = true;
                        videoChecksAfterMediaDenial = 0;
                        diagnostics.removeCallbacks(checkVideo);
                        diagnostics.postDelayed(checkVideo, 3000);
                    }
                }
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public void onShowCustomView(View view, CustomViewCallback callback) {
                if (fullScreenView != null) { callback.onCustomViewHidden(); return; }
                fullScreenView = view;
                fullScreenCallback = callback;
                fullScreenContainer = new FrameLayout(ZeeAlwanActivity.this);
                fullScreenContainer.setBackgroundColor(Color.BLACK);
                fullScreenContainer.addView(view, new FrameLayout.LayoutParams(-1, -1));
                root.addView(fullScreenContainer, new FrameLayout.LayoutParams(-1, -1));
                getWindow().getDecorView().setSystemUiVisibility(
                        View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
            }
            @Override public void onHideCustomView() {
                closeFullScreen();
            }
        });
        root.addView(webView, new FrameLayout.LayoutParams(-1, -1));

        progress = new ProgressBar(this);
        FrameLayout.LayoutParams loading = new FrameLayout.LayoutParams(-2, -2, Gravity.CENTER);
        root.addView(progress, loading);

        error = new TextView(this);
        error.setTextColor(Color.WHITE);
        error.setTextSize(15);
        error.setGravity(Gravity.CENTER);
        error.setPadding(36, 30, 36, 30);
        error.setBackgroundColor(0xEE111723);
        error.setVisibility(View.GONE);
        root.addView(error, new FrameLayout.LayoutParams(-1, -2, Gravity.CENTER));
        // Start at the provider's official channel page, not its deep watch URL.
        // The successful guest path first opened this page and used the site's own
        // Watch Live button. Direct navigation can skip a session initialization
        // step and lead to the provider's generic playback error.
        webView.loadUrl(CHANNEL_PAGE);
    }

    /**
     * A 403 is a server-side access-control response, not a codec failure.
     * Switch ONCE to a different licensed publisher page without proxying or
     * extracting DRM endpoints. This stays inside the app's WebView.
     */
    private void attemptOfficialBackup(String reason) {
        if (!triedOfficialBackup) {
            triedOfficialBackup = true;
            if (progress != null) progress.setVisibility(View.VISIBLE);
            if (error != null) error.setVisibility(View.GONE);
            diagnostics.removeCallbacks(checkVideo);
            providerMediaDenied = false;
            videoChecksAfterMediaDenial = 0;
            Log.i("ZeeAlwanPlayback", "Switching to separate official ZEE5 service: " + reason);
            webView.post(() -> webView.loadUrl(ZeeAlwanSource.ZEE5_LIVE_PAGE));
        } else {
            mainFrameUnavailable = true;
            playbackHealth.markFailed(ZeeAlwanSource.CHANNEL_ID);
            showError("تعذر عرض زي ألوان من مزوّدي البث الرسميين على هذا الاتصال."
                    + (isVpnActive() ? " تم اكتشاف VPN؛ جرّب الاتصال المباشر." : "")
                    + " حالة الاتصال: " + (providerIssue.isEmpty() ? reason : providerIssue));
        }
    }

    private boolean obsoleteSourceRequest(android.net.Uri url) {
        // Late STARZPLAY requests can arrive after switching provider; they
        // must not be treated as errors from the ZEE5 fallback.
        if (!triedOfficialBackup || url == null) return false;
        String host = url.getHost();
        if (host == null) return false;
        host = host.toLowerCase(java.util.Locale.ROOT);
        return host.equals("starzplay.com") || host.endsWith(".starzplay.com")
                || host.equals("starzplayarabia.com") || host.endsWith(".starzplayarabia.com");
    }

    private boolean isVpnActive() {
        ConnectivityManager connectivity = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        if (connectivity == null) return false;
        NetworkCapabilities caps = connectivity.getNetworkCapabilities(connectivity.getActiveNetwork());
        return caps != null && caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN);
    }

    private void showError(String detail) {
        if (progress != null) progress.setVisibility(View.GONE);
        if (error != null) {
            error.setText(detail);
            error.setVisibility(View.VISIBLE);
        }
    }

    private void closeFullScreen() {
        if (fullScreenView == null) return;
        if (fullScreenContainer != null) {
            fullScreenContainer.removeView(fullScreenView);
            root.removeView(fullScreenContainer);
        }
        fullScreenView = null;
        fullScreenContainer = null;
        if (fullScreenCallback != null) fullScreenCallback.onCustomViewHidden();
        fullScreenCallback = null;
        getWindow().getDecorView().setSystemUiVisibility(0);
    }

    @Override public void onBackPressed() {
        if (fullScreenView != null) { closeFullScreen(); return; }
        if (webView != null && webView.canGoBack()) { webView.goBack(); return; }
        super.onBackPressed();
    }
    @Override protected void onPause() {
        if (webView != null) webView.onPause();
        super.onPause();
    }
    @Override protected void onResume() {
        super.onResume();
        if (webView != null) webView.onResume();
    }
    @Override protected void onDestroy() {
        if (fullScreenView != null) closeFullScreen();
        diagnostics.removeCallbacks(checkVideo);
        if (webView != null) {
            root.removeView(webView);
            webView.stopLoading();
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
