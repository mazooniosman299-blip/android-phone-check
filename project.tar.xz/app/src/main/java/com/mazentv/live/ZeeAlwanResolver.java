package com.mazentv.live;

import android.os.Handler;
import android.os.Looper;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;

/** Resolves candidate streams on the *device's* network. Never plays an untested 404/403 URL. */
public final class ZeeAlwanResolver {
    public interface Callback {
        void resolved(String streamUrl);
        void unavailable(String explanation);
    }
    private ZeeAlwanResolver() {}

    public static void findAvailable(Callback callback) {
        Handler main = new Handler(Looper.getMainLooper());
        new Thread(() -> {
            LinkedHashSet<String> candidates = new LinkedHashSet<>();
            // Fetch a current channel-only public directory first. It is an index, not a rights grant.
            try {
                String data = load(ZeeAlwanSource.CHANNEL_ID, 1024 * 512);
                for (Channel channel : M3uParser.parse(data, 25)) {
                    if (Channel.isValidStreamUrl(channel.url) && !channel.url.equals(ZeeAlwanSource.CHANNEL_ID)) {
                        candidates.add(channel.url);
                    }
                }
            } catch (Exception ignored) {
                // Directory might not be reachable; continue to the other published candidates.
            }
            candidates.add(ZeeAlwanSource.OLD_DEAD_URL);
            candidates.add(ZeeAlwanSource.PUBLIC_LISTED_BACKUP);

            String lastResult = "لا يوجد بث HLS متاح للشبكة الحالية";
            int checked = 0;
            for (String candidate : candidates) {
                if (++checked > 10) break;
                if (!candidate.startsWith("https://")) continue;
                try {
                    String manifest = load(candidate, 24 * 1024);
                    if (ZeeAlwanSource.isLiveManifest(manifest)) {
                        final String playable = candidate;
                        main.post(() -> callback.resolved(playable));
                        return;
                    }
                    lastResult = "المصدر الحالي ليس بثاً مباشراً صالحاً";
                } catch (Exception failure) {
                    lastResult = failure.getMessage() == null ? "المصدر غير متاح" : failure.getMessage();
                }
            }
            final String message = "زي ألوان غير متاحة للبث داخل التطبيق من اتصالك حالياً. " + lastResult +
                    ". قد يكون السبب توقف المصدر أو تقييد الوصول. لم يتم تجاوز أي حماية.";
            main.post(() -> callback.unavailable(message));
        }, "zee-alwan-stream-check").start();
    }

    private static String load(String url, int maxBytes) throws Exception {
        HttpURLConnection conn = (HttpURLConnection) new URL(url).openConnection();
        conn.setInstanceFollowRedirects(true);
        conn.setConnectTimeout(6500);
        conn.setReadTimeout(6500);
        conn.setRequestProperty("Accept", "application/vnd.apple.mpegurl, application/x-mpegURL, text/plain, */*");
        try {
            int code = conn.getResponseCode();
            if (code != 200) throw new Exception("رمز الخادم " + code);
            try (InputStream in = conn.getInputStream(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                byte[] block = new byte[2048];
                int size;
                while ((size = in.read(block)) >= 0) {
                    if (out.size() + size > maxBytes) {
                        // HLS master playlist usually fits; reject excessive / unrelated content.
                        throw new Exception("استجابة أكبر من المتوقع");
                    }
                    out.write(block, 0, size);
                }
                return new String(out.toByteArray(), StandardCharsets.UTF_8);
            }
        } finally { conn.disconnect(); }
    }
}
