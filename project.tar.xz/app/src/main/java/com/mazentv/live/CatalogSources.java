package com.mazentv.live;

import java.util.Locale;

/** Public third-party playlist *directory*. An entry is not a rights grant or availability guarantee. */
public final class CatalogSources {
    public static final class Source {
        public final String title;
        public final String url;
        public final String note;
        public Source(String title, String path, String note) {
            this.title = title;
            this.url = "https://iptv-org.github.io/iptv/" + path + ".m3u";
            this.note = note;
        }
    }
    private CatalogSources() {}
    public static final Source[] SOURCES = {
        new Source("القنوات العربية", "languages/ara", "مصادر عربية عامة"),
        new Source("قنوات السودان", "countries/sd", "قنوات السودان المتاحة"),
        new Source("قنوات عُمان", "countries/om", "قنوات سلطنة عُمان"),
        new Source("أخبار العالم", "categories/news", "قنوات إخبارية"),
        new Source("الرياضة المفتوحة", "categories/sports", "لا تشمل القنوات الرياضية المشفرة"),
        new Source("الأطفال", "categories/kids", "برامج الأطفال"),
        new Source("القرآن والدين", "categories/religious", "قنوات دينية"),
        new Source("وثائقيات", "categories/documentary", "برامج وثائقية"),
        new Source("أفلام مجانية", "categories/movies", "لا تتضمن قنوات الأفلام المدفوعة"),
        new Source("الترفيه", "categories/entertainment", "قنوات من دول متعددة"),
        new Source("الإنجليزية", "languages/eng", "قنوات باللغة الإنجليزية"),
        new Source("كل القنوات المفتوحة المفهرسة", "index", "فهرس خارجي ضخم؛ لا يعني جميع قنوات العالم")
    };
    public static boolean isTrustedCatalogUrl(String url) {
        if (url == null) return false;
        try {
            java.net.URI uri = new java.net.URI(url);
            return "https".equalsIgnoreCase(uri.getScheme())
                && "iptv-org.github.io".equalsIgnoreCase(uri.getHost())
                && uri.getUserInfo() == null
                && uri.getRawQuery() == null
                && uri.getRawFragment() == null
                && uri.getPath() != null
                && uri.getPath().startsWith("/iptv/")
                && uri.getPath().toLowerCase(Locale.ROOT).endsWith(".m3u");
        } catch (Exception e) { return false; }
    }
}
