package com.mazentv.live;

import android.app.Activity;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.LinkedHashSet;

import androidx.media3.common.MediaItem;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.datasource.HttpDataSource;
import androidx.media3.ui.AspectRatioFrameLayout;
import androidx.media3.ui.PlayerView;

/** Full-bleed live video. All optional controls are overlays; no title or separate toolbar. */
@UnstableApi
public final class PlayerActivity extends Activity {
    private static final int BLACK = 0xFF000000;
    private static final int WHITE = 0xFFF5F7FB;
    private static final int GLASS = 0xD0182030;
    private ExoPlayer player;
    private PlayerView videoView;
    private TextView status;
    private LinearLayout topControls;
    private FrameLayout controlsLayer;
    private Button qualityButton;
    private String streamUrl;
    private String originalUrl;
    private final ArrayList<String> sourceCandidates = new ArrayList<>();
    private int sourceIndex = 0;
    private boolean videoFrameRendered;
    private final Runnable noVideoTimeout = () -> {
        // A URL can return HTTP 200 but never display video: recover from stalls too.
        if (player != null && !videoFrameRendered) tryNextSource("لم تصل صورة من المصدر");
    };
    private PlaybackHealth playbackHealth;
    private int maxQuality = -1;
    private boolean controlsVisible = true;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final Runnable hideControls = () -> setControlsVisible(false);
    private final Runnable hideStatus = () -> {
        if (status != null) status.setVisibility(View.GONE);
    };

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        streamUrl = getIntent().getStringExtra("url");
        originalUrl = streamUrl;
        LinkedHashSet<String> uniqueSources = new LinkedHashSet<>();
        if (Channel.isValidStreamUrl(streamUrl)) uniqueSources.add(streamUrl);
        ArrayList<String> extras = getIntent().getStringArrayListExtra("alternate_urls");
        if (extras != null) for (String option : extras) {
            if (uniqueSources.size() >= ChannelFallbacks.MAX_SOURCES) break;
            if (Channel.isValidStreamUrl(option)) uniqueSources.add(option);
        }
        sourceCandidates.addAll(uniqueSources);
        playbackHealth = new PlaybackHealth(this);
        if (!Channel.isValidStreamUrl(streamUrl)) { finish(); return; }
        if (savedInstanceState != null) {
            maxQuality = savedInstanceState.getInt("quality", -1);
        }
        getWindow().setStatusBarColor(BLACK);
        getWindow().setNavigationBarColor(BLACK);
        getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        buildPlayerScreen();
    }

    private int dp(float v) { return Math.round(v * getResources().getDisplayMetrics().density); }
    private GradientDrawable glass() {
        GradientDrawable d = new GradientDrawable();
        d.setColor(GLASS);
        d.setCornerRadius(dp(15));
        d.setStroke(dp(1), 0x55323C52);
        return d;
    }
    private Button action(String label, String description) {
        Button b = new Button(this);
        b.setAllCaps(false);
        b.setText(label);
        b.setTextSize(14);
        b.setTextColor(WHITE);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setBackground(glass());
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        b.setPadding(dp(13), dp(8), dp(13), dp(8));
        b.setContentDescription(description);
        return b;
    }

    private void buildPlayerScreen() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(BLACK);
        setContentView(root);

        videoView = new PlayerView(this);
        videoView.setBackgroundColor(BLACK);
        videoView.setUseController(false);
        videoView.setShowBuffering(PlayerView.SHOW_BUFFERING_ALWAYS);
        videoView.setKeepScreenOn(true);
        videoView.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_FIT);
        root.addView(videoView, new FrameLayout.LayoutParams(-1, -1));

        // Transparent touch target: one tap reveals or dismisses overlays, not a second video surface.
        View touchTarget = new View(this);
        touchTarget.setContentDescription("إظهار أو إخفاء أدوات المشاهدة");
        touchTarget.setOnClickListener(v -> {
            setControlsVisible(!controlsVisible);
            if (controlsVisible) scheduleHideControls();
        });
        root.addView(touchTarget, new FrameLayout.LayoutParams(-1, -1));

        // All controls float OVER the picture: nothing below the live player.
        FrameLayout topLayer = new FrameLayout(this);
        topControls = new LinearLayout(this);
        topControls.setOrientation(LinearLayout.HORIZONTAL);
        topControls.setGravity(Gravity.CENTER_VERTICAL);
        Button back = action("‹", "الرجوع للقنوات");
        back.setOnClickListener(v -> finish());
        topControls.addView(back, new LinearLayout.LayoutParams(dp(48), dp(44)));
        FrameLayout.LayoutParams backParams = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.START);
        backParams.setMargins(dp(12), dp(14), dp(12), 0);
        topLayer.addView(topControls, backParams);

        LinearLayout playerActions = new LinearLayout(this);
        playerActions.setOrientation(LinearLayout.HORIZONTAL);
        playerActions.setGravity(Gravity.CENTER_VERTICAL);
        qualityButton = action("تلقائي", "تغيير جودة القناة");
        qualityButton.setOnClickListener(v -> chooseQuality());
        playerActions.addView(qualityButton, new LinearLayout.LayoutParams(-2, dp(44)));
        Button fullscreen = action("⛶", "ملء الشاشة أو العودة للوضع العادي");
        fullscreen.setOnClickListener(v -> changeOrientation());
        LinearLayout.LayoutParams fullParams = new LinearLayout.LayoutParams(dp(50), dp(44));
        fullParams.setMargins(dp(8), 0, 0, 0);
        playerActions.addView(fullscreen, fullParams);
        FrameLayout.LayoutParams controlsParams = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.END);
        controlsParams.setMargins(dp(12), dp(14), dp(12), 0);
        topLayer.addView(playerActions, controlsParams);
        FrameLayout.LayoutParams layerParams = new FrameLayout.LayoutParams(-1, dp(70), Gravity.TOP);
        root.addView(topLayer, layerParams);
        topControls = playerActions;
        // Back control is part of the same layer and hides with the actions.
        // Keep a reference so tap-to-show works for both groups.
        controlsLayer = topLayer;

        status = new TextView(this);
        status.setTextSize(12);
        status.setTextColor(WHITE);
        status.setText("جاري الاتصال بالبث...");
        status.setPadding(dp(11), dp(9), dp(11), dp(9));
        status.setBackground(glass());
        FrameLayout.LayoutParams statusParams = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.START);
        statusParams.setMargins(dp(12), 0, dp(12), dp(23));
        root.addView(status, statusParams);

        updateWindowMode();
        scheduleHideControls();
    }

    @Override protected void onStart() {
        super.onStart();
        if (player != null) return;
        player = new ExoPlayer.Builder(this).build();
        videoView.setPlayer(player);
        player.addListener(new Player.Listener() {
            @Override public void onPlaybackStateChanged(int state) {
                if (state == Player.STATE_BUFFERING) showStatus("جاري تحميل البث...", false);
                else if (state == Player.STATE_READY) showStatus("تم الاتصال؛ انتظار ظهور الصورة...", false);
                else if (state == Player.STATE_ENDED) {
                    if (!videoFrameRendered) tryNextSource("انتهى المصدر قبل ظهور الصورة");
                    else showStatus("انتهى البث", false);
                }
            }
            @Override public void onRenderedFirstFrame() {
                videoFrameRendered = true;
                main.removeCallbacks(noVideoTimeout);
                playbackHealth.markRendered(streamUrl);
                // The originally selected channel should earn the observed LIVE
                // badge even when a matching backup variant supplied the picture.
                playbackHealth.markRendered(originalUrl);
                showStatus("● مباشر", true);
            }
            @Override public void onPlayerError(PlaybackException error) {
                final int httpCode = httpStatus(error);
                String reason;
                if (httpCode == 403 || httpCode == 401) reason = "المصدر يحتاج صلاحية وصول (HTTP " + httpCode + ")";
                else if (httpCode == 404 || httpCode == 410) reason = "عنوان البث لم يعد موجوداً (HTTP " + httpCode + ")";
                else if (httpCode != 0) reason = "الخادم أعاد HTTP " + httpCode;
                else reason = "تعذر فك البث أو انقطع الاتصال: " + error.getErrorCodeName();
                tryNextSource(reason);
            }
        });
        startCandidate();
    }

    private static int httpStatus(Throwable error) {
        for (Throwable cause = error; cause != null; cause = cause.getCause()) {
            if (cause instanceof HttpDataSource.InvalidResponseCodeException)
                return ((HttpDataSource.InvalidResponseCodeException) cause).responseCode;
        }
        return 0;
    }

    private void startCandidate() {
        if (player == null || sourceIndex >= sourceCandidates.size()) return;
        streamUrl = sourceCandidates.get(sourceIndex);
        videoFrameRendered = false;
        main.removeCallbacks(noVideoTimeout);
        MediaItem.Builder item = new MediaItem.Builder().setUri(streamUrl);
        String path = streamUrl.split("\\?", 2)[0].toLowerCase(java.util.Locale.ROOT);
        if (path.endsWith(".m3u8")) item.setMimeType(MimeTypes.APPLICATION_M3U8);
        else if (path.endsWith(".mpd")) item.setMimeType(MimeTypes.APPLICATION_MPD);
        player.stop();
        player.setMediaItem(item.build());
        applyQuality();
        player.prepare();
        player.play();
        main.postDelayed(noVideoTimeout, 30000);
    }

    private void tryNextSource(String reason) {
        if (player == null) return;
        main.removeCallbacks(noVideoTimeout);
        playbackHealth.markFailed(streamUrl);
        android.util.Log.w("TilfaziPlayer", "Stream variant " + (sourceIndex + 1)
                + "/" + sourceCandidates.size() + ": " + reason);
        if (sourceIndex + 1 < sourceCandidates.size()) {
            sourceIndex++;
            showStatus("جاري الاتصال بمصدر البث البديل " + (sourceIndex + 1) +
                    "/" + sourceCandidates.size() + "...", false);
            main.post(this::startCandidate);
        } else {
            // Do not fake a LIVE badge for a source that produced no video.
            playbackHealth.markFailed(originalUrl);
            showStatus("القناة غير متاحة حالياً من مصادرها: " + reason, false);
        }
    }

    private void showStatus(String message, boolean temporary) {
        if (status == null) return;
        main.removeCallbacks(hideStatus);
        status.setText(message);
        status.setVisibility(View.VISIBLE);
        if (temporary) main.postDelayed(hideStatus, 1700);
    }

    @Override protected void onStop() {
        main.removeCallbacks(hideControls);
        main.removeCallbacks(hideStatus);
        main.removeCallbacks(noVideoTimeout);
        if (videoView != null) videoView.setPlayer(null);
        if (player != null) { player.release(); player = null; }
        super.onStop();
    }
    @Override protected void onSaveInstanceState(Bundle out) {
        out.putInt("quality", maxQuality);
        super.onSaveInstanceState(out);
    }

    private void scheduleHideControls() {
        main.removeCallbacks(hideControls);
        main.postDelayed(hideControls, 3200);
    }
    private void setControlsVisible(boolean visible) {
        controlsVisible = visible;
        if (controlsLayer != null) controlsLayer.setVisibility(visible ? View.VISIBLE : View.GONE);
        if (!visible) main.removeCallbacks(hideControls);
    }
    private void chooseQuality() {
        int[] heights = {-1, 1080, 720, 480, 360};
        String[] choices = {"تلقائي (أفضل جودة متاحة)", "حتى 1080p", "حتى 720p", "حتى 480p", "حتى 360p"};
        int selected = 0;
        for (int i = 1; i < heights.length; i++) if (maxQuality == heights[i]) selected = i;
        new android.app.AlertDialog.Builder(this).setTitle("جودة البث")
                .setSingleChoiceItems(choices, selected, (dialog, which) -> {
                    maxQuality = heights[which];
                    applyQuality();
                    qualityButton.setText(maxQuality == -1 ? "تلقائي" : maxQuality + "p");
                    dialog.dismiss();
                    scheduleHideControls();
                }).setNegativeButton("إغلاق", null).show();
    }
    private void applyQuality() {
        if (player == null) return;
        int maxH = maxQuality < 0 ? Integer.MAX_VALUE : maxQuality;
        int maxW = maxQuality < 0 ? Integer.MAX_VALUE : maxQuality * 16 / 9;
        player.setTrackSelectionParameters(player.getTrackSelectionParameters().buildUpon()
                .setMaxVideoSize(maxW, maxH).build());
    }
    private void changeOrientation() {
        boolean landscape = getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE;
        setRequestedOrientation(landscape ? ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                : ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
        scheduleHideControls();
    }
    private void applyVideoScaling() {
        // FIT keeps all edges visible. Zoom would crop the picture on aspect ratio mismatch.
        if (videoView != null) videoView.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_FIT);
    }
    @SuppressWarnings("deprecation")
    private void updateWindowMode() {
        boolean landscape = getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE;
        getWindow().getDecorView().setSystemUiVisibility(landscape
                ? View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                  | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_FULLSCREEN
                  | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                : View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        applyVideoScaling();
    }
    @Override public void onConfigurationChanged(Configuration config) {
        super.onConfigurationChanged(config);
        updateWindowMode();
    }
    @Override public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) updateWindowMode();
    }
}
