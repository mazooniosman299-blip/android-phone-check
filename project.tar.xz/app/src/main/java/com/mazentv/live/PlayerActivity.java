package com.mazentv.live;

import android.app.Activity;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.media3.common.MediaItem;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.PlayerView;

@UnstableApi
public final class PlayerActivity extends Activity {
    private static final int BG = 0xFF0C0D11;
    private static final int ACCENT = 0xFFA7FA71;
    private ExoPlayer player;
    private PlayerView playerView;
    private TextView status;
    private Button fullscreen;
    private String url;
    private String label;
    private int quality = -1;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        url = getIntent().getStringExtra("url");
        label = getIntent().getStringExtra("name");
        if (!Channel.isValidStreamUrl(url)) { finish(); return; }
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        showUI();
    }

    private int dp(int n) { return Math.round(n * getResources().getDisplayMetrics().density); }
    private GradientDrawable bg(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(dp(radius)); return d;
    }
    private Button button(String value) {
        Button b = new Button(this);
        b.setAllCaps(false);
        b.setText(value);
        b.setTextColor(0xFFF4F6F9);
        b.setTextSize(14);
        b.setBackground(bg(0xFF242930, 11));
        b.setMinimumHeight(0); b.setMinHeight(0);
        b.setPadding(dp(8), dp(5), dp(8), dp(5));
        return b;
    }
    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextColor(color); t.setTextSize(size);
        t.setGravity(Gravity.CENTER_VERTICAL);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private void showUI() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.setFitsSystemWindows(true);
        root.setBackgroundColor(BG);
        root.setPadding(dp(12), dp(8), dp(12), dp(8));
        setContentView(root);

        LinearLayout titleBar = new LinearLayout(this);
        titleBar.setGravity(Gravity.CENTER_VERTICAL);
        Button back = button("↩");
        titleBar.addView(back, new LinearLayout.LayoutParams(dp(50), dp(45)));
        back.setOnClickListener(v -> finish());
        LinearLayout info = new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        TextView heading = text(label == null ? "بث مباشر" : label, 16, 0xFFF4F6F9, true);
        heading.setMaxLines(2);
        info.addView(heading);
        info.addView(text("●  مباشر / بث عبر الإنترنت", 11, ACCENT, false));
        titleBar.addView(info, new LinearLayout.LayoutParams(0, dp(54), 1));
        root.addView(titleBar);

        FrameLayout stage = new FrameLayout(this);
        stage.setBackground(bg(0xFF000000, 15));
        playerView = new PlayerView(this);
        playerView.setUseController(true);
        playerView.setKeepScreenOn(true);
        playerView.setShowBuffering(PlayerView.SHOW_BUFFERING_ALWAYS);
        playerView.setControllerAutoShow(true);
        playerView.setBackgroundColor(0xFF000000);
        FrameLayout.LayoutParams video = new FrameLayout.LayoutParams(-1, -1);
        stage.addView(playerView, video);
        int height = getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE
                ? Math.max(dp(140), getResources().getDisplayMetrics().heightPixels - dp(155))
                : dp(245);
        root.addView(stage, new LinearLayout.LayoutParams(-1, height));

        status = text("جاري الاتصال بالبث...", 12, 0xFFABB4BC, false);
        status.setPadding(dp(4), dp(10), dp(4), dp(12));
        root.addView(status);
        LinearLayout actions = new LinearLayout(this);
        actions.setGravity(Gravity.CENTER_VERTICAL);
        Button retry = button("⟳  إعادة المحاولة");
        Button qualityButton = button("⚙  الجودة");
        fullscreen = button("⛶  ملء الشاشة");
        actions.addView(retry, new LinearLayout.LayoutParams(0, dp(46), 1));
        actions.addView(qualityButton, new LinearLayout.LayoutParams(0, dp(46), 1));
        actions.addView(fullscreen, new LinearLayout.LayoutParams(0, dp(46), 1));
        root.addView(actions);
        retry.setOnClickListener(v -> restart());
        qualityButton.setOnClickListener(v -> chooseQuality());
        fullscreen.setOnClickListener(v -> toggleOrientation());
        root.addView(text("الجودة الفعلية تعتمد على دقة المصدر وسرعة الاتصال.", 12, 0xFF7F8791, false));
    }

    @Override protected void onStart() { super.onStart(); start(); }
    @Override protected void onStop() {
        if (playerView != null) playerView.setPlayer(null);
        if (player != null) { player.release(); player = null; }
        super.onStop();
    }

    private void start() {
        if (player != null) return;
        player = new ExoPlayer.Builder(this).build();
        playerView.setPlayer(player);
        player.addListener(new Player.Listener() {
            @Override public void onPlaybackStateChanged(int state) {
                if (status == null) return;
                if (state == Player.STATE_BUFFERING) status.setText("جاري تحميل البث...");
                else if (state == Player.STATE_READY) status.setText("●  يعمل الآن");
                else if (state == Player.STATE_ENDED) status.setText("انتهى البث أو المقطع");
            }
            @Override public void onPlayerError(PlaybackException error) {
                if (status != null) status.setText("تعذر تشغيل المصدر (" + error.errorCode + "). جرّب إعادة المحاولة أو رابطاً آخر.");
            }
        });
        MediaItem.Builder item = new MediaItem.Builder().setUri(url);
        String clean = url.split("\\?", 2)[0].toLowerCase(java.util.Locale.ROOT);
        if (clean.endsWith(".m3u8")) item.setMimeType(MimeTypes.APPLICATION_M3U8);
        if (clean.endsWith(".mpd")) item.setMimeType(MimeTypes.APPLICATION_MPD);
        player.setMediaItem(item.build());
        applyQuality();
        player.prepare();
        player.setPlayWhenReady(true);
    }

    private void restart() {
        if (status != null) status.setText("إعادة الاتصال بالمصدر...");
        if (player != null) { player.seekToDefaultPosition(); player.prepare(); player.play(); }
        else start();
    }

    private void chooseQuality() {
        String[] names = { "تلقائي (موصى به)", "1080p كحد أعلى", "720p كحد أعلى", "480p كحد أعلى", "360p كحد أعلى" };
        new android.app.AlertDialog.Builder(this).setTitle("جودة البث")
                .setSingleChoiceItems(names, quality == -1 ? 0 : quality == 1080 ? 1 : quality == 720 ? 2 : quality == 480 ? 3 : 4,
                        (dialog, which) -> {
                            quality = which == 0 ? -1 : which == 1 ? 1080 : which == 2 ? 720 : which == 3 ? 480 : 360;
                            applyQuality();
                            dialog.dismiss();
                        }).setNegativeButton("إغلاق", null).show();
    }

    private void applyQuality() {
        if (player == null) return;
        int maxHeight = quality < 0 ? Integer.MAX_VALUE : quality;
        int maxWidth = quality < 0 ? Integer.MAX_VALUE : (quality * 16 / 9);
        player.setTrackSelectionParameters(player.getTrackSelectionParameters().buildUpon()
                .setMaxVideoSize(maxWidth, maxHeight).build());
    }

    private void toggleOrientation() {
        boolean landscape = getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE;
        setRequestedOrientation(landscape ? ActivityInfo.SCREEN_ORIENTATION_PORTRAIT : ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
    }
    @Override public void onConfigurationChanged(Configuration config) {
        super.onConfigurationChanged(config);
        showUI();
        if (player != null) playerView.setPlayer(player);
        if (config.orientation == Configuration.ORIENTATION_LANDSCAPE)
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        else getWindow().getDecorView().setSystemUiVisibility(0);
    }
}
