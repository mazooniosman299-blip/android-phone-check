package com.mazentv.live;

import android.app.Activity;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.media3.common.MediaItem;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.AspectRatioFrameLayout;
import androidx.media3.ui.PlayerView;

/** Full-bleed live video. All optional controls are overlays; no title or separate toolbar. */
@UnstableApi
public final class PlayerActivity extends Activity {
    private static final int BLACK = 0xFF000000;
    private static final int WHITE = 0xFFF5F7FB;
    private static final int GLASS = 0xD0182030;
    private ExoPlayer player;
    private PlayerView videoView;
    private TextView status;
    private LinearLayout topControls;
    private LinearLayout bottomControls;
    private Button qualityButton;
    private Button fitButton;
    private String streamUrl;
    private int maxQuality = -1;
    private boolean fillVideo = true;
    private boolean controlsVisible = true;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final Runnable hideControls = () -> setControlsVisible(false);
    private final Runnable hideStatus = () -> {
        if (status != null) status.setVisibility(View.GONE);
    };

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        streamUrl = getIntent().getStringExtra("url");
        if (!Channel.isValidStreamUrl(streamUrl)) { finish(); return; }
        if (savedInstanceState != null) {
            maxQuality = savedInstanceState.getInt("quality", -1);
            fillVideo = savedInstanceState.getBoolean("fill", true);
        }
        getWindow().setStatusBarColor(BLACK);
        getWindow().setNavigationBarColor(BLACK);
        getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        buildPlayerScreen();
    }

    private int dp(float v) { return Math.round(v * getResources().getDisplayMetrics().density); }
    private GradientDrawable glass() {
        GradientDrawable d = new GradientDrawable();
        d.setColor(GLASS);
        d.setCornerRadius(dp(15));
        d.setStroke(dp(1), 0x55323C52);
        return d;
    }
    private Button action(String label, String description) {
        Button b = new Button(this);
        b.setAllCaps(false);
        b.setText(label);
        b.setTextSize(14);
        b.setTextColor(WHITE);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setBackground(glass());
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        b.setPadding(dp(13), dp(8), dp(13), dp(8));
        b.setContentDescription(description);
        return b;
    }

    private void buildPlayerScreen() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(BLACK);
        setContentView(root);

        videoView = new PlayerView(this);
        videoView.setBackgroundColor(BLACK);
        videoView.setUseController(false);
        videoView.setShowBuffering(PlayerView.SHOW_BUFFERING_ALWAYS);
        videoView.setKeepScreenOn(true);
        root.addView(videoView, new FrameLayout.LayoutParams(-1, -1));

        // Transparent touch target: one tap reveals or dismisses overlays, not a second video surface.
        View touchTarget = new View(this);
        touchTarget.setContentDescription("إظهار أو إخفاء أدوات المشاهدة");
        touchTarget.setOnClickListener(v -> {
            setControlsVisible(!controlsVisible);
            if (controlsVisible) scheduleHideControls();
        });
        root.addView(touchTarget, new FrameLayout.LayoutParams(-1, -1));

        topControls = new LinearLayout(this);
        topControls.setOrientation(LinearLayout.HORIZONTAL);
        Button back = action("‹", "الرجوع للقنوات");
        back.setOnClickListener(v -> finish());
        topControls.addView(back, new LinearLayout.LayoutParams(dp(48), dp(44)));
        FrameLayout.LayoutParams topParams = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.START);
        topParams.setMargins(dp(16), dp(19), dp(16), 0);
        root.addView(topControls, topParams);

        bottomControls = new LinearLayout(this);
        bottomControls.setOrientation(LinearLayout.HORIZONTAL);
        bottomControls.setGravity(Gravity.CENTER_VERTICAL);
        qualityButton = action("تلقائي", "جودة البث");
        qualityButton.setOnClickListener(v -> chooseQuality());
        bottomControls.addView(qualityButton, new LinearLayout.LayoutParams(-2, dp(44)));
        fitButton = action("ملء", "تغيير طريقة عرض الفيديو");
        fitButton.setOnClickListener(v -> {
            fillVideo = !fillVideo;
            applyVideoScaling();
            scheduleHideControls();
        });
        LinearLayout.LayoutParams fitParams = new LinearLayout.LayoutParams(-2, dp(44));
        fitParams.setMargins(dp(8), 0, 0, 0);
        bottomControls.addView(fitButton, fitParams);
        Button fullscreen = action("⛶", "تبديل ملء الشاشة");
        fullscreen.setOnClickListener(v -> changeOrientation());
        LinearLayout.LayoutParams fsParams = new LinearLayout.LayoutParams(-2, dp(44));
        fsParams.setMargins(dp(8), 0, 0, 0);
        bottomControls.addView(fullscreen, fsParams);
        FrameLayout.LayoutParams bottomParams = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.END);
        bottomParams.setMargins(dp(12), 0, dp(12), dp(22));
        root.addView(bottomControls, bottomParams);

        status = new TextView(this);
        status.setTextSize(12);
        status.setTextColor(WHITE);
        status.setText("جاري الاتصال بالبث...");
        status.setPadding(dp(11), dp(9), dp(11), dp(9));
        status.setBackground(glass());
        FrameLayout.LayoutParams statusParams = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.START);
        statusParams.setMargins(dp(12), 0, dp(12), dp(23));
        root.addView(status, statusParams);

        updateWindowMode();
        scheduleHideControls();
    }

    @Override protected void onStart() {
        super.onStart();
        if (player != null) return;
        player = new ExoPlayer.Builder(this).build();
        videoView.setPlayer(player);
        player.addListener(new Player.Listener() {
            @Override public void onPlaybackStateChanged(int state) {
                if (state == Player.STATE_BUFFERING) showStatus("جاري تحميل البث...", false);
                else if (state == Player.STATE_READY) showStatus("مباشر الآن", true);
                else if (state == Player.STATE_ENDED) showStatus("انتهى البث", false);
            }
            @Override public void onPlayerError(PlaybackException error) {
                showStatus("تعذر تشغيل المصدر الحالي", false);
            }
        });
        MediaItem.Builder item = new MediaItem.Builder().setUri(streamUrl);
        String path = streamUrl.split("\\?", 2)[0].toLowerCase(java.util.Locale.ROOT);
        if (path.endsWith(".m3u8")) item.setMimeType(MimeTypes.APPLICATION_M3U8);
        else if (path.endsWith(".mpd")) item.setMimeType(MimeTypes.APPLICATION_MPD);
        player.setMediaItem(item.build());
        applyQuality();
        player.prepare();
        player.play();
    }

    private void showStatus(String message, boolean temporary) {
        if (status == null) return;
        main.removeCallbacks(hideStatus);
        status.setText(message);
        status.setVisibility(View.VISIBLE);
        if (temporary) main.postDelayed(hideStatus, 1700);
    }

    @Override protected void onStop() {
        main.removeCallbacks(hideControls);
        main.removeCallbacks(hideStatus);
        if (videoView != null) videoView.setPlayer(null);
        if (player != null) { player.release(); player = null; }
        super.onStop();
    }
    @Override protected void onSaveInstanceState(Bundle out) {
        out.putInt("quality", maxQuality);
        out.putBoolean("fill", fillVideo);
        super.onSaveInstanceState(out);
    }

    private void scheduleHideControls() {
        main.removeCallbacks(hideControls);
        main.postDelayed(hideControls, 3200);
    }
    private void setControlsVisible(boolean visible) {
        controlsVisible = visible;
        if (topControls != null) topControls.setVisibility(visible ? View.VISIBLE : View.GONE);
        if (bottomControls != null) bottomControls.setVisibility(visible ? View.VISIBLE : View.GONE);
        if (!visible) main.removeCallbacks(hideControls);
    }
    private void chooseQuality() {
        int[] heights = {-1, 1080, 720, 480, 360};
        String[] choices = {"تلقائي (أفضل جودة متاحة)", "حتى 1080p", "حتى 720p", "حتى 480p", "حتى 360p"};
        int selected = 0;
        for (int i = 1; i < heights.length; i++) if (maxQuality == heights[i]) selected = i;
        new android.app.AlertDialog.Builder(this).setTitle("جودة البث")
                .setSingleChoiceItems(choices, selected, (dialog, which) -> {
                    maxQuality = heights[which];
                    applyQuality();
                    qualityButton.setText(maxQuality == -1 ? "تلقائي" : maxQuality + "p");
                    dialog.dismiss();
                    scheduleHideControls();
                }).setNegativeButton("إغلاق", null).show();
    }
    private void applyQuality() {
        if (player == null) return;
        int maxH = maxQuality < 0 ? Integer.MAX_VALUE : maxQuality;
        int maxW = maxQuality < 0 ? Integer.MAX_VALUE : maxQuality * 16 / 9;
        player.setTrackSelectionParameters(player.getTrackSelectionParameters().buildUpon()
                .setMaxVideoSize(maxW, maxH).build());
    }
    private void changeOrientation() {
        boolean landscape = getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE;
        setRequestedOrientation(landscape ? ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                : ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
        scheduleHideControls();
    }
    private void applyVideoScaling() {
        if (videoView == null) return;
        boolean landscape = getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE;
        // Portrait preserves the complete picture; landscape can zoom to fill without black bars.
        videoView.setResizeMode(landscape && fillVideo
                ? AspectRatioFrameLayout.RESIZE_MODE_ZOOM : AspectRatioFrameLayout.RESIZE_MODE_FIT);
        if (fitButton != null) fitButton.setText(fillVideo ? "ملء" : "احتواء");
    }
    @SuppressWarnings("deprecation")
    private void updateWindowMode() {
        boolean landscape = getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE;
        getWindow().getDecorView().setSystemUiVisibility(landscape
                ? View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                  | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_FULLSCREEN
                  | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                : View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        applyVideoScaling();
    }
    @Override public void onConfigurationChanged(Configuration config) {
        super.onConfigurationChanged(config);
        updateWindowMode();
    }
    @Override public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) updateWindowMode();
    }
}
