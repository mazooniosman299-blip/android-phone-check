package com.mazentv.live;

import android.content.Context;
import android.content.SharedPreferences;

/** Per-device OBSERVED playback, not a network guess or a promise of future availability. */
public final class PlaybackHealth {
    public static final int UNKNOWN = 0;
    public static final int PLAYED = 1;
    public static final int FAILED = 2;
    // A successful playback can become unavailable at any time. Never keep a permanent LIVE badge.
    private static final long PLAYED_TTL_MS = 2L * 60 * 60 * 1000;
    private static final long FAILED_TTL_MS = 30L * 60 * 1000;
    private final SharedPreferences prefs;

    public PlaybackHealth(Context context) {
        prefs = context.getApplicationContext().getSharedPreferences("playback_health_v1", Context.MODE_PRIVATE);
    }
    private static String key(String url) {
        try {
            byte[] bytes = java.security.MessageDigest.getInstance("SHA-256")
                    .digest(url.getBytes(java.nio.charset.StandardCharsets.UTF_8));
            StringBuilder out = new StringBuilder("channel_");
            for (byte b : bytes) out.append(String.format(java.util.Locale.ROOT, "%02x", b & 0xff));
            return out.toString();
        } catch (java.security.NoSuchAlgorithmException e) {
            throw new IllegalStateException(e);
        }
    }
    private void save(String url, int state) {
        if (!Channel.isValidStreamUrl(url)) return;
        String prefix = key(url);
        prefs.edit().putInt(prefix + "_state", state)
                .putLong(prefix + "_at", System.currentTimeMillis()).apply();
    }
    public void markRendered(String url) { save(url, PLAYED); }
    public void markFailed(String url) { save(url, FAILED); }
    public int state(String url) {
        if (!Channel.isValidStreamUrl(url)) return UNKNOWN;
        String prefix = key(url);
        int state = prefs.getInt(prefix + "_state", UNKNOWN);
        long when = prefs.getLong(prefix + "_at", 0);
        long elapsed = System.currentTimeMillis() - when;
        if (when <= 0 || elapsed < 0) return UNKNOWN;
        if (state == PLAYED && elapsed < PLAYED_TTL_MS) return PLAYED;
        if (state == FAILED && elapsed < FAILED_TTL_MS) return FAILED;
        return UNKNOWN;
    }
}
