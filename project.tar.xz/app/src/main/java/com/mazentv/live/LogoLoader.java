package com.mazentv.live;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.LruCache;
import android.widget.ImageView;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Bounded HTTPS channel artwork loader; no tracking, third-party image libraries or UI blocking. */
public final class LogoLoader {
    private static final int MAX_BYTES = 1024 * 1024;
    private final ExecutorService pool = Executors.newFixedThreadPool(3);
    private final LruCache<String, Bitmap> cache = new LruCache<String,Bitmap>(8 * 1024) {
        @Override protected int sizeOf(String key, Bitmap item) { return item.getByteCount() / 1024; }
    };
    private final Activity activity;
    private boolean closed;

    public LogoLoader(Activity activity) { this.activity = activity; }

    public void load(String url, ImageView image) {
        if (!isAcceptableImageUrl(url) || closed) return;
        image.setTag(url);
        Bitmap hit = cache.get(url);
        if (hit != null) { image.setImageBitmap(hit); return; }
        pool.execute(() -> {
            Bitmap bmp = fetch(url);
            if (bmp == null || closed) return;
            cache.put(url, bmp);
            activity.runOnUiThread(() -> {
                if (!closed && url.equals(image.getTag())) image.setImageBitmap(bmp);
            });
        });
    }

    public static boolean isAcceptableImageUrl(String value) {
        try {
            URI uri = new URI(value);
            String host = uri.getHost();
            return "https".equalsIgnoreCase(uri.getScheme()) && host != null
                    && uri.getRawUserInfo() == null && uri.getPort() == -1
                    && host.length() <= 253 && !host.equalsIgnoreCase("localhost")
                    && !host.endsWith(".local") && !host.matches("[0-9.]+")
                    && !host.contains(":");
        } catch (Exception ignored) { return false; }
    }

    private Bitmap fetch(String url) {
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(url).openConnection();
            c.setConnectTimeout(5500);
            c.setReadTimeout(6500);
            c.setInstanceFollowRedirects(false);
            c.setRequestProperty("User-Agent", "TilfaziLive/3.0");
            if (c.getResponseCode() != 200) return null;
            String type = c.getContentType();
            if (type == null || !type.toLowerCase(java.util.Locale.ROOT).startsWith("image/")) return null;
            if (c.getContentLength() > MAX_BYTES) return null;
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            try (InputStream in = c.getInputStream()) {
                byte[] buf = new byte[4096]; int n;
                while ((n=in.read(buf))!=-1) {
                    if (out.size()+n > MAX_BYTES) return null;
                    out.write(buf,0,n);
                }
            }
            byte[] raw = out.toByteArray();
            BitmapFactory.Options bounds=new BitmapFactory.Options();
            bounds.inJustDecodeBounds=true;
            BitmapFactory.decodeByteArray(raw,0,raw.length,bounds);
            if(bounds.outWidth <= 0 || bounds.outHeight <= 0 || bounds.outWidth > 8192 || bounds.outHeight > 8192)return null;
            BitmapFactory.Options opts=new BitmapFactory.Options();
            int sample=1;
            while(bounds.outWidth / sample > 260 || bounds.outHeight / sample > 260) sample *= 2;
            opts.inSampleSize=sample;
            return BitmapFactory.decodeByteArray(raw,0,raw.length,opts);
        } catch (Exception ignored) { return null; }
        finally { if(c!=null)c.disconnect(); }
    }

    public void close() { closed = true; pool.shutdownNow(); cache.evictAll(); }
}
