package com.mazentv.live;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

/** 2026 redesign: four native screens, unified design tokens and full-screen playback. */
public final class MainActivity extends Activity {
    private static final int PICK_M3U = 1007;
    private static final int EXPORT_BACKUP = 1012;
    private static final int IMPORT_BACKUP = 1013;
    private static final int MAX_PLAYLIST_BYTES = 20 * 1024 * 1024;
    private static final int TAB_HOME = 0, TAB_CHANNELS = 1, TAB_FAVORITES = 2, TAB_MORE = 3;
    private static final int BG = 0xFF090C14;
    private static final int PANEL = 0xFF141A27;
    private static final int PANEL_2 = 0xFF1D2638;
    private static final int BORDER = 0xFF2A364B;
    private static final int ACCENT = 0xFF69D9FA;
    private static final int PURPLE = 0xFFA88DFF;
    private static final int TEXT = 0xFFF3F6FC;
    private static final int MUTED = 0xFF96A4BB;
    private static final int SUCCESS = 0xFF73E7BC;

    private ChannelRepository repo;
    private LogoLoader logoLoader;
    private PlaybackHealth playbackHealth;
    private FrameLayout content;
    private LinearLayout nav;
    private GridView channelGrid;
    private ChannelGridAdapter gridAdapter;
    private TextView counter;
    private int selectedTab = TAB_HOME;
    private String category = "الكل";
    private String searchQuery = "";
    private volatile boolean loadingInitial = false;
    private ExecutorService catalogWorkers;
    private static final String CATALOG_STATUS_PREFS = "tilfazi_catalog_status_v2";
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        repo = new ChannelRepository(this);
        ensureZeeAlwanListed();
        logoLoader = new LogoLoader(this);
        playbackHealth = new PlaybackHealth(this);
        if (state != null) {
            selectedTab = state.getInt("tab", TAB_HOME);
            category = state.getString("category", "الكل");
            searchQuery = state.getString("query", "");
        }
        buildShell();
        showTab(selectedTab);
        // Never trust the old single flag: it could have been set after only
        // one small country playlist succeeded, leaving 38 channels forever.
        // Sync every source independently and repair incomplete imports.
        bootstrapDefaultCatalogs();
    }

    @Override protected void onSaveInstanceState(Bundle out) {
        out.putInt("tab", selectedTab);
        out.putString("category", category);
        out.putString("query", searchQuery);
        super.onSaveInstanceState(out);
    }

    @Override protected void onResume() {
        super.onResume();
        // Refresh the active list after returning from the video player so a
        // newly verified stream gets its LIVE mark. Do not hide broken sources
        // silently; keep their identity so fallback playback can be attempted.
        if (content != null) {
            refreshCurrent();
            // Also resume missing catalog imports after returning to the app.
            // A temporary offline first launch must not lock the user to 38 channels.
            if (!loadingInitial) bootstrapDefaultCatalogs(false);
        }
    }

    @Override protected void onDestroy() {
        if (catalogWorkers != null) catalogWorkers.shutdownNow();
        if (logoLoader != null) logoLoader.close();
        if (repo != null) repo.close();
        super.onDestroy();
    }

    private int dp(float n) { return Math.round(n * getResources().getDisplayMetrics().density); }
    private GradientDrawable shape(int bg, int r, int stroke) {
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(bg); gd.setCornerRadius(dp(r));
        if (stroke != 0) gd.setStroke(dp(1), stroke);
        return gd;
    }
    private GradientDrawable gradient(int a, int b, int r) {
        GradientDrawable gd = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{a,b});
        gd.setCornerRadius(dp(r)); return gd;
    }
    private LinearLayout vertical() { LinearLayout x = new LinearLayout(this); x.setOrientation(LinearLayout.VERTICAL); return x; }
    private LinearLayout row() { LinearLayout x = new LinearLayout(this); x.setOrientation(LinearLayout.HORIZONTAL); x.setGravity(Gravity.CENTER_VERTICAL); return x; }
    private LinearLayout.LayoutParams lp(int w, int h, int l, int t, int r, int b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w < 0 ? w : dp(w), h < 0 ? h : dp(h));
        p.setMargins(dp(l), dp(t), dp(r), dp(b)); return p;
    }
    private TextView text(String s, int sp, int color, boolean bold) {
        TextView v = new TextView(this); v.setText(s); v.setTextColor(color); v.setTextSize(sp);
        v.setGravity(Gravity.CENTER_VERTICAL); v.setTextDirection(View.TEXT_DIRECTION_FIRST_STRONG);
        if (bold) v.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD)); return v;
    }
    private TextView pill(String label, boolean active) {
        TextView v = text(label, 12, active ? BG : MUTED, active);
        v.setGravity(Gravity.CENTER); v.setPadding(dp(15), 0, dp(15), 0);
        v.setBackground(shape(active ? ACCENT : PANEL, 22, active ? 0 : BORDER)); return v;
    }
    private ImageView imageIcon(int res, int color, int size) {
        ImageView v = new ImageView(this); v.setImageResource(res); v.setColorFilter(color);
        v.setPadding(dp(3),dp(3),dp(3),dp(3));
        v.setContentDescription(getResources().getResourceEntryName(res)); return v;
    }
    private LinearLayout iconButton(int icon, String title, Runnable action) {
        LinearLayout b = row(); b.setGravity(Gravity.CENTER); b.setBackground(shape(PANEL_2, 15, BORDER));
        ImageView iv = imageIcon(icon, ACCENT, 19); b.addView(iv, lp(21,21,0,0,7,0));
        b.addView(text(title, 12, TEXT, true)); b.setPadding(dp(14),0,dp(14),0);
        b.setOnClickListener(v -> action.run()); b.setContentDescription(title); return b;
    }

    private void buildShell() {
        LinearLayout shell = vertical(); shell.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        shell.setFitsSystemWindows(true); shell.setBackgroundColor(BG);
        setContentView(shell);
        content = new FrameLayout(this);
        shell.addView(content, new LinearLayout.LayoutParams(-1,0,1));
        nav = row(); nav.setBackground(shape(0xFF101725,0,0));
        nav.setPadding(dp(10),dp(5),dp(10),dp(5));
        shell.addView(nav, new LinearLayout.LayoutParams(-1, dp(68)));
    }

    private void showTab(int tab) {
        selectedTab = tab;
        channelGrid = null; gridAdapter = null; counter = null;
        content.removeAllViews();
        if (tab == TAB_HOME) renderHome();
        else if (tab == TAB_CHANNELS) renderChannels(false);
        else if (tab == TAB_FAVORITES) renderChannels(true);
        else renderMore();
        drawNavigation();
    }

    private void drawNavigation() {
        nav.removeAllViews();
        int[] icons = {R.drawable.ic_home, R.drawable.ic_grid, R.drawable.ic_heart, R.drawable.ic_settings};
        String[] labels = {"الرئيسية", "القنوات", "المفضلة", "المزيد"};
        for (int i=0;i<4;i++) {
            final int index=i;
            boolean active=selectedTab == i;
            LinearLayout item=vertical(); item.setGravity(Gravity.CENTER);
            if (active) item.setBackground(shape(0xFF1A3041,16,0));
            item.addView(imageIcon(icons[i],active?ACCENT:MUTED,23),lp(24,24,0,0,0,3));
            TextView title=text(labels[i],11,active?TEXT:MUTED,active); title.setGravity(Gravity.CENTER);
            item.addView(title);
            item.setContentDescription(labels[i]);
            item.setOnClickListener(v -> {
                if (index == TAB_CHANNELS) { category = "الكل"; searchQuery = ""; }
                showTab(index);
            });
            nav.addView(item,new LinearLayout.LayoutParams(0,-1,1));
        }
    }

    private LinearLayout screen(String title, String subtitle) {
        LinearLayout body=vertical();body.setPadding(dp(17),dp(18),dp(17),dp(12));
        body.setBackgroundColor(BG);body.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        LinearLayout top=row();
        LinearLayout titles=vertical();
        titles.addView(text(title,26,TEXT,true));
        titles.addView(text(subtitle,12,MUTED,false),lp(-1,-2,0,3,0,0));
        top.addView(titles,new LinearLayout.LayoutParams(0,-2,1));
        ImageView badge=imageIcon(R.drawable.ic_tv,ACCENT,32);
        badge.setPadding(dp(9),dp(9),dp(9),dp(9)); badge.setBackground(shape(PANEL_2,17,BORDER));
        top.addView(badge,lp(52,52,8,0,0,0));
        body.addView(top,lp(-1,-2,0,0,0,18));return body;
    }

    private ScrollView scroll(LinearLayout body) {
        ScrollView sv=new ScrollView(this);sv.setFillViewport(true);sv.setVerticalScrollBarEnabled(false);
        sv.addView(body); content.addView(sv,new FrameLayout.LayoutParams(-1,-1));return sv;
    }

    private void renderHome() {
        LinearLayout body=screen("تلفازي", "كل ما تحبه، في مكان واحد");
        scroll(body);
        LinearLayout hero=vertical();
        hero.setPadding(dp(19),dp(22),dp(19),dp(19));
        hero.setBackground(gradient(0xFF243A5B,0xFF251941,23));
        TextView live=text("●  LIVE  •  تلفاز مباشر",12,SUCCESS,true);
        hero.addView(live);
        hero.addView(text("عالم القنوات\nفي شاشة واحدة",26,TEXT,true),lp(-1,-2,0,12,0,10));
        hero.addView(text("أخبار، ترفيه، رياضة وكرتون — اختر قناتك وابدأ المشاهدة.",13,0xFFD3DEEF,false),lp(-1,-2,0,0,0,15));
        LinearLayout controls=row();
        LinearLayout explore=iconButton(R.drawable.ic_grid,"استكشف القنوات",() -> showTab(TAB_CHANNELS));
        controls.addView(explore,new LinearLayout.LayoutParams(-1,dp(46)));
        hero.addView(controls);body.addView(hero,lp(-1,-2,0,0,0,22));

        sectionHeading(body,"استكشف حسب الاهتمام","اختر مجموعة القنوات المناسبة");
        HorizontalScrollView hs=new HorizontalScrollView(this);hs.setHorizontalScrollBarEnabled(false);
        LinearLayout categories=row();
        String[] labels={"الكل","الأطفال والكرتون","رسوم متحركة","أخبار العالم","الرياضة المفتوحة","الترفيه","مسلسلات","قنوات السودان","قنوات عُمان"};
        for(String name:labels){
            TextView c=pill(name,false);
            c.setOnClickListener(v -> {
                category="الكل"; searchQuery="";
                showTab(TAB_CHANNELS);
                if (!"الكل".equals(name)) {
                    for (CatalogSources.Source source:CatalogSources.SOURCES) {
                        if (source.title.equals(name)) { fetchPlaylist(source.url,false,false); break; }
                    }
                }
            });
            categories.addView(c,lp(-2,39,0,0,8,0));
        }
        hs.addView(categories);body.addView(hs,lp(-1,40,0,10,0,21));

        sectionHeading(body,"للمشاهدة الآن","روابط قنوات أُضيفت إلى قائمتك (غير مضمونة)");
        List<Channel> all=repo.all();
        if(all.isEmpty()) {
            emptyState(body,"القنوات بتتجهز تلقائياً","يتم استيراد القنوات المتاحة عند الاتصال بالإنترنت.","استكشاف الدليل",()->showCatalog());
        } else {
            List<Channel> selection=new ArrayList<>();
            // Prefer streams that actually produced a first video frame on this device.
            for(Channel c:all)if(playbackHealth.state(c.url)==PlaybackHealth.PLAYED
                    && repo.isFavorite(c.url) && selection.size()<8)selection.add(c);
            for(Channel c:all)if(playbackHealth.state(c.url)==PlaybackHealth.PLAYED
                    && selection.size()<8 && !selection.contains(c))selection.add(c);
            // Unknown entries are still discoverable, but not tagged LIVE.
            for(Channel c:all)if(playbackHealth.state(c.url)==PlaybackHealth.UNKNOWN
                    && selection.size()<8 && !selection.contains(c))selection.add(c);
            for(int i=0;i<selection.size();i+=2) {
                LinearLayout r=row();
                addTile(r,selection.get(i));
                if(i+1<selection.size())addTile(r,selection.get(i+1));
                else r.addView(new View(this),new LinearLayout.LayoutParams(0,dp(182),1));
                body.addView(r,lp(-1,-2,0,0,0,10));
            }
        }
        LinearLayout more=iconButton(R.drawable.ic_grid,"عرض جميع القنوات",()->showTab(TAB_CHANNELS));
        body.addView(more,lp(-1,48,0,16,0,12));
    }

    private void sectionHeading(LinearLayout body,String heading,String sub) {
        body.addView(text(heading,19,TEXT,true),lp(-1,-2,0,0,0,3));
        body.addView(text(sub,12,MUTED,false),lp(-1,-2,0,0,0,10));
    }

    private void renderChannels(boolean favorites) {
        LinearLayout body=screen(favorites?"قنواتك المفضلة":"كل القنوات",
                favorites?"القنوات التي حفظتها للمشاهدة السريعة":"تصفح وابحث حسب الاسم أو التصنيف");
        content.addView(body,new FrameLayout.LayoutParams(-1,-1));
        if(!favorites) {
            EditText input=new EditText(this);
            input.setSingleLine(true);input.setText(searchQuery);
            input.setHint("ابحث عن قناة...");input.setHintTextColor(MUTED);
            input.setTextColor(TEXT); input.setTextSize(14);
            input.setPadding(dp(16),0,dp(16),0);
            input.setBackground(shape(PANEL,16,BORDER));
            input.setInputType(android.text.InputType.TYPE_CLASS_TEXT);
            input.addTextChangedListener(new TextWatcher(){
                @Override public void beforeTextChanged(CharSequence s,int st,int c,int a){}
                @Override public void onTextChanged(CharSequence s,int st,int before,int count){searchQuery=s.toString();refreshList();}
                @Override public void afterTextChanged(Editable e){}
            });
            body.addView(input,lp(-1,49,0,0,0,13));
            HorizontalScrollView hs=new HorizontalScrollView(this);hs.setHorizontalScrollBarEnabled(false);
            LinearLayout chips=row();
            LinkedHashSet<String> groups=new LinkedHashSet<>(); groups.add("الكل");
            for(Channel c:repo.all())if(groups.size()<24)groups.add(c.group);
            for(String group:groups){
                TextView chip=pill(group,category.equals(group));
                chip.setOnClickListener(v->{category=group;renderChips(chips,groups);refreshList();});
                chips.addView(chip,lp(-2,36,0,0,8,0));
            }
            hs.addView(chips);body.addView(hs,lp(-1,39,0,0,0,11));
        }
        LinearLayout label=row();
        counter=text("",12,MUTED,false);label.addView(counter,new LinearLayout.LayoutParams(0,-2,1));
        if (!favorites){
            TextView add=pill("＋ إضافة",false);
            add.setOnClickListener(v -> showQuickActions()); label.addView(add,lp(-2,33,0,0,0,0));
        }
        body.addView(label,lp(-1,37,0,0,0,8));
        channelGrid=new GridView(this);
        int widthDp=Math.round(getResources().getDisplayMetrics().widthPixels/getResources().getDisplayMetrics().density);
        channelGrid.setNumColumns(widthDp>=720?4:widthDp>=540?3:2);
        channelGrid.setHorizontalSpacing(dp(11));channelGrid.setVerticalSpacing(dp(11));
        channelGrid.setVerticalScrollBarEnabled(false);
        channelGrid.setClipToPadding(false);
        channelGrid.setSelector(android.R.color.transparent);
        gridAdapter=new ChannelGridAdapter();channelGrid.setAdapter(gridAdapter);
        channelGrid.setOnItemClickListener((p,v,pos,id)->play(gridAdapter.shown.get(pos)));
        channelGrid.setOnItemLongClickListener((p,v,pos,id)->{
            Channel c=gridAdapter.shown.get(pos);
            new AlertDialog.Builder(this).setTitle(c.name).setItems(new String[]{"تشغيل القناة","إضافة أو إزالة من المفضلة","حذف القناة"},
                    (d,action)->{
                        if(action==0)play(c);
                        else if(action==1){repo.setFavorite(c.url,!repo.isFavorite(c.url));refreshList();}
                        else new AlertDialog.Builder(this).setMessage("حذف القناة من قائمتك؟")
                            .setPositiveButton("حذف",(dlg,w)->{repo.remove(c.url);refreshCurrent();})
                            .setNegativeButton("إلغاء",null).show();
                    }).show();return true;
        });
        FrameLayout gridArea = new FrameLayout(this);
        gridArea.addView(channelGrid, new FrameLayout.LayoutParams(-1, -1));
        TextView empty = text(favorites ? "ما أضفت قنوات للمفضلة بعد" : "ما في قنوات مطابقة حالياً", 14, MUTED, false);
        empty.setGravity(Gravity.CENTER);
        FrameLayout.LayoutParams emptyParams = new FrameLayout.LayoutParams(-1, dp(110), Gravity.CENTER);
        gridArea.addView(empty, emptyParams);
        channelGrid.setEmptyView(empty);
        body.addView(gridArea,new LinearLayout.LayoutParams(-1,0,1));
        refreshList();
    }

    private void renderChips(LinearLayout container, LinkedHashSet<String> groups) {
        container.removeAllViews();
        for(String group:groups){
            TextView chip=pill(group,category.equals(group));
            chip.setOnClickListener(v->{category=group;renderChips(container,groups);refreshList();});
            container.addView(chip,lp(-2,36,0,0,8,0));
        }
    }

    private void refreshCurrent() {
        if(content==null)return;
        if(selectedTab==TAB_HOME || selectedTab==TAB_MORE)showTab(selectedTab);
        else if(channelGrid!=null)refreshList();
    }
    private void refreshList() {
        if(gridAdapter==null)return;
        gridAdapter.shown.clear();
        String needle=searchQuery.trim().toLowerCase(Locale.ROOT);
        for(Channel c:repo.all()){
            // Never hide a requested channel because one URL or temporary network
            // attempt failed. The player will try known SAME-channel variants.
            if(selectedTab==TAB_FAVORITES && !repo.isFavorite(c.url))continue;
            if(selectedTab==TAB_CHANNELS && !"الكل".equals(category) && !category.equals(c.group))continue;
            if(selectedTab==TAB_CHANNELS && !c.matches(needle))continue;
            gridAdapter.shown.add(c);
        }
        gridAdapter.notifyDataSetChanged();
        if(counter!=null) {
            int total = repo.size();
            int visible = gridAdapter.shown.size();
            counter.setText((visible == total ? total + " قناة" : "المعروض " + visible + " من " + total + " قناة")
                    + (loadingInitial ? "  •  جاري استكمال القنوات..." : ""));
        }
    }

    private final class ChannelGridAdapter extends BaseAdapter {
        final ArrayList<Channel> shown=new ArrayList<>();
        @Override public int getCount(){return shown.size();}
        @Override public Object getItem(int i){return shown.get(i);}
        @Override public long getItemId(int i){return i;}
        @Override public View getView(int i,View convert,ViewGroup parent){return createTile(shown.get(i));}
    }

    private void addTile(LinearLayout r,Channel c){
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(182),1);
        p.setMargins(0,0,dp(10),0);
        r.addView(createTile(c),p);
    }

    private View createTile(Channel c) {
        FrameLayout outer=new FrameLayout(this);outer.setLayoutParams(new AbsListView.LayoutParams(-1, dp(182)));
        outer.setBackground(shape(PANEL,21,BORDER));
        outer.setClipToOutline(true);outer.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        LinearLayout card=vertical();card.setPadding(dp(13),dp(12),dp(13),dp(12));
        FrameLayout artwork=new FrameLayout(this);
        artwork.setBackground(gradient(0xFF202F4C,0xFF171B30,16));
        ImageView logo=new ImageView(this);logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        logo.setPadding(dp(12),dp(11),dp(12),dp(11));
        logo.setImageResource(R.drawable.ic_tv);
        artwork.addView(logo,new FrameLayout.LayoutParams(-1,-1));
        if(c.logo!=null&&!c.logo.isEmpty())logoLoader.load(c.logo,logo);
        // Do not present catalogue entries as confirmed live streams.
        // Only the actual video first-frame callback can establish observed playback.
        int observed = playbackHealth.state(c.url);
        // Show the LIVE badge only after Media3 rendered actual video frames.
        // Unknown or inaccessible sources must not be advertised as live.
        if (observed == PlaybackHealth.PLAYED) {
            TextView live=text("● مباشر",10,SUCCESS,true);
            live.setBackground(shape(0xCC13212D,10,0));
            live.setPadding(dp(7),dp(4),dp(7),dp(4));
            FrameLayout.LayoutParams liveLp=new FrameLayout.LayoutParams(-2,-2,Gravity.TOP|Gravity.START);
            liveLp.setMargins(dp(7),dp(7),0,0);
            artwork.addView(live,liveLp);
        }
        card.addView(artwork,lp(-1,103,0,0,0,10));
        TextView label=text(c.name,13,TEXT,true);label.setMaxLines(1);label.setEllipsize(android.text.TextUtils.TruncateAt.END);
        card.addView(label);
        TextView group=text(c.group,11,MUTED,false);group.setMaxLines(1);
        group.setEllipsize(android.text.TextUtils.TruncateAt.END);
        card.addView(group,lp(-1,-2,0,3,0,0));
        outer.addView(card,new FrameLayout.LayoutParams(-1,-1));
        TextView fav=text(repo.isFavorite(c.url)?"♥":"♡",24,repo.isFavorite(c.url)?PURPLE:TEXT,true);
        fav.setGravity(Gravity.CENTER);fav.setBackground(shape(0xDD1B2331,20,0));
        fav.setContentDescription(repo.isFavorite(c.url)?"إزالة من المفضلة":"إضافة للمفضلة");
        FrameLayout.LayoutParams fp=new FrameLayout.LayoutParams(dp(37),dp(37),Gravity.TOP|Gravity.END);
        fp.setMargins(dp(7),dp(18),dp(7),0);outer.addView(fav,fp);
        fav.setOnClickListener(v->{repo.setFavorite(c.url,!repo.isFavorite(c.url));refreshCurrent();});
        outer.setOnClickListener(v->play(c));
        outer.setOnLongClickListener(v->{new AlertDialog.Builder(this).setTitle(c.name)
                .setItems(new String[]{"تشغيل","إزالة من القائمة"},(dialog,which)->{
                    if(which==0)play(c); else {repo.remove(c.url);refreshCurrent();}
                }).show();return true;});
        outer.setContentDescription("قناة "+c.name);
        return outer;
    }

    private void renderMore() {
        LinearLayout body=screen("الإدارة والمصادر","كل الأدوات في مكان واحد بعيداً عن المشاهدة");scroll(body);
        sectionHeading(body,"إدارة القنوات","استيراد وإضافة وتحديث القنوات");
        settingRow(body,R.drawable.ic_download,"استيراد ملف M3U","اختر ملفاً من هاتفك",()->selectM3uFile());
        settingRow(body,R.drawable.ic_link,"استيراد رابط M3U","لقوائم البث المصرح بها",()->promptPlaylistUrl());
        settingRow(body,R.drawable.ic_plus,"إضافة قناة يدوياً","اسم القناة ورابط تشغيلها",()->promptSingleChannel());
        settingRow(body,R.drawable.ic_refresh,"تحديث الدليل","استكمال جميع مجموعات القنوات دون حذف القديمة",()->bootstrapDefaultCatalogs(true));
        settingRow(body,R.drawable.ic_grid,"استكشاف المجموعات","بلدان وأخبار وكرتون ورياضة",()->showCatalog());
        sectionHeading(body,"حماية بياناتك","احفظ القنوات والمفضلة في ملف يمكن استعادته");
        settingRow(body,R.drawable.ic_download,"نسخة احتياطية","حفظ القنوات والمفضلة في هاتفك",()->exportChannelBackup());
        settingRow(body,R.drawable.ic_plus,"استعادة نسخة احتياطية","استيراد القنوات والمفضلة دون مسح الموجود",()->importChannelBackup());
        body.addView(text("التطبيق يشغّل القنوات المتاحة من مصادر خارجية أو مضافة من المستخدم. توفر روابط البث لا يعني وجود حقوق إعادة توزيع أو فتح القنوات المدفوعة.",12,MUTED,false),lp(-1,-2,0,24,0,12));
    }

    private void ensureZeeAlwanListed() {
        // Migrate the previous dead 404 URL to a stable logical channel entry.
        // Preserve the channel's favorite state. Stream resolution runs on tap.
        boolean wasFavorite = repo.isFavorite(ZeeAlwanSource.OLD_DEAD_URL);
        repo.add(new Channel("ZEE Alwan - زي ألوان", "مسلسلات",
                ZeeAlwanSource.CHANNEL_ID, ZeeAlwanSource.CHANNEL_LOGO));
        if (wasFavorite) {
            repo.setFavorite(ZeeAlwanSource.CHANNEL_ID, true);
        }
        repo.remove(ZeeAlwanSource.OLD_DEAD_URL);
    }

    private void settingRow(LinearLayout parent,int icon,String title,String subtitle,Runnable act) {
        LinearLayout entry=row();entry.setPadding(dp(15),dp(14),dp(15),dp(14));entry.setBackground(shape(PANEL,17,BORDER));
        ImageView iv=imageIcon(icon,ACCENT,27);entry.addView(iv,lp(31,31,0,0,12,0));
        LinearLayout copy=vertical();copy.addView(text(title,14,TEXT,true));
        copy.addView(text(subtitle,11,MUTED,false),lp(-1,-2,0,4,0,0));
        entry.addView(copy,new LinearLayout.LayoutParams(0,-2,1));
        entry.addView(text("‹",25,MUTED,false));
        entry.setOnClickListener(v->act.run());parent.addView(entry,lp(-1,-2,0,0,0,9));
    }

    private void emptyState(LinearLayout parent,String title,String description,String actionLabel,Runnable action) {
        LinearLayout empty=vertical();empty.setGravity(Gravity.CENTER);empty.setPadding(dp(20),dp(24),dp(20),dp(24));
        empty.setBackground(shape(PANEL,20,BORDER));
        ImageView v=imageIcon(R.drawable.ic_tv,ACCENT,44);empty.addView(v,lp(52,52,0,0,0,8));
        TextView h=text(title,16,TEXT,true);h.setGravity(Gravity.CENTER);empty.addView(h);
        TextView sub=text(description,12,MUTED,false);sub.setGravity(Gravity.CENTER);empty.addView(sub,lp(-1,-2,0,7,0,13));
        LinearLayout call=iconButton(R.drawable.ic_grid,actionLabel,action);empty.addView(call,lp(-2,45,0,0,0,0));
        parent.addView(empty,lp(-1,-2,0,0,0,8));
    }

    @androidx.annotation.OptIn(markerClass = androidx.media3.common.util.UnstableApi.class)
    private void play(Channel c) {
        if (ZeeAlwanSource.matches(c.name)) {
            // Critical bug fix: a Zee Alwan HLS/DASH source must NOT be
            // intercepted by the browser-only provider activity. Prefer the
            // user's permitted native stream even if a logical catalog tile
            // was tapped instead of that URL's own row.
            List<String> direct = ZeeAlwanSource.nativeAlternatives(c, repo.all());
            if (!direct.isEmpty()) {
                Channel playable = new Channel(c.name, c.group, direct.get(0), c.logo);
                launchPlayer(playable, direct.get(0));
            } else {
                askForZeeSource(c);
            }
        } else {
            launchPlayer(c, c.url);
        }
    }

    /** A provider webpage cannot be rebranded as our native stream player. */
    private void askForZeeSource(Channel channel) {
        new AlertDialog.Builder(this)
                .setTitle("زي ألوان")
                .setMessage("مشغّل تلفازي يحتاج رابط بث HLS أو DASH تسمح به الجهة الناشرة."
                        + " روابط القناة القديمة متوقفة، ولن نستبدلها بصفحة موقع أو رابط غير مؤكد.")
                .setPositiveButton("إضافة مصدر مباشر", (dialog, which) -> {
                    EditText field = new EditText(this);
                    field.setSingleLine(true);
                    field.setHint("https://example.com/live.m3u8");
                    field.setInputType(android.text.InputType.TYPE_CLASS_TEXT
                            | android.text.InputType.TYPE_TEXT_VARIATION_URI);
                    new AlertDialog.Builder(this).setTitle("مصدر زي ألوان المباشر")
                            .setView(field)
                            .setPositiveButton("إضافة وتشغيل", (d, w) -> {
                                String stream = field.getText().toString().trim();
                                if (!ZeeAlwanSource.isDirectMediaUrl(stream)) {
                                    message("رابط غير مناسب", "أدخل رابط بث HLS (.m3u8) أو DASH (.mpd) صالحاً ومصرحاً به.");
                                    return;
                                }
                                Channel nativeChannel = new Channel("ZEE Alwan - زي ألوان", channel.group,
                                        stream, channel.logo);
                                repo.add(nativeChannel);
                                launchPlayer(nativeChannel, stream);
                                refreshCurrent();
                            }).setNegativeButton("إلغاء", null).show();
                })
                .setNegativeButton("إغلاق", null)
                .show();
    }

    @androidx.annotation.OptIn(markerClass = androidx.media3.common.util.UnstableApi.class)
    private void launchPlayer(Channel channel, String playableUrl) {
        getPreferences(MODE_PRIVATE).edit().putString("last_channel", channel.url).apply();
        Intent i = new Intent(this, PlayerActivity.class);
        i.putExtra("name", channel.name);
        i.putExtra("group", channel.group);
        // Try variants observed playing on THIS device first; keep the selected
        // logical channel ID separate so a backup still verifies that channel.
        java.util.ArrayList<String> sources = new java.util.ArrayList<>(
                ChannelFallbacks.alternatives(channel, repo.all()));
        sources.sort((left, right) -> Integer.compare(
                streamPriority(playbackHealth.state(left)), streamPriority(playbackHealth.state(right))));
        i.putExtra("url", sources.isEmpty() ? playableUrl : sources.get(0));
        i.putExtra("channel_url", channel.url);
        i.putStringArrayListExtra("alternate_urls", sources);
        startActivity(i);
    }

    // Lower values are better. A previously rendered frame is stronger evidence
    // than a playlist entry, while a recently denied URL should be attempted last.
    private static int streamPriority(int state) {
        return state == PlaybackHealth.PLAYED ? 0 : state == PlaybackHealth.UNKNOWN ? 1 : 2;
    }

    private void showQuickActions() {
        new AlertDialog.Builder(this).setTitle("إدارة القنوات")
                .setItems(new String[]{"قائمة M3U من الإنترنت","ملف M3U من الجهاز","إضافة قناة جديدة","استكشاف الدليل"},
                (dialog,which)->{
                    if(which==0)promptPlaylistUrl();
                    else if(which==1)selectM3uFile();
                    else if(which==2)promptSingleChannel();
                    else if(which==3)showCatalog();
                }).show();
    }

    private void selectM3uFile() {
        Intent pick = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        pick.setType("*/*");
        pick.addCategory(Intent.CATEGORY_OPENABLE);
        pick.putExtra(Intent.EXTRA_MIME_TYPES, new String[] {
                "audio/x-mpegurl", "application/x-mpegURL", "text/plain", "application/octet-stream" });
        try { startActivityForResult(pick, PICK_M3U); }
        catch (Exception error) { toast("تعذر فتح مدير الملفات"); }
    }

    private void exportChannelBackup() {
        Intent save = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        save.addCategory(Intent.CATEGORY_OPENABLE);
        save.setType("application/json");
        save.putExtra(Intent.EXTRA_TITLE, "tilfazi-channels-backup.json");
        try { startActivityForResult(save, EXPORT_BACKUP); }
        catch (RuntimeException e) { toast("لا يوجد مدير ملفات لحفظ النسخة الاحتياطية"); }
    }

    private void importChannelBackup() {
        Intent pick = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        pick.addCategory(Intent.CATEGORY_OPENABLE);
        pick.setType("application/json");
        try { startActivityForResult(pick, IMPORT_BACKUP); }
        catch (RuntimeException e) { toast("لا يوجد مدير ملفات لاستعادة النسخة الاحتياطية"); }
    }

    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (result != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        if (request == EXPORT_BACKUP) {
            new Thread(() -> {
                try (java.io.OutputStream output = getContentResolver().openOutputStream(uri, "w")) {
                    if (output == null) throw new java.io.IOException("تعذر فتح ملف الحفظ");
                    int count = ChannelBackup.write(output, repo);
                    runOnUiThread(() -> {
                        if (!isFinishing() && !isDestroyed()) toast("تم حفظ " + count + " قناة ومفضلاتها");
                    });
                } catch (Exception e) {
                    runOnUiThread(() -> {
                        if (!isFinishing() && !isDestroyed()) message("لم تُحفظ النسخة الاحتياطية", e.getMessage());
                    });
                }
            }, "tilfazi-backup-export").start();
            return;
        }
        if (request == IMPORT_BACKUP) {
            new Thread(() -> {
                try (InputStream in = getContentResolver().openInputStream(uri)) {
                    if (in == null) throw new java.io.IOException("تعذر قراءة النسخة الاحتياطية");
                    ChannelBackup.RestoreResult resultBackup = ChannelBackup.restore(in, repo);
                    runOnUiThread(() -> {
                        if (isFinishing() || isDestroyed()) return;
                        showTab(TAB_CHANNELS);
                        message("استُعيدت بياناتك", "قنوات صالحة: " + resultBackup.valid
                                + " • أضيفت: " + resultBackup.added + " • مفضلات: " + resultBackup.favorites);
                    });
                } catch (Exception e) {
                    runOnUiThread(() -> {
                        if (!isFinishing() && !isDestroyed()) message("تعذرت الاستعادة", e.getMessage());
                    });
                }
            }, "tilfazi-backup-import").start();
            return;
        }
        if (request != PICK_M3U) return;
        new Thread(() -> {
            try (InputStream in = getContentResolver().openInputStream(uri)) {
                if (in == null) throw new Exception("تعذر فتح الملف");
                importText(new String(readLimited(in), StandardCharsets.UTF_8));
            } catch (Exception e) { runOnUiThread(() -> message("تعذر استيراد الملف", e.getMessage())); }
        }).start();
    }

    private static byte[] readLimited(InputStream input) throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = input.read(buf)) != -1) {
            if (out.size() + n > MAX_PLAYLIST_BYTES) throw new Exception("حجم القائمة أكبر من 20 ميغابايت");
            out.write(buf, 0, n);
        }
        return out.toByteArray();
    }

    private void importText(String data) throws Exception {
        List<Channel> found = M3uParser.parse(data, ChannelRepository.capacity());
        int imported = repo.addMany(found);
        runOnUiThread(() -> {
            category = "الكل";
            searchQuery = "";
            showTab(TAB_CHANNELS);
            message("استيراد القائمة", "أضيف " + imported + " رابطاً، لم يُختبر تشغيلها بعد. تم تجاهل الروابط غير الصالحة والمكررة.");
        });
    }

    private void promptPlaylistUrl() {
        EditText input = new EditText(this);
        input.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_URI);
        input.setHint("https://example.com/playlist.m3u");
        new AlertDialog.Builder(this).setTitle("رابط قائمة M3U")
                .setMessage("استخدم رابطاً تملك حق الوصول إليه. لن يتم تجاوز أي حماية أو اشتراك.")
                .setView(input).setPositiveButton("استيراد", (d, which) -> fetchPlaylist(input.getText().toString().trim(), false, false))
                .setNegativeButton("إلغاء", null).show();
    }

    private void fetchPlaylist(String url, boolean silent, boolean bootstrap) {
        if (!Channel.isValidStreamUrl(url)) {
            if (!silent) toast("الرابط غير صالح");
            return;
        }
        if (!silent) toast("جاري تنزيل القائمة...");
        new Thread(() -> {
            HttpURLConnection connection = null;
            try {
                connection = (HttpURLConnection) new URL(url).openConnection();
                connection.setConnectTimeout(12000);
                connection.setReadTimeout(22000);
                connection.setRequestProperty("User-Agent", "TilfaziLive/3.2 Android-TV-Client");
                connection.setRequestProperty("Accept", "application/x-mpegURL, audio/x-mpegurl, text/plain, */*");
                if (connection.getResponseCode() != 200) throw new Exception("الخادم أعاد رمز " + connection.getResponseCode());
                try (InputStream in = connection.getInputStream()) {
                    String payload = new String(readLimited(in), StandardCharsets.UTF_8);
                    List<Channel> found = M3uParser.parse(payload, ChannelRepository.capacity());
                    int added = repo.addMany(found);
                    runOnUiThread(() -> {
                        refreshCurrent();
                        if (!silent) message("تم الاستيراد", "أضيف " + added + " رابط قناة غير مختبر.");
                        else if (!bootstrap) toast("تمت إضافة " + added + " قناة");
                    });
                }
            } catch (Exception e) {
                runOnUiThread(() -> {
                    if (!silent) message("تعذر تحديث قائمة القنوات", e.getMessage());
                    else if (!bootstrap) toast("تعذر تحميل القائمة");
                });
            } finally { if (connection != null) connection.disconnect(); }
        }).start();
    }

    private void bootstrapDefaultCatalogs() {
        bootstrapDefaultCatalogs(false);
    }

    /**
     * Downloads catalogues independently rather than accepting a single global
     * "import finished" flag after one short playlist succeeds. Each successful
     * catalogue is recorded separately; missing sources are retried safely.
     * Existing SQLite channels and favorites are NEVER deleted by a refresh.
     */
    private void bootstrapDefaultCatalogs(boolean force) {
        if (loadingInitial) {
            if (force) toast("تحديث القنوات جاري بالفعل");
            return;
        }
        SharedPreferences progress = getSharedPreferences(CATALOG_STATUS_PREFS, MODE_PRIVATE);
        long now = System.currentTimeMillis();
        ArrayList<CatalogSources.Source> pending = new ArrayList<>();
        for (CatalogSources.Source source : CatalogSources.startupSources()) {
            String key = source.url;
            boolean completed = progress.getBoolean("ok:" + key, false);
            long lastSuccess = progress.getLong("success:" + key, 0L);
            long lastAttempt = progress.getLong("attempt:" + key, 0L);
            if (CatalogRefreshPolicy.shouldFetch(force, completed, lastAttempt, lastSuccess, now))
                pending.add(source);
        }
        // Rescue a partial migration or an interrupted first import. The full
        // public index is deliberately NOT fetched at every launch: only when
        // fewer than 300 entries exist and its own independent retry policy
        // permits it. Never overwrite or delete the user's local channels.
        CatalogSources.Source fullIndex = CatalogSources.SOURCES[CatalogSources.SOURCES.length - 1];
        if (CatalogRefreshPolicy.needsIndexRecovery(repo.size())) {
            String key = fullIndex.url;
            if (CatalogRefreshPolicy.shouldFetch(force,
                    progress.getBoolean("ok:" + key, false),
                    progress.getLong("attempt:" + key, 0L),
                    progress.getLong("success:" + key, 0L), now)) {
                pending.add(0, fullIndex);
            }
        }
        if (pending.isEmpty()) {
            if (force) toast("القوائم محدّثة حالياً");
            return;
        }
        loadingInitial = true;
        refreshCurrent();
        if (force) toast("جاري استكمال الدليل بدون حذف قنواتك...");
        // Three workers keep failed hosts from blocking all other sources.
        catalogWorkers = Executors.newFixedThreadPool(3);
        ExecutorService workers = catalogWorkers;
        CountDownLatch finished = new CountDownLatch(pending.size());
        AtomicInteger added = new AtomicInteger();
        AtomicInteger completed = new AtomicInteger();
        AtomicInteger deferred = new AtomicInteger();
        for (CatalogSources.Source source : pending) {
            workers.execute(() -> {
                HttpURLConnection connection = null;
                try {
                    progress.edit().putLong("attempt:" + source.url, System.currentTimeMillis()).apply();
                    connection = (HttpURLConnection) new URL(source.url).openConnection();
                    connection.setConnectTimeout(10000);
                    connection.setReadTimeout(18000);
                    connection.setRequestProperty("User-Agent", "TilfaziLive/3.4 Android-TV-Client");
                    connection.setRequestProperty("Accept", "application/x-mpegURL, audio/x-mpegurl, text/plain, */*");
                    if (connection.getResponseCode() != 200) throw new java.io.IOException("Catalog HTTP " + connection.getResponseCode());
                    List<Channel> found;
                    try (InputStream stream = connection.getInputStream()) {
                        found = M3uParser.parse(new String(readLimited(stream), StandardCharsets.UTF_8),
                                ChannelRepository.capacity());
                    }
                    if (found.isEmpty()) throw new java.io.IOException("Empty catalog");
                    added.addAndGet(repo.addMany(found));
                    progress.edit().putBoolean("ok:" + source.url, true)
                            .putLong("success:" + source.url, System.currentTimeMillis()).apply();
                    completed.incrementAndGet();
                    runOnUiThread(() -> {
                        if (!isFinishing() && !isDestroyed()) refreshCurrent();
                    });
                } catch (Exception e) {
                    // Save the exact reason for developer diagnostics, never
                    // treat a missing catalog as a successful global sync.
                    android.util.Log.w("TilfaziCatalog", "Source unavailable: " + source.title, e);
                    deferred.incrementAndGet();
                } finally {
                    if (connection != null) connection.disconnect();
                    finished.countDown();
                }
            });
        }
        workers.execute(() -> {
            // This tail task executes after queued jobs; the latch also waits
            // for any concurrently running jobs to finish.
            try { finished.await(); }
            catch (InterruptedException e) { Thread.currentThread().interrupt(); }
            runOnUiThread(() -> {
                loadingInitial = false;
                if (isFinishing() || isDestroyed()) return;
                refreshCurrent();
                if (force) toast("القنوات الموجودة " + repo.size()
                        + " • مجموعات محدّثة " + completed.get()
                        + (deferred.get() > 0 ? " • مجموعات ستُستكمل لاحقاً " + deferred.get() : ""));
            });
            workers.shutdown();
        });
    }

    private void showCatalog() {
        CatalogSources.Source[] sources = CatalogSources.SOURCES;
        String[] labels = new String[sources.length];
        for (int i = 0; i < sources.length; i++) labels[i] = sources[i].title + "  •  " + sources[i].note;
        new AlertDialog.Builder(this)
                .setTitle("استكشاف مجموعات القنوات")
                .setItems(labels, (dialog, which) -> fetchPlaylist(sources[which].url, false, false))
                .setNeutralButton("عن الدليل والحقوق", (dialog, which) -> message("مصادر القنوات", "القوائم مصدرها مشروع IPTV-org الخارجي. لا يضمن التطبيق توفر القنوات أو حق إعادة نشر بثها، ولا يفك أي اشتراك أو تشفير. يمكنك أيضاً إضافة قنوات تملك إذناً بمشاهدتها من رابط خاص."))
                .setNegativeButton("إغلاق", null)
                .show();
    }

    private void promptSingleChannel() {
        LinearLayout form = vertical();
        form.setPadding(dp(20), 0, dp(20), 0);
        EditText name = new EditText(this);
        name.setHint("اسم القناة");
        EditText url = new EditText(this);
        url.setHint("رابط البث HLS / DASH / MP4");
        url.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_URI);
        EditText group = new EditText(this);
        group.setHint("التصنيف (اختياري)");
        form.addView(name); form.addView(url); form.addView(group);
        new AlertDialog.Builder(this).setTitle("إضافة قناة")
                .setView(form).setPositiveButton("حفظ", (dialog, which) -> {
                    String n = name.getText().toString().trim();
                    String u = url.getText().toString().trim();
                    if (n.isEmpty() || !Channel.isValidStreamUrl(u)) {
                        message("لم تتم الإضافة", "أدخل اسماً ورابط بث HTTP أو HTTPS صالحاً.");
                        return;
                    }
                    int count = repo.add(new Channel(n, group.getText().toString().trim(), u, ""));
                    category = "الكل"; searchQuery = ""; showTab(TAB_CHANNELS);
                    toast(count == 1 ? "تمت إضافة القناة" : "القناة موجودة بالفعل أو القائمة ممتلئة");
                }).setNegativeButton("إلغاء", null).show();
    }

    private void message(String title, String body) {
        new AlertDialog.Builder(this).setTitle(title).setMessage(body == null ? "خطأ غير معروف" : body)
                .setPositiveButton("حسناً", null).show();
    }

    private void toast(String text) { Toast.makeText(this, text, Toast.LENGTH_SHORT).show(); }
}
