package com.mazentv.live;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;

public final class MainActivity extends Activity {
    private static final int PICK_M3U = 1007;
    private static final int MAX_PLAYLIST_BYTES = 20 * 1024 * 1024;
    private static final int BG = 0xFF0C0D11;
    private static final int CARD = 0xFF191B21;
    private static final int CARD2 = 0xFF22252C;
    private static final int ACCENT = 0xFFA7FA71;
    private static final int MUTED = 0xFF989CA8;
    private static final int WHITE = 0xFFF4F6F9;

    private ChannelRepository repo;
    private ChannelAdapter adapter;
    private TextView counter;
    private EditText search;
    private LinearLayout filters;
    private String category = "الكل";
    private boolean favoritesOnly = false;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        repo = new ChannelRepository(this);
        buildUI();
        refresh();
        // First launch: load genuine public live-stream listings rather than demo footage.
        // This directory is third-party and channels may be restricted or unlicensed.
        if (repo.size() == 0) fetchPlaylist(CatalogSources.SOURCES[0].url, true);
    }

    private int dp(float v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    private GradientDrawable shape(int fill, int corner) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(fill);
        d.setCornerRadius(dp(corner));
        return d;
    }

    private TextView text(String label, int size, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(label);
        v.setTextSize(size);
        v.setTextColor(color);
        v.setGravity(Gravity.CENTER_VERTICAL);
        if (bold) v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        v.setTextDirection(View.TEXT_DIRECTION_FIRST_STRONG);
        return v;
    }

    private Button button(String label, boolean main) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextColor(main ? BG : WHITE);
        b.setTextSize(12);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setBackground(shape(main ? ACCENT : CARD2, 13));
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        b.setPadding(dp(10), dp(9), dp(10), dp(9));
        return b;
    }

    private LinearLayout vertical() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        return layout;
    }
    private LinearLayout horizontal() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.HORIZONTAL);
        layout.setGravity(Gravity.CENTER_VERTICAL);
        return layout;
    }
    private LinearLayout.LayoutParams lp(int w, int h, int l, int t, int r, int b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams((w == -1 || w == -2) ? w : dp(w), h == -1 || h == -2 ? h : dp(h));
        p.setMargins(dp(l), dp(t), dp(r), dp(b));
        return p;
    }

    private void buildUI() {
        LinearLayout root = vertical();
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.setFitsSystemWindows(true);
        root.setBackgroundColor(BG);
        root.setPadding(dp(16), dp(10), dp(16), dp(6));
        setContentView(root);

        LinearLayout header = horizontal();
        LinearLayout branding = vertical();
        TextView heading = text("تلفازي", 29, WHITE, true);
        branding.addView(heading);
        TextView caption = text("عالم البث المباشر بين يديك", 12, MUTED, false);
        branding.addView(caption, lp(-1, -2, 0, 0, 0, 0));
        header.addView(branding, new LinearLayout.LayoutParams(0, dp(61), 1));
        TextView live = text("●  LIVE", 14, ACCENT, true);
        live.setGravity(Gravity.CENTER);
        live.setBackground(shape(0xFF1A3021, 13));
        header.addView(live, lp(88, 43, 4, 0, 0, 0));
        root.addView(header, lp(-1, -2, 0, 5, 0, 17));

        LinearLayout feature = vertical();
        GradientDrawable gradient = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[] { 0xFF253B2F, 0xFF14201E, 0xFF181B22 });
        gradient.setCornerRadius(dp(20));
        feature.setBackground(gradient);
        feature.setPadding(dp(18), dp(13), dp(18), dp(13));
        feature.addView(text("◉  قنوات بث مباشر حقيقية", 18, WHITE, true));
        feature.addView(text("قنوات عربية وأخبار ورياضة مجانية من أدلة عامة. التوفر والجودة بحسب المصدر.", 13, 0xFFCAD6D0, false),
                lp(-1, -2, 0, 7, 0, 8));
        Button browse = button("▶  استكشاف القنوات المباشرة", true);
        browse.setOnClickListener(v -> showCatalog());
        feature.addView(browse, lp(-1, 42, 0, 0, 0, 0));
        root.addView(feature, lp(-1, -2, 0, 0, 0, 12));

        LinearLayout actions = horizontal();
        Button addUrl = button("رابط M3U", false);
        Button addChannel = button("ملف M3U", false);
        Button official = button("بث رسمي", false);
        actions.addView(addUrl, new LinearLayout.LayoutParams(0, dp(42), 1));
        actions.addView(addChannel, new LinearLayout.LayoutParams(0, dp(42), 1));
        actions.addView(official, new LinearLayout.LayoutParams(0, dp(42), 1));
        addUrl.setOnClickListener(v -> promptPlaylistUrl());
        addChannel.setOnClickListener(v -> selectM3uFile());
        official.setOnClickListener(v -> showOfficialSources());
        root.addView(actions, lp(-1, -2, 0, 0, 0, 12));

        search = new EditText(this);
        search.setSingleLine(true);
        search.setHint("⌕   ابحث عن قناة أو تصنيف...");
        search.setTextSize(14);
        search.setHintTextColor(MUTED);
        search.setTextColor(WHITE);
        search.setPadding(dp(15), 0, dp(15), 0);
        search.setBackground(shape(CARD, 14));
        search.setInputType(android.text.InputType.TYPE_CLASS_TEXT);
        root.addView(search, lp(-1, 47, 0, 0, 0, 7));
        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int st, int c, int a) {}
            @Override public void onTextChanged(CharSequence s, int st, int b, int c) { refreshList(); }
            @Override public void afterTextChanged(Editable e) {}
        });

        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setFillViewport(false);
        hs.setHorizontalScrollBarEnabled(false);
        filters = horizontal();
        hs.addView(filters);
        root.addView(hs, lp(-1, 43, 0, 0, 0, 7));
        counter = text("", 12, MUTED, false);
        root.addView(counter, lp(-1, 24, 0, 0, 0, 3));

        ListView list = new ListView(this);
        adapter = new ChannelAdapter();
        list.setAdapter(adapter);
        list.setDivider(null);
        list.setDividerHeight(dp(7));
        list.setVerticalScrollBarEnabled(false);
        list.setCacheColorHint(Color.TRANSPARENT);
        list.setSelector(android.R.color.transparent);
        list.setOnItemClickListener((parent, view, position, id) -> play(adapter.shown.get(position)));
        list.setOnItemLongClickListener((parent, view, position, id) -> {
            Channel c = adapter.shown.get(position);
            new AlertDialog.Builder(this).setTitle(c.name).setMessage("هل تريد حذف هذه القناة من قائمتك؟")
                    .setPositiveButton("حذف", (dialog, which) -> { repo.remove(c.url); refresh(); })
                    .setNegativeButton("إلغاء", null).show();
            return true;
        });
        root.addView(list, new LinearLayout.LayoutParams(-1, 0, 1));
        TextView tip = text("دليل خارجي للقنوات • الروابط قد تتوقف أو تخضع لحقوق وبث جغرافي", 11, MUTED, false);
        tip.setGravity(Gravity.CENTER);
        root.addView(tip, lp(-1, 31, 0, 2, 0, 0));
    }

    private void refresh() {
        filters.removeAllViews();
        LinkedHashSet<String> names = new LinkedHashSet<>();
        names.add("الكل");
        names.add("المفضلة");
        for (Channel c : repo.all()) if (names.size() < 36) names.add(c.group);
        for (String name : names) {
            boolean selected = name.equals("المفضلة") ? favoritesOnly : (!favoritesOnly && name.equals(category));
            TextView chip = text(name, 12, selected ? BG : WHITE, selected);
            chip.setGravity(Gravity.CENTER);
            chip.setPadding(dp(17), 0, dp(17), 0);
            chip.setBackground(shape(selected ? ACCENT : CARD, 14));
            chip.setOnClickListener(v -> {
                favoritesOnly = name.equals("المفضلة");
                if (!favoritesOnly) category = name;
                refresh();
            });
            filters.addView(chip, lp(-2, 35, 0, 0, 7, 0));
        }
        refreshList();
    }

    private void refreshList() {
        if (adapter == null) return;
        adapter.shown.clear();
        String needle = search == null ? "" : search.getText().toString().trim().toLowerCase(Locale.ROOT);
        for (Channel c : repo.all()) {
            if (favoritesOnly && !repo.isFavorite(c.url)) continue;
            if (!favoritesOnly && !"الكل".equals(category) && !category.equals(c.group)) continue;
            if (!c.matches(needle)) continue;
            adapter.shown.add(c);
        }
        adapter.notifyDataSetChanged();
        counter.setText("القنوات المتاحة في قائمتك: " + adapter.shown.size() + " / " + repo.size());
    }

    private final class ChannelAdapter extends BaseAdapter {
        private final ArrayList<Channel> shown = new ArrayList<>();
        @Override public int getCount() { return shown.size(); }
        @Override public Object getItem(int p) { return shown.get(p); }
        @Override public long getItemId(int p) { return p; }
        @Override public View getView(int p, View convert, ViewGroup parent) {
            Channel c = shown.get(p);
            LinearLayout row = horizontal();
            row.setBackground(shape(CARD, 16));
            row.setPadding(dp(11), dp(7), dp(12), dp(7));
            TextView icon = text("▶", 23, ACCENT, true);
            icon.setGravity(Gravity.CENTER);
            icon.setBackground(shape(0xFF273B2E, 12));
            row.addView(icon, lp(51, 53, 0, 0, 11, 0));
            LinearLayout info = vertical();
            TextView title = text(c.name, 14, WHITE, true);
            title.setMaxLines(2);
            info.addView(title);
            info.addView(text("◉  " + c.group, 11, MUTED, false), lp(-1, -2, 0, 4, 0, 0));
            row.addView(info, new LinearLayout.LayoutParams(0, -2, 1));
            TextView star = text(repo.isFavorite(c.url) ? "★" : "☆", 28,
                    repo.isFavorite(c.url) ? ACCENT : MUTED, false);
            star.setGravity(Gravity.CENTER);
            star.setContentDescription(repo.isFavorite(c.url) ? "إزالة من المفضلة" : "إضافة للمفضلة");
            star.setOnClickListener(v -> {
                repo.setFavorite(c.url, !repo.isFavorite(c.url));
                refreshList();
            });
            row.addView(star, lp(42, 54, 0, 0, 0, 0));
            return row;
        }
    }

    private void play(Channel c) {
        Intent i = new Intent(this, PlayerActivity.class);
        i.putExtra("name", c.name);
        i.putExtra("url", c.url);
        i.putExtra("group", c.group);
        startActivity(i);
    }

    private void selectM3uFile() {
        Intent pick = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        pick.setType("*/*");
        pick.addCategory(Intent.CATEGORY_OPENABLE);
        pick.putExtra(Intent.EXTRA_MIME_TYPES, new String[] {
                "audio/x-mpegurl", "application/x-mpegURL", "text/plain", "application/octet-stream" });
        try { startActivityForResult(pick, PICK_M3U); }
        catch (Exception error) { toast("تعذر فتح مدير الملفات"); }
    }

    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request != PICK_M3U || result != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        new Thread(() -> {
            try (InputStream in = getContentResolver().openInputStream(uri)) {
                if (in == null) throw new Exception("تعذر فتح الملف");
                importText(new String(readLimited(in), StandardCharsets.UTF_8));
            } catch (Exception e) { runOnUiThread(() -> message("تعذر استيراد الملف", e.getMessage())); }
        }).start();
    }

    private static byte[] readLimited(InputStream input) throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = input.read(buf)) != -1) {
            if (out.size() + n > MAX_PLAYLIST_BYTES) throw new Exception("حجم القائمة أكبر من 4 ميغابايت");
            out.write(buf, 0, n);
        }
        return out.toByteArray();
    }

    private void importText(String data) throws Exception {
        List<Channel> found = M3uParser.parse(data, ChannelRepository.capacity());
        int imported = repo.addMany(found);
        runOnUiThread(() -> {
            category = "الكل";
            favoritesOnly = false;
            refresh();
            message("استيراد القائمة", "أضيفت " + imported + " قناة جديدة. تم تجاهل الروابط غير الصالحة والمكررة.");
        });
    }

    private void promptPlaylistUrl() {
        EditText input = new EditText(this);
        input.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_URI);
        input.setHint("https://example.com/playlist.m3u");
        new AlertDialog.Builder(this).setTitle("رابط قائمة M3U")
                .setMessage("استخدم رابطاً تملك حق الوصول إليه. لن يتم تجاوز أي حماية أو اشتراك.")
                .setView(input).setPositiveButton("استيراد", (d, which) -> fetchPlaylist(input.getText().toString().trim()))
                .setNegativeButton("إلغاء", null).show();
    }

    private void fetchPlaylist(String url) { fetchPlaylist(url, false); }

    private void fetchPlaylist(String url, boolean silent) {
        if (!Channel.isValidStreamUrl(url)) { toast("الرابط غير صالح"); return; }
        if (!silent) toast("جاري تنزيل قائمة البث المباشر...");
        new Thread(() -> {
            HttpURLConnection connection = null;
            try {
                connection = (HttpURLConnection) new URL(url).openConnection();
                connection.setConnectTimeout(12000);
                connection.setReadTimeout(22000);
                connection.setRequestProperty("User-Agent", "TilfaziLive/2.0 Android-TV-Client");
                connection.setRequestProperty("Accept", "application/x-mpegURL, audio/x-mpegurl, text/plain, */*");
                if (connection.getResponseCode() != 200) throw new Exception("الخادم أعاد رمز " + connection.getResponseCode());
                try (InputStream in = connection.getInputStream()) {
                    if (silent) importTextSilently(new String(readLimited(in), StandardCharsets.UTF_8));
                    else importText(new String(readLimited(in), StandardCharsets.UTF_8));
                }
            } catch (Exception e) {
                runOnUiThread(() -> {
                    if (silent) toast("تعذر تحميل القنوات تلقائياً؛ افتح دليل القنوات للمحاولة");
                    else message("فشل تنزيل القائمة", e.getMessage());
                });
            } finally { if (connection != null) connection.disconnect(); }
        }).start();
    }

    private void importTextSilently(String data) throws Exception {
        List<Channel> found = M3uParser.parse(data, ChannelRepository.capacity());
        int added = repo.addMany(found);
        runOnUiThread(() -> { refresh(); toast("القنوات المتاحة: " + repo.size() + " (جديد: " + added + ")"); });
    }

    private void showCatalog() {
        CatalogSources.Source[] sources = CatalogSources.SOURCES;
        String[] labels = new String[sources.length];
        for (int i = 0; i < sources.length; i++) labels[i] = sources[i].title + "  •  " + sources[i].note;
        new AlertDialog.Builder(this)
            .setTitle("قنوات خارجية مجانية (التوفر متغيّر)")
            .setItems(labels, (dialog, which) -> fetchPlaylist(sources[which].url))
            .setNeutralButton("عن الدليل والحقوق", (dialog, which) -> message("مصادر القنوات", "القوائم مصدرها مشروع IPTV-org الخارجي. لا يضمن التطبيق توفر القنوات أو حق إعادة نشر بثها، ولا يفك أي اشتراك أو تشفير. يمكنك إضافة قنوات تملك إذناً بمشاهدتها من رابط خاص."))
            .setNegativeButton("إغلاق", null)
            .show();
    }

    private void promptSingleChannel() {
        LinearLayout form = vertical();
        form.setPadding(dp(20), 0, dp(20), 0);
        EditText name = new EditText(this);
        name.setHint("اسم القناة");
        EditText url = new EditText(this);
        url.setHint("رابط البث HLS / DASH / MP4");
        url.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_URI);
        EditText group = new EditText(this);
        group.setHint("التصنيف (اختياري)");
        form.addView(name); form.addView(url); form.addView(group);
        new AlertDialog.Builder(this).setTitle("إضافة قناة")
                .setView(form).setPositiveButton("حفظ", (dialog, which) -> {
                    String n = name.getText().toString().trim();
                    String u = url.getText().toString().trim();
                    if (n.isEmpty() || !Channel.isValidStreamUrl(u)) {
                        message("لم تتم الإضافة", "أدخل اسماً ورابط بث HTTP أو HTTPS صالحاً.");
                        return;
                    }
                    int count = repo.add(new Channel(n, group.getText().toString().trim(), u, ""));
                    category = "الكل"; favoritesOnly = false; refresh();
                    toast(count == 1 ? "تمت إضافة القناة" : "القناة موجودة بالفعل أو القائمة ممتلئة");
                }).setNegativeButton("إلغاء", null).show();
    }

    private void showOfficialSources() {
        String[] labels = { "الجزيرة • بث عربي مباشر", "الجزيرة مباشر • الموقع الرسمي",
                "الجزيرة الوثائقية • الموقع الرسمي", "NASA+ • ناسا", "France 24 • فرانس 24", "DW • دويتشه فيله" };
        String[] urls = { "https://www.aljazeera.net/video/live",
                "https://www.aljazeera.net/video/live/الجزيرة-مباشر",
                "https://www.aljazeera.net/video/live/الجزيرة-الوثائقية",
                "https://plus.nasa.gov/", "https://www.france24.com/ar/live",
                "https://www.dw.com/en/live-tv/s-100825" };
        new AlertDialog.Builder(this).setTitle("مواقع القنوات الرسمية (تفتح بالمتصفح)")
                .setItems(labels, (d, i) -> {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(urls[i]))); }
                    catch (Exception e) { toast("لا يوجد متصفح لفتح الرابط"); }
                }).setNegativeButton("إغلاق", null).show();
    }

    private void message(String title, String body) {
        new AlertDialog.Builder(this).setTitle(title).setMessage(body == null ? "خطأ غير معروف" : body)
                .setPositiveButton("حسناً", null).show();
    }
    private void toast(String text) { Toast.makeText(this, text, Toast.LENGTH_SHORT).show(); }
}
