package com.mazentv.live;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;

public final class MainActivity extends Activity {
    private static final int PICK_M3U = 1007;
    private static final int MAX_PLAYLIST_BYTES = 20 * 1024 * 1024;
    private static final int BG = 0xFF090B10;
    private static final int SURFACE = 0xFF131722;
    private static final int SURFACE2 = 0xFF1A2030;
    private static final int STROKE = 0xFF2A3247;
    private static final int ACCENT = 0xFF61D0FF;
    private static final int ACCENT_2 = 0xFF8B5CFF;
    private static final int WHITE = 0xFFF5F7FB;
    private static final int MUTED = 0xFFA8B1C4;

    private ChannelRepository repo;
    private ChannelAdapter adapter;
    private TextView counter;
    private EditText search;
    private LinearLayout filters;
    private String category = "الكل";
    private boolean favoritesOnly = false;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        repo = new ChannelRepository(this);
        buildUI();
        refresh();
        if (repo.size() == 0) bootstrapDefaultCatalogs();
    }

    private int dp(float v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    private GradientDrawable shape(int fill, int corner) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(fill);
        d.setCornerRadius(dp(corner));
        return d;
    }

    private GradientDrawable shapeStroke(int fill, int corner, int strokeColor) {
        GradientDrawable d = shape(fill, corner);
        d.setStroke(dp(1), strokeColor);
        return d;
    }

    private TextView text(String label, int size, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(label);
        v.setTextSize(size);
        v.setTextColor(color);
        v.setGravity(Gravity.CENTER_VERTICAL);
        if (bold) v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        v.setTextDirection(View.TEXT_DIRECTION_FIRST_STRONG);
        return v;
    }

    private Button softButton(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextColor(WHITE);
        b.setTextSize(12);
        b.setBackground(shapeStroke(SURFACE2, 16, STROKE));
        b.setMinimumHeight(0);
        b.setMinHeight(0);
        b.setPadding(dp(12), dp(10), dp(12), dp(10));
        return b;
    }

    private Button accentButton(String label) {
        Button b = softButton(label);
        GradientDrawable gd = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{ACCENT_2, ACCENT});
        gd.setCornerRadius(dp(16));
        b.setBackground(gd);
        b.setTextColor(BG);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return b;
    }

    private LinearLayout vertical() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        return layout;
    }

    private LinearLayout horizontal() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.HORIZONTAL);
        layout.setGravity(Gravity.CENTER_VERTICAL);
        return layout;
    }

    private LinearLayout.LayoutParams lp(int w, int h, int l, int t, int r, int b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams((w == -1 || w == -2) ? w : dp(w), h == -1 || h == -2 ? h : dp(h));
        p.setMargins(dp(l), dp(t), dp(r), dp(b));
        return p;
    }

    private void buildUI() {
        LinearLayout root = vertical();
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.setFitsSystemWindows(true);
        root.setBackgroundColor(BG);
        root.setPadding(dp(16), dp(12), dp(16), dp(6));
        setContentView(root);

        LinearLayout header = horizontal();
        TextView logo = text("TV", 16, BG, true);
        logo.setGravity(Gravity.CENTER);
        GradientDrawable lg = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{ACCENT_2, ACCENT});
        lg.setCornerRadius(dp(18));
        logo.setBackground(lg);
        header.addView(logo, lp(54, 54, 0, 0, 12, 0));

        LinearLayout branding = vertical();
        branding.addView(text("تلفازي LIVE", 24, WHITE, true));
        branding.addView(text("واجهة حديثة لقنوات البث المباشر", 12, MUTED, false), lp(-1, -2, 0, 2, 0, 0));
        header.addView(branding, new LinearLayout.LayoutParams(0, -2, 1));

        Button catalog = accentButton("استكشاف");
        catalog.setOnClickListener(v -> showCatalog());
        header.addView(catalog, lp(-2, 42, 8, 0, 0, 0));

        Button menu = softButton("⋯");
        menu.setOnClickListener(v -> showQuickActions());
        header.addView(menu, lp(52, 42, 8, 0, 0, 0));
        root.addView(header, lp(-1, -2, 0, 0, 0, 12));

        LinearLayout hero = vertical();
        GradientDrawable heroBg = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{0xFF11192C, 0xFF0D1220, 0xFF11131A});
        heroBg.setCornerRadius(dp(22));
        hero.setBackground(heroBg);
        hero.setPadding(dp(16), dp(16), dp(16), dp(16));
        hero.addView(text("مشاهدة حديثة • قنوات أكثر • بث مباشر", 18, WHITE, true));
        hero.addView(text("القنوات تُجمع من أدلة عامة وروابط تضيفها أنت. التوفر والجودة والحقوق تعتمد على المصدر.", 12, 0xFFD7E0F3, false), lp(-1, -2, 0, 6, 0, 10));
        LinearLayout heroActions = horizontal();
        Button add = softButton("استيراد / إضافة");
        add.setOnClickListener(v -> showQuickActions());
        Button official = softButton("المصادر الرسمية");
        official.setOnClickListener(v -> showOfficialSources());
        heroActions.addView(add, new LinearLayout.LayoutParams(0, dp(42), 1));
        heroActions.addView(official, new LinearLayout.LayoutParams(0, dp(42), 1));
        root.addView(hero, lp(-1, -2, 0, 0, 0, 12));
        heroActions.setWeightSum(2);
        add.setLayoutParams(new LinearLayout.LayoutParams(0, dp(42), 1));
        official.setLayoutParams(new LinearLayout.LayoutParams(0, dp(42), 1));
        heroActions.setPadding(0,0,0,0);
        heroActions.setGravity(Gravity.CENTER_VERTICAL);
        hero.addView(heroActions);

        search = new EditText(this);
        search.setSingleLine(true);
        search.setHint("ابحث عن قناة أو تصنيف...");
        search.setTextSize(14);
        search.setHintTextColor(MUTED);
        search.setTextColor(WHITE);
        search.setPadding(dp(16), 0, dp(16), 0);
        search.setBackground(shapeStroke(SURFACE, 16, STROKE));
        search.setInputType(android.text.InputType.TYPE_CLASS_TEXT);
        root.addView(search, lp(-1, 50, 0, 0, 0, 8));
        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int st, int c, int a) {}
            @Override public void onTextChanged(CharSequence s, int st, int b, int c) { refreshList(); }
            @Override public void afterTextChanged(Editable e) {}
        });

        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setFillViewport(false);
        hs.setHorizontalScrollBarEnabled(false);
        filters = horizontal();
        hs.addView(filters);
        root.addView(hs, lp(-1, 40, 0, 0, 0, 8));

        counter = text("", 12, MUTED, false);
        root.addView(counter, lp(-1, 24, 0, 0, 0, 4));

        ListView list = new ListView(this);
        adapter = new ChannelAdapter();
        list.setAdapter(adapter);
        list.setDivider(null);
        list.setDividerHeight(dp(8));
        list.setVerticalScrollBarEnabled(false);
        list.setCacheColorHint(Color.TRANSPARENT);
        list.setSelector(android.R.color.transparent);
        list.setOnItemClickListener((parent, view, position, id) -> play(adapter.shown.get(position)));
        list.setOnItemLongClickListener((parent, view, position, id) -> {
            Channel c = adapter.shown.get(position);
            new AlertDialog.Builder(this).setTitle(c.name).setMessage("هل تريد حذف هذه القناة من قائمتك؟")
                    .setPositiveButton("حذف", (dialog, which) -> { repo.remove(c.url); refresh(); })
                    .setNegativeButton("إلغاء", null).show();
            return true;
        });
        root.addView(list, new LinearLayout.LayoutParams(-1, 0, 1));
    }

    private void refresh() {
        filters.removeAllViews();
        LinkedHashSet<String> names = new LinkedHashSet<>();
        names.add("الكل");
        names.add("المفضلة");
        for (Channel c : repo.all()) if (names.size() < 40) names.add(c.group);
        for (String name : names) {
            boolean selected = name.equals("المفضلة") ? favoritesOnly : (!favoritesOnly && name.equals(category));
            TextView chip = text(name, 12, selected ? BG : WHITE, true);
            chip.setGravity(Gravity.CENTER);
            chip.setPadding(dp(16), 0, dp(16), 0);
            chip.setBackground(shape(selected ? ACCENT : SURFACE, 15));
            chip.setOnClickListener(v -> {
                favoritesOnly = name.equals("المفضلة");
                if (!favoritesOnly) category = name;
                refresh();
            });
            filters.addView(chip, lp(-2, 34, 0, 0, 8, 0));
        }
        refreshList();
    }

    private void refreshList() {
        if (adapter == null) return;
        adapter.shown.clear();
        String needle = search == null ? "" : search.getText().toString().trim().toLowerCase(Locale.ROOT);
        for (Channel c : repo.all()) {
            if (favoritesOnly && !repo.isFavorite(c.url)) continue;
            if (!favoritesOnly && !"الكل".equals(category) && !category.equals(c.group)) continue;
            if (!c.matches(needle)) continue;
            adapter.shown.add(c);
        }
        adapter.notifyDataSetChanged();
        counter.setText("القنوات في قائمتك: " + adapter.shown.size() + " / " + repo.size());
    }

    private final class ChannelAdapter extends BaseAdapter {
        private final ArrayList<Channel> shown = new ArrayList<>();
        @Override public int getCount() { return shown.size(); }
        @Override public Object getItem(int p) { return shown.get(p); }
        @Override public long getItemId(int p) { return p; }
        @Override public View getView(int p, View convert, ViewGroup parent) {
            Channel c = shown.get(p);
            LinearLayout row = horizontal();
            row.setBackground(shapeStroke(SURFACE, 18, STROKE));
            row.setPadding(dp(12), dp(10), dp(12), dp(10));

            TextView icon = text("TV", 12, BG, true);
            icon.setGravity(Gravity.CENTER);
            GradientDrawable tv = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{ACCENT_2, ACCENT});
            tv.setCornerRadius(dp(14));
            icon.setBackground(tv);
            row.addView(icon, lp(48, 48, 0, 0, 12, 0));

            LinearLayout info = vertical();
            TextView title = text(c.name, 14, WHITE, true);
            title.setMaxLines(2);
            info.addView(title);
            LinearLayout meta = horizontal();
            TextView badge = text(c.group, 11, 0xFFD4DDF2, false);
            badge.setGravity(Gravity.CENTER);
            badge.setPadding(dp(10), dp(4), dp(10), dp(4));
            badge.setBackground(shape(0xFF1E2942, 10));
            meta.addView(badge);
            meta.addView(text("بث مباشر", 11, MUTED, false), lp(-2, -2, 8, 0, 0, 0));
            info.addView(meta, lp(-1, -2, 0, 5, 0, 0));
            row.addView(info, new LinearLayout.LayoutParams(0, -2, 1));

            LinearLayout side = vertical();
            TextView play = text("▶", 18, ACCENT, true);
            play.setGravity(Gravity.CENTER);
            side.addView(play, lp(26, 24, 0, 0, 0, 4));
            TextView star = text(repo.isFavorite(c.url) ? "★" : "☆", 24, repo.isFavorite(c.url) ? 0xFFFFD76A : MUTED, false);
            star.setGravity(Gravity.CENTER);
            star.setOnClickListener(v -> {
                repo.setFavorite(c.url, !repo.isFavorite(c.url));
                refreshList();
            });
            side.addView(star, lp(28, 28, 0, 0, 0, 0));
            row.addView(side, lp(30, -2, 0, 0, 0, 0));
            return row;
        }
    }

    @androidx.annotation.OptIn(markerClass = androidx.media3.common.util.UnstableApi.class)
    private void play(Channel c) {
        Intent i = new Intent(this, PlayerActivity.class);
        i.putExtra("name", c.name);
        i.putExtra("url", c.url);
        i.putExtra("group", c.group);
        startActivity(i);
    }

    private void showQuickActions() {
        String[] labels = {
                "تحديث القنوات من الدليل",
                "استيراد قائمة من رابط M3U",
                "استيراد قائمة من ملف M3U",
                "إضافة قناة يدوياً",
                "المصادر الرسمية بالمواقع",
                "معلومات عن الحقوق والمصادر"
        };
        new AlertDialog.Builder(this)
                .setTitle("إدارة القنوات")
                .setItems(labels, (dialog, which) -> {
                    if (which == 0) bootstrapDefaultCatalogs();
                    else if (which == 1) promptPlaylistUrl();
                    else if (which == 2) selectM3uFile();
                    else if (which == 3) promptSingleChannel();
                    else if (which == 4) showOfficialSources();
                    else message("المصادر والحقوق", "التطبيق يشغّل روابط البث التي تضيفها أو التي تأتي من أدلة عامة. التطبيق لا يفك التشفير ولا يتجاوز الاشتراكات ولا يضمن بقاء أي قناة متاحة.");
                })
                .setNegativeButton("إغلاق", null)
                .show();
    }

    private void selectM3uFile() {
        Intent pick = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        pick.setType("*/*");
        pick.addCategory(Intent.CATEGORY_OPENABLE);
        pick.putExtra(Intent.EXTRA_MIME_TYPES, new String[] {
                "audio/x-mpegurl", "application/x-mpegURL", "text/plain", "application/octet-stream" });
        try { startActivityForResult(pick, PICK_M3U); }
        catch (Exception error) { toast("تعذر فتح مدير الملفات"); }
    }

    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request != PICK_M3U || result != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        new Thread(() -> {
            try (InputStream in = getContentResolver().openInputStream(uri)) {
                if (in == null) throw new Exception("تعذر فتح الملف");
                importText(new String(readLimited(in), StandardCharsets.UTF_8));
            } catch (Exception e) { runOnUiThread(() -> message("تعذر استيراد الملف", e.getMessage())); }
        }).start();
    }

    private static byte[] readLimited(InputStream input) throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = input.read(buf)) != -1) {
            if (out.size() + n > MAX_PLAYLIST_BYTES) throw new Exception("حجم القائمة أكبر من 20 ميغابايت");
            out.write(buf, 0, n);
        }
        return out.toByteArray();
    }

    private void importText(String data) throws Exception {
        List<Channel> found = M3uParser.parse(data, ChannelRepository.capacity());
        int imported = repo.addMany(found);
        runOnUiThread(() -> {
            category = "الكل";
            favoritesOnly = false;
            refresh();
            message("استيراد القائمة", "أضيفت " + imported + " قناة جديدة. تم تجاهل الروابط غير الصالحة والمكررة.");
        });
    }

    private void promptPlaylistUrl() {
        EditText input = new EditText(this);
        input.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_URI);
        input.setHint("https://example.com/playlist.m3u");
        new AlertDialog.Builder(this).setTitle("رابط قائمة M3U")
                .setMessage("استخدم رابطاً تملك حق الوصول إليه. لن يتم تجاوز أي حماية أو اشتراك.")
                .setView(input).setPositiveButton("استيراد", (d, which) -> fetchPlaylist(input.getText().toString().trim(), false, false))
                .setNegativeButton("إلغاء", null).show();
    }

    private void fetchPlaylist(String url, boolean silent, boolean bootstrap) {
        if (!Channel.isValidStreamUrl(url)) {
            if (!silent) toast("الرابط غير صالح");
            return;
        }
        if (!silent) toast("جاري تنزيل القائمة...");
        new Thread(() -> {
            HttpURLConnection connection = null;
            try {
                connection = (HttpURLConnection) new URL(url).openConnection();
                connection.setConnectTimeout(12000);
                connection.setReadTimeout(22000);
                connection.setRequestProperty("User-Agent", "TilfaziLive/2.1 Android-TV-Client");
                connection.setRequestProperty("Accept", "application/x-mpegURL, audio/x-mpegurl, text/plain, */*");
                if (connection.getResponseCode() != 200) throw new Exception("الخادم أعاد رمز " + connection.getResponseCode());
                try (InputStream in = connection.getInputStream()) {
                    String payload = new String(readLimited(in), StandardCharsets.UTF_8);
                    List<Channel> found = M3uParser.parse(payload, ChannelRepository.capacity());
                    int added = repo.addMany(found);
                    runOnUiThread(() -> {
                        refresh();
                        if (!silent) message("تم الاستيراد", "أضيفت " + added + " قناة جديدة.");
                        else if (!bootstrap) toast("تمت إضافة " + added + " قناة");
                    });
                }
            } catch (Exception e) {
                runOnUiThread(() -> {
                    if (!silent) message("فشل تنزيل القائمة", e.getMessage());
                    else if (!bootstrap) toast("تعذر تحميل القائمة");
                });
            } finally { if (connection != null) connection.disconnect(); }
        }).start();
    }

    private void bootstrapDefaultCatalogs() {
        toast("جاري تجهيز القنوات الأساسية...");
        new Thread(() -> {
            int totalAdded = 0;
            for (CatalogSources.Source source : CatalogSources.startupSources()) {
                HttpURLConnection connection = null;
                try {
                    connection = (HttpURLConnection) new URL(source.url).openConnection();
                    connection.setConnectTimeout(12000);
                    connection.setReadTimeout(22000);
                    connection.setRequestProperty("User-Agent", "TilfaziLive/2.1 Android-TV-Client");
                    connection.setRequestProperty("Accept", "application/x-mpegURL, audio/x-mpegurl, text/plain, */*");
                    if (connection.getResponseCode() != 200) continue;
                    try (InputStream in = connection.getInputStream()) {
                        String payload = new String(readLimited(in), StandardCharsets.UTF_8);
                        List<Channel> found = M3uParser.parse(payload, ChannelRepository.capacity());
                        totalAdded += repo.addMany(found);
                    }
                } catch (Exception ignored) {
                    // Keep going so one failed catalog does not block the others.
                } finally {
                    if (connection != null) connection.disconnect();
                }
            }
            final int addedFinal = totalAdded;
            runOnUiThread(() -> {
                refresh();
                toast("تم تجهيز " + repo.size() + " قناة (جديد: " + addedFinal + ")");
            });
        }).start();
    }

    private void showCatalog() {
        CatalogSources.Source[] sources = CatalogSources.SOURCES;
        String[] labels = new String[sources.length];
        for (int i = 0; i < sources.length; i++) labels[i] = sources[i].title + "  •  " + sources[i].note;
        new AlertDialog.Builder(this)
                .setTitle("استكشاف مجموعات القنوات")
                .setItems(labels, (dialog, which) -> fetchPlaylist(sources[which].url, false, false))
                .setNeutralButton("عن الدليل والحقوق", (dialog, which) -> message("مصادر القنوات", "القوائم مصدرها مشروع IPTV-org الخارجي. لا يضمن التطبيق توفر القنوات أو حق إعادة نشر بثها، ولا يفك أي اشتراك أو تشفير. يمكنك أيضاً إضافة قنوات تملك إذناً بمشاهدتها من رابط خاص."))
                .setNegativeButton("إغلاق", null)
                .show();
    }

    private void promptSingleChannel() {
        LinearLayout form = vertical();
        form.setPadding(dp(20), 0, dp(20), 0);
        EditText name = new EditText(this);
        name.setHint("اسم القناة");
        EditText url = new EditText(this);
        url.setHint("رابط البث HLS / DASH / MP4");
        url.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_URI);
        EditText group = new EditText(this);
        group.setHint("التصنيف (اختياري)");
        form.addView(name); form.addView(url); form.addView(group);
        new AlertDialog.Builder(this).setTitle("إضافة قناة")
                .setView(form).setPositiveButton("حفظ", (dialog, which) -> {
                    String n = name.getText().toString().trim();
                    String u = url.getText().toString().trim();
                    if (n.isEmpty() || !Channel.isValidStreamUrl(u)) {
                        message("لم تتم الإضافة", "أدخل اسماً ورابط بث HTTP أو HTTPS صالحاً.");
                        return;
                    }
                    int count = repo.add(new Channel(n, group.getText().toString().trim(), u, ""));
                    category = "الكل"; favoritesOnly = false; refresh();
                    toast(count == 1 ? "تمت إضافة القناة" : "القناة موجودة بالفعل أو القائمة ممتلئة");
                }).setNegativeButton("إلغاء", null).show();
    }

    private void showOfficialSources() {
        String[] labels = {
                "الجزيرة • بث مباشر",
                "الجزيرة مباشر • الموقع الرسمي",
                "الجزيرة الوثائقية • الموقع الرسمي",
                "NASA+ • ناسا",
                "France 24 • فرانس 24",
                "DW • دويتشه فيله"
        };
        String[] urls = {
                "https://www.aljazeera.net/video/live",
                "https://www.aljazeera.net/video/live/الجزيرة-مباشر",
                "https://www.aljazeera.net/video/live/الجزيرة-الوثائقية",
                "https://plus.nasa.gov/",
                "https://www.france24.com/ar/live",
                "https://www.dw.com/en/live-tv/s-100825"
        };
        new AlertDialog.Builder(this).setTitle("مواقع القنوات الرسمية")
                .setItems(labels, (d, i) -> {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(urls[i]))); }
                    catch (Exception e) { toast("لا يوجد متصفح لفتح الرابط"); }
                }).setNegativeButton("إغلاق", null).show();
    }

    private void message(String title, String body) {
        new AlertDialog.Builder(this).setTitle(title).setMessage(body == null ? "خطأ غير معروف" : body)
                .setPositiveButton("حسناً", null).show();
    }

    private void toast(String text) { Toast.makeText(this, text, Toast.LENGTH_SHORT).show(); }
}
