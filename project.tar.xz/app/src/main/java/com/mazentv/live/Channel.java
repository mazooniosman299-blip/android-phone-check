package com.mazentv.live;

import java.util.Locale;

public final class Channel {
    public final String name;
    public final String group;
    public final String url;
    public final String logo;

    public Channel(String name, String group, String url, String logo) {
        this.name = clean(name, "قناة بدون اسم");
        this.group = clean(group, "عام");
        this.url = url == null ? "" : url.trim();
        this.logo = logo == null ? "" : logo.trim();
    }

    private static String clean(String value, String fallback) {
        return value == null || value.trim().isEmpty() ? fallback : value.trim();
    }

    public static boolean isValidStreamUrl(String url) {
        if (url == null) return false;
        try {
            java.net.URI uri = new java.net.URI(url.trim());
            String scheme = uri.getScheme();
            return scheme != null && (scheme.equalsIgnoreCase("https") || scheme.equalsIgnoreCase("http"))
                    && uri.getHost() != null && !uri.getHost().isEmpty()
                    && uri.getRawUserInfo() == null;
        } catch (Exception e) {
            return false;
        }
    }

    public boolean matches(String filter) {
        String f = filter == null ? "" : filter.toLowerCase(Locale.ROOT);
        return name.toLowerCase(Locale.ROOT).contains(f) || group.toLowerCase(Locale.ROOT).contains(f);
    }
}
