package com.mazentv.live;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/** User-controlled, portable backup of channels and favorites using Android's file picker. */
public final class ChannelBackup {
    public static final String FORMAT = "tilfazi-backup-v1";
    private static final int MAX_IMPORT_BYTES = 40 * 1024 * 1024;
    private ChannelBackup() {}

    public static int write(OutputStream stream, ChannelRepository repo) throws IOException {
        List<Channel> channels = repo.all();
        try {
            // Stream JSON one channel at a time instead of building a huge array in memory.
            stream.write(("{\"format\":\"" + FORMAT + "\",\"channels\":[").getBytes(StandardCharsets.UTF_8));
            int written = 0;
            for (Channel channel : channels) {
                if (!Channel.isValidStreamUrl(channel.url)) continue;
                JSONObject item = new JSONObject();
                item.put("name", channel.name);
                item.put("group", channel.group);
                item.put("url", channel.url);
                item.put("logo", channel.logo);
                item.put("favorite", repo.isFavorite(channel.url));
                if (written > 0) stream.write(',');
                stream.write(item.toString().getBytes(StandardCharsets.UTF_8));
                written++;
            }
            stream.write("]}".getBytes(StandardCharsets.UTF_8));
            stream.flush();
            return written;
        } catch (JSONException e) {
            throw new IOException("Cannot serialize channel backup", e);
        }
    }

    public static RestoreResult restore(InputStream input, ChannelRepository repo) throws IOException {
        ByteArrayOutputStream buffer = new ByteArrayOutputStream();
        byte[] chunk = new byte[8192];
        int read;
        while ((read = input.read(chunk)) != -1) {
            if (buffer.size() + read > MAX_IMPORT_BYTES) throw new IOException("Backup is larger than 40 MB");
            buffer.write(chunk, 0, read);
        }
        try {
            JSONObject file = new JSONObject(new String(buffer.toByteArray(), StandardCharsets.UTF_8));
            if (!FORMAT.equals(file.optString("format"))) throw new IOException("Unsupported backup format");
            JSONArray array = file.optJSONArray("channels");
            if (array == null || array.length() > ChannelRepository.capacity()) throw new IOException("Invalid channel count");
            List<Channel> rows = new ArrayList<>();
            List<String> favorites = new ArrayList<>();
            for (int i = 0; i < array.length(); i++) {
                JSONObject row = array.optJSONObject(i);
                if (row == null) continue;
                String url = row.optString("url", "");
                if (!Channel.isValidStreamUrl(url)) continue;
                rows.add(new Channel(row.optString("name"), row.optString("group"), url, row.optString("logo")));
                if (row.optBoolean("favorite", false)) favorites.add(url);
            }
            int added = repo.addMany(rows);
            for (String url : favorites) repo.setFavorite(url, true);
            return new RestoreResult(added, rows.size(), favorites.size());
        } catch (JSONException e) {
            throw new IOException("Backup JSON is corrupted", e);
        }
    }

    public static final class RestoreResult {
        public final int added, valid, favorites;
        RestoreResult(int added, int valid, int favorites) {
            this.added = added;
            this.valid = valid;
            this.favorites = favorites;
        }
    }
}
