package com.mazentv.live;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;

/** Disk-backed channel store; persists large playlists without a giant SharedPreferences JSON value. */
public final class ChannelRepository extends SQLiteOpenHelper {
    private static final int MAX_CHANNELS = 30000;
    private final LinkedHashMap<String, Channel> channels = new LinkedHashMap<>();
    private final HashSet<String> favorites = new HashSet<>();

    public ChannelRepository(Context context) {
        super(context.getApplicationContext(), "tilfazi_channels_v2.db", null, 1);
        SQLiteDatabase db = getWritableDatabase();
        try (Cursor cursor = db.rawQuery("SELECT name,grp,url,logo,favorite FROM channel ORDER BY id", null)) {
            while (cursor.moveToNext()) {
                Channel c = new Channel(cursor.getString(0), cursor.getString(1), cursor.getString(2), cursor.getString(3));
                if (!Channel.isValidStreamUrl(c.url)) continue;
                channels.put(c.url, c);
                if (cursor.getInt(4) != 0) favorites.add(c.url);
            }
        }
        migrateLegacyPrefs(context);
    }
    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE channel (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, grp TEXT NOT NULL, url TEXT UNIQUE NOT NULL, logo TEXT, favorite INTEGER NOT NULL DEFAULT 0)");
        db.execSQL("CREATE INDEX idx_channel_grp ON channel(grp)");
    }
    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) { /* Reserved */ }
    private void migrateLegacyPrefs(Context context) {
        SharedPreferences prefs = context.getSharedPreferences("tv_local_v1", Context.MODE_PRIVATE);
        if (!prefs.contains("channels")) return;
        try {
            JSONArray old = new JSONArray(prefs.getString("channels", "[]"));
            ArrayList<Channel> items = new ArrayList<>();
            for (int i=0; i<old.length() && i<MAX_CHANNELS; i++) {
                JSONObject o = old.optJSONObject(i);
                if (o != null) items.add(new Channel(o.optString("name"), o.optString("group"), o.optString("url"), o.optString("logo")));
            }
            addMany(items);
            for (String key : prefs.getStringSet("favorites", new HashSet<>())) setFavorite(key, true);
            prefs.edit().clear().apply();
        } catch (Exception ignored) { /* Keep old preferences for a later migration attempt. */ }
    }
    public synchronized List<Channel> all() { return new ArrayList<>(channels.values()); }
    public synchronized int size() { return channels.size(); }
    public synchronized boolean isFavorite(String url) { return favorites.contains(url); }
    public synchronized void setFavorite(String url, boolean favorite) {
        if (!channels.containsKey(url)) return;
        ContentValues values = new ContentValues();
        values.put("favorite", favorite ? 1 : 0);
        getWritableDatabase().update("channel", values, "url=?", new String[]{url});
        if (favorite) favorites.add(url); else favorites.remove(url);
    }
    public synchronized int add(Channel channel) { return addMany(java.util.Collections.singletonList(channel)); }
    public synchronized int addMany(List<Channel> items) {
        SQLiteDatabase db = getWritableDatabase();
        int inserted = 0;
        db.beginTransaction();
        try {
            for (Channel c : items) {
                if (channels.size() >= MAX_CHANNELS) break;
                if (!Channel.isValidStreamUrl(c.url) || channels.containsKey(c.url)) continue;
                ContentValues values = new ContentValues();
                values.put("name", c.name);
                values.put("grp", c.group);
                values.put("url", c.url);
                values.put("logo", c.logo);
                if (db.insertWithOnConflict("channel", null, values, SQLiteDatabase.CONFLICT_IGNORE) < 0) continue;
                channels.put(c.url, c);
                inserted++;
            }
            db.setTransactionSuccessful();
        } finally { db.endTransaction(); }
        return inserted;
    }
    public synchronized void remove(String url) {
        if (channels.remove(url) != null) {
            favorites.remove(url);
            getWritableDatabase().delete("channel", "url=?", new String[]{url});
        }
    }
    public static int capacity() { return MAX_CHANNELS; }
}
