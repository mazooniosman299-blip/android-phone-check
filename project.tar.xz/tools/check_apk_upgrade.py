#!/usr/bin/env python3
"""Read the actual Android APK Signing Block certificate, never the APK filename.

Run: python3 tools/check_apk_upgrade.py OLD.apk NEW.apk
Does not install, re-sign, or change either APK. For a final Android test use
adb install -r NEW.apk and inspect the returned PackageManager error code.
"""
import hashlib
from pathlib import Path
import struct
import sys

MAGIC = b"APK Sig Block 42"
SIGNING_IDS = {0x7109871A, 0xF05368C0}


def _u32(buf, index):
    return struct.unpack_from('<I', buf, index)[0]


def _u64(buf, index):
    return struct.unpack_from('<Q', buf, index)[0]


def _prefixed(buf, index):
    if index + 4 > len(buf):
        raise ValueError('Invalid APK signer length')
    length = _u32(buf, index)
    start = index + 4
    end = start + length
    if end > len(buf):
        raise ValueError('Invalid APK signer contents')
    return buf[start:end], end


def signer_sha256(path):
    content = Path(path).read_bytes()
    eocd = content.rfind(b'PK\x05\x06')
    if eocd < 0:
        raise ValueError('Not an APK/ZIP: EOCD missing')
    cd_offset = _u32(content, eocd + 16)
    if content[cd_offset - 16:cd_offset] != MAGIC:
        raise ValueError('APK v2/v3 signing block missing (v1-only not supported)')
    block_size = _u64(content, cd_offset - 24)
    block_start = cd_offset - block_size - 8
    if block_start < 0 or _u64(content, block_start) != block_size:
        raise ValueError('Broken APK signing block size')
    pairs = content[block_start+8:cd_offset-24]
    cursor = 0
    while cursor < len(pairs):
        length = _u64(pairs, cursor)
        signer_id = _u32(pairs, cursor+8)
        value = pairs[cursor+12:cursor+8+length]
        cursor += 8+length
        if signer_id not in SIGNING_IDS:
            continue
        signer_list, _ = _prefixed(value, 0)
        signer, _ = _prefixed(signer_list, 0)
        signed_data, _ = _prefixed(signer, 0)
        _, next_pos = _prefixed(signed_data, 0)  # digests
        certificates, _ = _prefixed(signed_data, next_pos)
        certificate, _ = _prefixed(certificates, 0)
        if not certificate or certificate[0] != 0x30:
            raise ValueError('Malformed X.509 certificate')
        return hashlib.sha256(certificate).hexdigest().upper()
    raise ValueError('No supported APK v2/v3 signers')


def main():
    if len(sys.argv) != 3:
        print(__doc__)
        return 2
    old_file, new_file = sys.argv[1:]
    old_cert = signer_sha256(old_file)
    new_cert = signer_sha256(new_file)
    print('Existing APK certificate SHA256:', old_cert)
    print('New APK certificate SHA256:     ', new_cert)
    if old_cert != new_cert:
        print('INCOMPATIBLE: Android will not replace the old app with the new signer.')
        return 1
    print('MATCH: Same signing certificate. Also verify package ID and versionCode')
    print('with Android aapt / PackageManager before distributing as an update.')
    return 0


if __name__ == '__main__':
    sys.exit(main())
