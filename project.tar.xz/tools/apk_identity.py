#!/usr/bin/env python3
"""Read Android binary manifest identity directly from an APK without Android SDK."""
import struct
import zipfile


def u16(data, pos): return struct.unpack_from('<H', data, pos)[0]
def u32(data, pos): return struct.unpack_from('<I', data, pos)[0]


def _length8(data, off):
    first = data[off]
    if first & 0x80:
        return ((first & 0x7F) << 8) | data[off + 1], off + 2
    return first, off + 1


def _length16(data, off):
    first = u16(data, off)
    if first & 0x8000:
        return ((first & 0x7FFF) << 16) | u16(data, off + 2), off + 4
    return first, off + 2


def _strings(data, off):
    count, flags, string_start = u32(data, off + 8), u32(data, off + 16), u32(data, off + 20)
    start_indices = off + u16(data, off + 2)
    result = []
    for i in range(count):
        ptr = off + string_start + u32(data, start_indices + 4 * i)
        if flags & 0x100:
            _, ptr = _length8(data, ptr)
            length, ptr = _length8(data, ptr)
            result.append(data[ptr:ptr + length].decode('utf-8'))
        else:
            length, ptr = _length16(data, ptr)
            result.append(data[ptr:ptr + 2 * length].decode('utf-16le'))
    return result


def apk_identity(path):
    with zipfile.ZipFile(path) as z:
        data = z.read('AndroidManifest.xml')
    if len(data) < 8 or u16(data, 0) != 0x0003:
        raise ValueError('Expected binary AndroidManifest.xml')
    cursor = u16(data, 2)
    strings = None
    while cursor < len(data):
        if cursor + 8 > len(data): break
        chunk_type = u16(data, cursor)
        chunk_size = u32(data, cursor + 4)
        if chunk_size < 8 or cursor + chunk_size > len(data):
            raise ValueError('Malformed Android binary XML chunk')
        if chunk_type == 0x0001:
            strings = _strings(data, cursor)
        elif chunk_type == 0x0102 and strings is not None:
            name_idx = u32(data, cursor + 20)
            if name_idx < len(strings) and strings[name_idx] == 'manifest':
                ext = cursor + 16
                attr_start = u16(data, ext + 8)
                attr_size = u16(data, ext + 10)
                count = u16(data, ext + 12)
                attrs = {}
                for i in range(count):
                    pos = ext + attr_start + i * attr_size
                    idx = u32(data, pos + 4)
                    if idx >= len(strings): continue
                    name = strings[idx]
                    raw = u32(data, pos + 8)
                    value_type = data[pos + 15]
                    value = u32(data, pos + 16)
                    if raw != 0xFFFFFFFF and raw < len(strings):
                        attrs[name] = strings[raw]
                    elif value_type == 0x03 and value < len(strings):
                        attrs[name] = strings[value]
                    else:
                        attrs[name] = value
                package, code = attrs.get('package'), attrs.get('versionCode')
                if not isinstance(package, str) or not isinstance(code, int):
                    raise ValueError('APK manifest is missing package or numeric versionCode')
                return package, code
        cursor += chunk_size
    raise ValueError('manifest element not found')
