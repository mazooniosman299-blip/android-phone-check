#!/usr/bin/env python3
"""Fail closed if a distributed release APK is not signed with the pinned app identity.

This checks signer identity, not runtime playback or on-device install. The private
keystore stays outside the public repository; the certificate fingerprint is public.
"""
from pathlib import Path
from check_apk_upgrade import signer_sha256
import sys

if len(sys.argv) != 2:
    raise SystemExit('Usage: verify_stable_signer.py <release.apk>')
expected = (Path(__file__).parent / 'release_signer_sha256.txt').read_text().strip().upper()
actual = signer_sha256(sys.argv[1])
if actual != expected:
    print('REJECT: APK signer differs from established Tilfazi release identity')
    print('Expected certificate:', expected)
    print('Actual certificate:  ', actual)
    raise SystemExit(1)
print('PASS: APK matches pinned long-term release signer', actual)
